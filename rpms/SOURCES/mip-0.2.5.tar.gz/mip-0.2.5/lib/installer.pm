#!/usr/bin/perl -w
use strict;

use File::Copy;
use File::Path;
use File::Basename;
use Cwd;

my $MIP_CONFIG_DIR="/home/hansent/mip-0.2/config";

####################################
## Installer methods ###############
####################################
sub install_mip{
   #setup source.pl
   #copy mip files
   #for every pkg in pkglist install pkg
}


## install_pkg
##    Installs a MIP package to an existing MIP installation
##    The mip package is extarcted and configured on the fly
##    by running the modules configuration file (which may choose
##    to alter the package's moduel list).  Then the module list
##    is read and each module listed is installed to the MIP 
##    installation.
sub install_pkg{
   my ($pkg_file, $pkg_name) = @_;
   my %mip_config = get_conf("source.pl");
   
   #prompt for target list and create pkg_name.pl configuration file
   my %pkg_config = get_config("$pkg_name.pl");
   #TODO: ask for cluster list
   save_config(\%pkg_conf);

   #extract gzipped tarball to tmp dir
   my $current_dir = cwd();
   my $tmpdir = "$mip_config{mipdir}/tmp";
   mkdir("$tmpdir"); 
   copy($pkg_file, $tmpdir);
   chdir("$tmpdir");
   if (system("tar -xzf $pkg_file") !=0){
     die "Error: Failed to untar pakackage.";
   }
   chdir($current_dir); #change back to old directory

   #configure pkg by running package config file
   if (-e "config"){
      do "$tmpdir/config";
   }

   #create package module directory if it doesnt exist yet
   mkdir("$mip_config{mipdir}/modules/$pkg_name");# unless (-d "$mip_config{mipdir}/$pkg_name");

   #read module list to get modules to be installed
   open(FILE, "$tmpdir/modules") or die("Unable to open module list file.");
   my @mod_list = <FILE>;
   close(FILE);

   #install each module from module list and check what roots should be installed
   my %roots = ();
   foreach my $mod (@mod_list){
     chomp $mod;
     unless($mod eq ""){
         $mod =~ /(.*)\//;
         my $root = $1;
         
         #if the root hasn't come up yet ask whether we want to install it
         unless ($roots{$root}){
            print "Would you like to install the $root Root?\n";
            my $inputline = <STDIN>;
            chomp($inputline);
            if($inputline =~ /^y.*/){
               $roots{$root} = 1;
            }
            else{
               $roots{$root} = -1;
            }
         }

        #install if its part of a root we want installed
        if($roots{$root} == 1){ 
           install_mod($pkg_name, $root, "$tmpdir/$pkg_name/$mod");
        }
     }
   }


   #all done...remove tmp diretory
   rmtree($tmpdir ,0,1)
}


## install_mod
##    installs a single mod file to the MIP
##    basically copies the sepcified file to teh right directory (mipdir/pkg/root/module.pl)
##    also, if it exists runs the optional module configuration file (living in teh same dir
##    as teh module and named the same plus a ".conf" suffix)

sub install_mod{
   my ($pkg_name, $root, $mod_file) = @_;

   my %mip_config = get_conf("source.pl");

   #configure module specific stuff in option module conf file
   if (-e "$mod_file.conf"){
      do "$mod_file.conf";
   }   

   #create root dir if it doesnt exist yet
   mkdir("$mip_config{moduledir}/$pkg_name/$root") unless (-d "$mip_config{mipdir}/modules/$pkg_name/$root" );

   #copy file to module/root dir of desired pkg;
   my $mod_name = basename("$mod_file");
   my $dest = "$mip_config{moduledir}/$pkg_name/$root/$mod_name";
   copy($mod_file, $dest) or die "Error:  Could not install $mod_name for package $pkg_name (Failed to copy '$mod_file' to '$dest')"; 
}




#####################################
## Configuration methods ############
#####################################


## get_conf
##    grabs teh specified configuration file from the MIP config directory
##    returns a handle to the configuration hash
sub get_conf{
   my ($conf_file) = @_;

   
   #read conf file
   my %config;
   if (-e "$MIP_CONFIG_DIR/$conf_file"){
      %config = do "$MIP_CONFIG_DIR/$conf_file";
   }
   else{
      %config = ();
   }

   #add some state vars to conf hash
   $config{__updated__} = 0;
   $config{__filename__} = $conf_file;
   
   return %config;
}


## save_conf
##    writes the configuration hash to the original file
##    it only writes if the configuration has been updated
sub save_conf{
   my ($conf) = @_;
   
   return unless ($conf->{__updated__} == 1);
   
   my $file_contents = __hsh_to_str($conf);
   open(OUTP, "> $MIP_CONFIG_DIR/$conf->{__filename__}") or die("Cannot open file '$conf->{__filename__}' for writing\n");
   print OUTP $file_contents;
   close OUTP;
}   


## __hsh_to_str
##    this function converts a configuration hash to a string that can be written to file
##    the output can be sourced into a hash by any perl  script
##    it handles sub-hashes and padds the lines for readability
sub __hsh_to_str{
   my ($hsh, $padding) = @_;
   my $str = '';

   foreach my $key(keys %{$hsh}){
      my $val = $hsh->{$key};
      if($padding){
         $str .= "   ";
      }
      #recurse if its an hash
      if(ref($val) eq "HASH"){
         $str .= "$key => { \n". __hsh_to_str($val, 1)."},";
      } 
      #write out the array
      elsif(ref($val) eq "ARRAY"){
         $str .= "$key => [";
         foreach(@{$val}){
            $str .= " \"$_\", ";
         }
         $str .= "], \n";
      }      
      #its a number or a string
      else{
         $str .= "$key => \"$val\",\n " unless ($key eq "__filename__" || $key eq "__updated__");
      }
   }
   return $str;
}


## add-config_val
##    simply adds a key/value pair to the configuration
##    also flags the congiguration hash as updated
sub add_conf_val{
   my ($conf, $key, $val) = @_;
   
   #add key/value and mark conf as updated
   $conf->{$key} = $val;
   $conf->{__updated__} = 1;
   return
}


## prompt_config_val
##    prints the specified prompt and lets user input a desired value
##    if the user hits <enter>, the specified default value will be set 
sub prompt_conf_val{
   my ($conf, $prompt, $key, $default_val) = @_;
   
   #interactive prompt for conf value
   print $prompt."[$default_val]:\n";

   my $inputline = <STDIN>;
   chomp($inputline);
   $default_val = $inputline unless ($inputline eq '');
   
   $conf->{$key} = $default_val;
   $conf->{__updated__} = 1;
}



## rem_conf_val
##    removes a key/value pair from teh configuration hash
##    also flag the configuration hash as updated
sub rem_conf_val{
   my ($conf, $key) = @_;
   
   #remove conf value from hash
   delete $conf->{$key};
   $conf->{__updated__} = 1;
}







# Some simple tests  (uncomment and run this file directly test)

#my %conf =  get_conf("osg2.pl");
#print __hsh_to_str(\%conf);
#save_conf(\%conf);
#print $conf{__filename__}."\n";
#add_conf_val(\%conf, "newval", "foo");
#print $conf{"newval"}."\n";
#prompt_conf_val(\%conf, "enter the path", "path", "/my/path");
#rem_conf_val(\%conf, "path");
#print $conf{path}."\n";
#print $conf{__updated__}."\n";


install_pkg("/home/hansent/mip-0.2/mypkg.tar.gz", "mypkg");

