clusterlist => ['grow-itb'],

uids =>  { 	Site             => [ "GROW", ],
				SubCluster       => [ "scuid something na alkjd aklj lkj", ],
				Cluster          => [ "clusteruid", ],
				ComputingElement => [ "ceuid", ],
				#StorageElement   => [ "seuid", ],
			}
			
