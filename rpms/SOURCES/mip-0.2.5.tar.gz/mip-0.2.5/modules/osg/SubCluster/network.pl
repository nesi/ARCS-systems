#!/usr/bin/perl
use strict;

# Copyright © 2005-2006 Grid Research and educatiOn group @ IoWa (GROW), The University of Iowa, IA. All rights reserved.
# For more information please contact: GROW team, grow-tech@grow.uiowa.edu

my ($hostname,$ipaddr,@privatelist);
my ($host,$devnull)=("google.com","/dev/null");
my ($outbound,$inbound)=("false","true");

if(!system("ping -q -c 1 $host 2>$devnull >$devnull")) {
	$outbound="true";
}

#FIXME: Need to find a better way to determine inbound network
$ipaddr=`hostname -i` or $inbound='false';

@privatelist=('10.','127.0.','172.16.','192.168.');
foreach my $range (@privatelist) {
	$inbound="false" if $ipaddr=~m/^$range/;
}

print "<NetworkAdapter OutboundIP=\"$outbound\" InboundIP=\"$inbound\"/>\n";


