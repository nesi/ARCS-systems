#!/bin/bash
#################################################################
# general parameters
#################################################################

# this version requires PRIMA_LOCATION
# and GLOBUS_LOCATION to be configured up front



#################################################################
# usage help screen
#################################################################
function usage {
  echo "
   Usage: ${0} -i install_directory -g globus_location [ -p product ] 

     -i install_directory
        Directory to set as the final install area for these products.

        WARNING: If this directory already exists, this script will
                 remove everything.

     -g globus_location
        The location of an existing GT3.2 distribution incl. header files

     -p product is one of the following...
                     curl
                     log4cpp
                     xerces
                     xmlsecurity
                     opensaml
                     opensamltest
		     prima_logger
		     prima_saml_support
		     prima_authz_module                     

        Doing these one at a time should only be done when trouble shooting
        problems with the builds.
  
        Default: All of the products are built.
                 This is probably the best mode to operate in.
                 It assumes you have made no changes to the
                 code in these packages as the source area
                 and install directory are deleted.

      WARNING: only use this script for the initial installation as it 
               cleans ALL areas whenever it is run and it will wipe
               out every change you may have made in the interim.
"
}
#---------------------------
function print_heading {
    echo "
##########################################
## $1
##########################################
" 
}

#-----------------------------------
function ask {


  read -p "
      **********************************
... $1
... Continue(y/n)?: " ans

case "$ans" in
  "y" ) ;;
  * ) echo "....BYE"
      exit ;;
esac

}


#---------------------------
function clean_build_area {
  for PRODUCT in $PRODUCTS
  do
    echo "--- $PRODUCT ---------------------"
    if [ -d $PRODUCT ];then
      echo "....removing directory: $PRODUCT"
      rm -rf $dir
    else
      echo "....WARNING directory ($PRODUCT) does not exist"

    fi
    TARFILE=$PRODUCT.tar.gz
    if [ ! -f $TARFILE ];then
      echo "....ERROR tar file ($TARFILE) does not exist"
      exit 1
    fi
    echo "....extracting from $TARFILE"
    tar zxf $TARFILE
    if [ "$?" != "0" ];then
      echo "....ERROR untarring $TARFILE"
      exit 1
    fi
  done
}
#---------------------------
function clean_install_area {
  echo "------------------------"
  echo "....cleaning install area: $PRIMA_LOCATION"
  if [  -d $PRIMA_LOCATION ];then
    rm -rf $PRIMA_LOCATION
  else
    echo "....WARNING: can't find $PRIMA_LOCATION"
    echo "    Assuming it is new."
  fi
  echo "....creating new install area: $PRIMA_LOCATION"
  mkdir $PRIMA_LOCATION
}

######### MAIN ##################################################



#----- products and dependencies -----------------
   curl=curl-7.11.1
   log4cpp=log4cpp-0.3.4b
   xerces=xerces-c-src_2_6_0
   xmlsecurity=xml-security-c-1.1.0
   opensaml=opensaml-1.0-with-osg-ext-0.1
   prima_logger=prima_logger-0.1
   prima_saml_support=prima_saml_support-0.2
   prima_authz_module=prima_authz_module-0.3

GLOBUS_LOCATION=""
PRIMA_LOCATION=""
unset GLOBUS_LOCATION
unset PRIMA_LOCATION

PRODUCTS="
$curl
$log4cpp
$xerces
$xmlsecurity
$opensaml
$prima_logger
$prima_saml_support
$prima_authz_module
"

#---- log files for builds ---
export LOGDIR=$PWD/build-logs
if [ ! -d $LOGDIR ];then
  mkdir $LOGDIR
fi
#--  the command line -----------
prod=""
while getopts p:i:g:y a
  do
    case $a in
      p ) prod=$OPTARG  
          eval PRODUCTS=\$$prod
          ;;
      i ) export PRIMA_LOCATION=$OPTARG  
          ;;
      g ) export GLOBUS_LOCATION=$OPTARG  
          ;;
      * ) echo "
"         
          usage
          exit 1;;
    esac
done
shift $(expr $OPTIND - 1)

if [ -z "$PRIMA_LOCATION" ];then
  echo "
....ERROR: -i option is required
"
  usage
  exit 1
fi

if [ -z "$GLOBUS_LOCATION" ];then
  echo "
....ERROR: -i option is required
"
  usage
  exit 1
fi
##################################
# intro message

echo "

This is a simple build script for the PRIMA authorization module
and its depenencies (mainly opensaml)

Parameters:
PRIMA_LOCATION is:  $PRIMA_LOCATION
GLOBUS_LOCATION is: $GLOBUS_LOCATION
"      



#---- clean directories -----------------------
#(only if we did not specify a specific product)
if [ -z "$prod" ];then
#-------- last warning -----
#  echo " 
#   Do you really want to clean your build area as well as the install area and
#   build the PRIMA module as well as its dependencies from scratch?
# "
#ask
  clean_build_area
  clean_install_area
fi

#--  build dependencies -----------------
export BUILD_DIR=$PWD
export LD_LIBRARY_PATH=$GLOBUS_LOCATION/lib:$PRIMA_LOCATION/lib:$LD_LIBRARY_PATH
unset LD_RUN_PATH

for PRODUCT in $PRODUCTS
do
  export PRODUCT
  cd $BUILD_DIR  ## need to get back to top level 
  case $PRODUCT in
    #-- curl --------------
    "$curl" )
       configure="./configure --prefix=$PRIMA_LOCATION --without-ca-bundle --enable-static=no --with-ssl=$GLOBUS_LOCATION"
       cd $PRODUCT
       ;;

    #-- log4cpp --------------
    "$log4cpp" )
       configure="./configure --prefix=$PRIMA_LOCATION --with-pthreads=yes --enable-static=no --enable-doxygen=no CXXFLAGS=\"-pthread\""
       cd $PRODUCT
       ;;

    #-- xerces --------------
    ## Xerces has a lousy make file which does not work when the libraries
    ## already exist.  Need to clean them
    "$xerces" )
##       rm -f $INSTALLDIR/lib/libxerces*
       export XERCESCROOT=$BUILD_DIR/$PRODUCT
#       rm -f $XERCESCROOT/lib/*
       configure="./runConfigure -p linux -c gcc -x g++ -r pthread -b 32 -P $PRIMA_LOCATION"
       cd $PRODUCT/src/xercesc
       ;;

    #-- xmlsecurity--------------
    "$xmlsecurity" )
       export XERCESCROOT=$BUILD_DIR/$xerces
       export OPENSSL=$GLOBUS_LOCATION 
       # the following is an attempt to fix the inability of configure to find xerces headers on RH7.2 
       export LDFLAGS="-L. -L$GLOBUS_LOCATION/lib -lcrypto_gcc32dbg -lssl_gcc32dbg "
       export CPPFLAGS=-I$PRIMA_LOCATION/include 
       echo "$XERCESCROOT/include/xercesc holds:"
       ls -la $XERCESCROOT/include/xercesc
       echo "LDFLAGS is set to $LDFLAGS"
       echo "CPPFLAGS is set to $CPPFLAGS"
       echo "XERCESCROOT is set to $XERCESCROOT"
       echo "OPENSSL is set to $OPENSSL"
       configure="./configure --prefix=$PRIMA_LOCATION --without-xalan"
       cd $PRODUCT/src
       ;;

    #-- opensaml --------------
    "$opensaml" )
       export XERCESCROOT=$BUILD_DIR/$xerces 
       unset LDFLAGS
       unset CPPFLAGS
       unset LIB
       export LDFLAGS="-L$GLOBUS_LOCATION/lib -lcrypto_gcc32dbg -lssl_gcc32dbg" 
       export CPPFLAGS="-I$GLOBUS_LOCATION/include/gcc32dbg/openssl "
       configure="./configure --prefix=$PRIMA_LOCATION --with-curl=$PRIMA_LOCATION --with-log4cpp=$PRIMA_LOCATION --with-xerces=$XERCESCROOT --with-xmlsec=$PRIMA_LOCATION --with-openssl=$GLOBUS_LOCATION -C"
       cd $PRODUCT
       ;;
    
    #-- prima_logger --------------
    "$prima_logger" )
       unset LDFLAGS
       unset CPPFLAGS
       configure="./configure --prefix=$PRIMA_LOCATION"
       cd $PRODUCT
       ;;

    #-- prima_saml_support --------------
    "$prima_saml_support" )
       unset LDFLAGS
       unset CPPFLAGS
       export OPENSAML_LOCATION=$PRIMA_LOCATION
       configure="./configure --prefix=$PRIMA_LOCATION"
       cd $PRODUCT
       ;;

    #-- prima_authz_module --------------
    "$prima_authz_module" )
       unset LDFLAGS
       unset CPPFLAGS
       configure="./configure --prefix=$PRIMA_LOCATION --with-flavor=gcc32dbg"
       cd $PRODUCT
       ls -la $PRIMA_LOCATION/include
       ;;

    #----------------
    * ) echo "
     ERROR: $PRODUCT is not a product we are building here
"
     usage
     exit 1 
     ;;
  esac
  ## --------------------------------------------
  ## build-it
  ## --------------------------------------------
    LOGFILE=$LOGDIR/$PRODUCT.log
    rm -f $LOGFILE
    #----
  (
    print_heading "Build Environment"
    echo "Compiler versions"
    gcc -v
    g++ -v

    echo "LD_LIBRARY_PATH is set to $LD_LIBRARY_PATH"
    echo "LD_RUN_PATH is set to $LD_RUN_PATH"
    echo "LDFLAGS is set to $LDFLAGS"
    echo "CPPFLAGS is set to $CPPFLAGS"
    echo "CFLAGS is set to $CFLAGS"

    print_heading "Configuring $PRODUCT"
    echo "$configure" 
    eval $configure 
    if [ "$?" != "0" ];then
      print_heading "FAILED in configuring $PRODUCT"
      cat config.log
      exit 
    else
      print_heading "SUCCESS in configuring $PRODUCT"
    fi 

    #--
    print_heading "Patching Makefile (replacing ssl and cypto libs, as well as curl lib name (adding gcc32dbg)"
    for makefile in $(find . -type f -name Makefile); do
      #sed '{s/-lssl /-lssl_gcc32dbg /g;s/-lcrypto /-lcrypto_gcc32dbg /g;s/-lssl$/-lssl_gcc32dbg/g;s/-lcrypto$/-lcrypto_gcc32dbg/g;s/-lcurl/-L${prefix}\/lib -lcurl_gcc32dbg/g;/^CURL_CONFIG/d;}' $makefile  > $makefile.patched
      sed '{s/-lssl /-lssl_gcc32dbg /g;s/-lcrypto /-lcrypto_gcc32dbg /g;s/-lssl$/-lssl_gcc32dbg/g;s/-lcrypto$/-lcrypto_gcc32dbg/g;}' $makefile  > $makefile.patched
      mv $makefile $makefile.original
      mv $makefile.patched $makefile
      echo "\n\n****************************\n***** New Makefile: $makefile \n\n" >> $LOGDIR/$PRODUCT-makefiles.log
      cat $makefile >> $LOGDIR/$PRODUCT-makefiles.log
    done

    #----
    print_heading " Making $PRODUCT "
    make 
    if [ "$?" != "0" ];then
      print_heading "FAILED in make for $PRODUCT"
      exit
    else
      print_heading "SUCCESS in make for $PRODUCT"
    fi

    #----
    print_heading " Installing $PRODUCT in $PRIMA_LOCATION"
    make install 
    if [ "$?" != "0" ];then
      print_heading "FAILED in make install for $PRODUCT"
      exit
    else
      print_heading "SUCCESS in make install for $PRODUCT"
    fi
  ) 2>&1 |tee -a $LOGFILE

  grep -qs FAIL $LOGFILE
  if [ "$?" = "0" ];then
     echo "*************FAILED****************"
     exit 1
  fi


  print_heading "Post Build Action"

  case $PRODUCT in
    #-- curl --------------
    #"$curl" )
     #  echo "renaming libcurl to libcurl_gcc32dbg"
     #  cd $PRIMA_LOCATION/lib
     #  ln -s libcurl.la libcurl_gcc32dbg.la
     #  ln -s libcurl.so.2.0.2 libcurl_gcc32dbg.so.2.0.2
     #  ln -s libcurl.so.2.0.2 libcurl_gcc32dbg.so.2
     #  ln -s libcurl.so.2.0.2 libcurl_gcc32dbg.so
     # ;;

    #-- prima_authz_module --------------
    "$prima_authz_module" )
       echo "moving libprima_authz_module libs to $PRIMA_LOCATION/lib"
       mv $GLOBUS_LOCATION/lib/libprima_authz_module_gcc32dbg.* $PRIMA_LOCATION/lib
       ;;

    #----------------
    * ) echo "
     No post build action required
"
     ;;

  esac

done

#--- test the opensaml ----------
#export LOGFILE=$LOGDIR/opensaml-tester-stderr.log
#(
#  testpgm=$BUILD_DIR/$opensaml/test/tester
#  print_heading "Testing OPENSAML ./test/tester program" 
#  if [ ! -f $testpgm ];then
#    print_heading "FAILED: opensaml test program not found." 
#    exit 1
#  else
#    cd $(dirname $testpgm)
#    $(basename $testpgm) -skipis -dump screen 
#  fi
#) 2<&1 | tee $LOGFILE




echo "

  WARNING: If this looks like it built correctly...
           you should have the binaries in $INSTALLDIR

           REMEMBER ... that you do not want to EVER run this script again.
           Especially if you have modified any of the source code for any
           of the products in here.
           This script will wipe out all your changes when it unpacks all
           the sources and replace the existing binary implementation in
           $INSTALLDIR

"


echo DONE
