#!/bin/bash
#################################################################
# general parameters
#################################################################

#---- installation directory ---
PRIMA_VERSION=prima-0.4
export INSTALLDIR="/usr/local/vdt-1.3.7/${PRIMA_VERSION}"

#----- globus location
export GLOBUS_LOCATION=/usr/local/vdt-1.3.7/globus

#---- openssl directory ---------
export OPENSSL_DIR=/usr/local/vdt-1.3.7/globus


##################################
# intro message

echo "

This is a simple build script for the PRIMA authorization module
and its depenencies (mainly opensaml)

Parameters:
INSTALLDIR:      $INSTALLDIR
GLOBUS_LOCATION: $GLOBUS_LOCATION
OPENSSL_DIR:     $OPENSSL_DIR

"      


#################################################################
# usage help screen
#################################################################
function usage {
  echo "
   Usage: ${0} -i install_directory [ -p product ] 

     -i install_directory
        Directory to set as the final install area for these products.

        WARNING: If this directory already exists, this script will
                 remove everything.

     -p product is one of the following...
                     curl
                     log4cpp
                     xerces
                     xmlsecurity
                     opensaml
                     opensamltest
		     prima_logger
		     prima_saml_support
		     prima_authz_module                     

        Doing these one at a time should only be done when trouble shooting
        problems with the builds.
  
        Default: All of the products are built.
                 This is probably the best mode to operate in.
                 It assumes you have made no changes to the
                 code in these packages as the source area
                 and install directory are deleted.

      WARNING: only use this script for the initial installation as it 
               cleans ALL areas whenever it is run and it will wipe
               out every change you may have made in the interim.
"
}
#---------------------------
function print_heading {
    echo "
##########################################
## $1
##########################################
" 
}

#-----------------------------------
function ask {
  read -p "
      **********************************
... $1
... Continue(y/n)?: " ans
case "$ans" in
  "y" ) ;;
  * ) echo "....BYE"
      exit ;;
esac
}


#---------------------------
function clean_build_area {
  for PRODUCT in $PRODUCTS
  do
    echo "--- $PRODUCT ---------------------"
    if [ -d $PRODUCT ];then
      echo "....removing directory: $PRODUCT"
      rm -rf $dir
    else
      echo "....WARNING directory ($PRODUCT) does not exist"

    fi
    TARFILE=$PRODUCT.tar.gz
    if [ ! -f $TARFILE ];then
      echo "....ERROR tar file ($TARFILE) does not exist"
      exit 1
    fi
    echo "....extracting from $TARFILE"
    tar zxf $TARFILE
    if [ "$?" != "0" ];then
      echo "....ERROR untarring $TARFILE"
      exit 1
    fi
  done
}
#---------------------------
function clean_install_area {
  echo "------------------------"
  echo "....cleaning install area: $INSTALLDIR"
  if [  -d $INSTALLDIR ];then
    rm -rf $INSTALLDIR
  else
    echo "....WARNING: can't find $INSTALLDIR"
    echo "    Assuming it is new."
  fi
  echo "....creating new install area: $INSTALLDIR"
  mkdir $INSTALLDIR
  if [ ! -d $INSTALLDIR ];then
    echo "...ERROR: Cannot create install dir $INSTALLDIR"
    exit 1
  fi
}

######### MAIN ##################################################
#---- setup the compiler --------
#fnal_setup="/fnal/ups/etc/setups.sh"
#if [ -f $fnal_setup ];then
#  source $fnal_setup
#else
#  echo "
#...ERROR: Cannot source FNAL setups.sh from
#          $fnal_setup 
#
#   This is necessary to get the correct C compiler.
#"
#  exit 1
#fi

#setup gcc v3_3_1 -f Linux+2.4-2.2.4  
export GCC_DIR=/usr
#print_heading "USING CC from $GCC_DIR" 

## need to (later) package the appropriate compiler lib with the binary distribution
#cpplibs="/afs/fnal.gov/ups/gcc/v3_3_1/Linux+2.4-2.2.4/lib/libstdc++.*"

export  CC=$GCC_DIR/bin/gcc
export CXX=$GCC_DIR/bin/g++


#----- products and dependencies -----------------
prima=osg-prima-0.4

       curl=curl-7.11.1
    log4cpp=log4cpp-0.3.4b
     xerces=xerces-c-src_2_6_0
xmlsecurity=xml-security-c-1.1.0
   opensaml=opensaml-1.0-with-osg-ext-0.1
   prima_logger=prima_logger-0.1
   prima_saml_support=prima_saml_support-0.2
   prima_authz_module=prima_authz_module-0.3

PRODUCTS="
$curl
$log4cpp
$xerces
$xmlsecurity
$opensaml
$prima_logger
$prima_saml_support
$prima_authz_module
"

#---- log files for builds ---
export LOGDIR=$PWD/install-logs
if [ ! -d $LOGDIR ];then
  mkdir $LOGDIR
fi
#--  the command line -----------
prod=""
while getopts p:i: a
  do
    case $a in
      p ) prod=$OPTARG  
          eval PRODUCTS=\$$prod
          ;;
      i ) INSTALLDIR=$OPTARG  
          ;;
      * ) echo "
"         
          usage
          exit 1;;
    esac
done
shift $(expr $OPTIND - 1)

if [ -z "$INSTALLDIR" ];then
  echo "
....ERROR: -i option is required
"
  usage
  exit 1
fi

#-------- last warning -----


#---- clean directories -----------------------
#(only if we did not specify a specific product)
if [ -z "$prod" ];then
  echo " 
   Do you really want to clean your build area as well as the install area and
   build the PRIMA module as well as its dependencies from scratch?
 "
  ask
  clean_build_area
  clean_install_area
fi

#--  build dependencies -----------------
export BUILD_DIR=$PWD
for PRODUCT in $PRODUCTS
do
  export PRODUCT
  export  CC=$GCC_DIR/bin/gcc
  export CXX=$GCC_DIR/bin/g++
  cd $BUILD_DIR  ## need to get back top level 
  case $PRODUCT in
    #-- curl --------------
    "$curl" )
       # all that the following gives us is that we are linked against BOTH the system and 
       # the globus library only way out I see is to change the Makefile after configure ran 
       #export LD_LIBRARY_PATH=$OPENSSL_DIR/lib/
       #export LDFLAGS="-L$OPENSSL_DIR/lib/ -lssl_gcc32dbg -lcrypto_gcc32dbg"
       #export CPPFLAGS="-I$OPENSSL_DIR/include/"       
       echo "LD_LIBRARY_PATH is: $LD_LIBRARY_PATH"
       echo "LDFLAGS are set to: $LDFLAGS"
       echo "CCPFLAGS are set to: $CPPFLAGS"
       configure="./configure --prefix=$INSTALLDIR --without-ca-bundle --enable-static=no --with-ssl=$OPENSSL_DIR"
       cd $PRODUCT
       ;;

    #-- log4cpp --------------
    "$log4cpp" )
#       export  CC=$LOG4_GCC_DIR/bin/gcc
#       export CXX=$LOG4_GCC_DIR/bin/g++
       echo "LD_LIBRARY_PATH is: $LD_LIBRARY_PATH"
       echo "LDFLAGS are set to: $LDFLAGS"
       echo "CCPFLAGS are set to: $CPPFLAGS"
       configure="./configure --prefix=$INSTALLDIR --with-pthreads=yes --enable-static=no --enable-doxygen=no CXXFLAGS=\"-pthread\""
       cd $PRODUCT
       ;;

    #-- xerces --------------
    ## Xerces has a lousy make file which does not work when the libraries
    ## already exist.  Need to clean them
    "$xerces" )
##       rm -f $INSTALLDIR/lib/libxerces*
       export XERCESCROOT=$BUILD_DIR/$PRODUCT
#       rm -f $XERCESCROOT/lib/*
       echo "LD_LIBRARY_PATH is: $LD_LIBRARY_PATH"
       echo "LDFLAGS are set to: $LDFLAGS"
       echo "CCPFLAGS are set to: $CPPFLAGS"
       configure="./runConfigure -p linux -c gcc -x g++ -r pthread -b 32 -P $INSTALLDIR"
       cd $PRODUCT/src/xercesc
       ;;

    #-- xmlsecurity--------------
    "$xmlsecurity" )
       export LD_LIBRARY_PATH=$OPENSSL_DIR/lib
       export XERCESCROOT=$BUILD_DIR/$xerces
       export OPENSSL=$OPENSSL_DIR 
       export LDFLAGS=-L$OPENSSL_DIR/lib       
       echo "LD_LIBRARY_PATH is: $LD_LIBRARY_PATH"
       echo "LDFLAGS are set to: $LDFLAGS"
       echo "CCPFLAGS are set to: $CPPFLAGS"
       configure="./configure --prefix=$INSTALLDIR --without-xalan"
       cd $PRODUCT/src
       ;;

    #-- opensaml --------------
    "$opensaml" )
       export XERCESCROOT=$BUILD_DIR/$xerces 
       # needed so configure can find openssl libraries and run test programs
       export LD_LIBRARY_PATH=$OPENSSL_DIR/lib
       export LDFLAGS="-L. -L$OPENSSL_DIR/lib -lcrypto_gcc32dbg -lssl_gcc32dbg "
       export CPPFLAGS="-L. -I$OPENSSL_DIR/include/gcc32dbg/openssl "
       configure="./configure --prefix=$INSTALLDIR --with-curl=$INSTALLDIR --with-log4cpp=$INSTALLDIR --with-xerces=$XERCESCROOT --with-xmlsec=$INSTALLDIR --with-openssl=$OPENSSL_DIR -C"
       cd $PRODUCT
       ;;
    
    #-- prima_logger --------------
    "$prima_logger" )
       unset LDFLAGS
       unset CPPFLAGS
       configure="./configure --prefix=$INSTALLDIR"
       cd $PRODUCT
       ;;

    #-- prima_saml_support --------------
    "$prima_saml_support" )
       unset LDFLAGS
       unset CPPFLAGS
       export OPENSAML_LOCATION=$INSTALLDIR
       configure="./configure --prefix=$INSTALLDIR"
       cd $PRODUCT
       ;;

    #-- prima_authz_module --------------
    "$prima_authz_module" )
       unset LDFLAGS
       unset CPPFLAGS
       export PRIMA_LOCATION=$INSTALLDIR
       configure="./configure --prefix=$INSTALLDIR --with-flavor=gcc32dbg"
       cd $PRODUCT
       ;;

    #----------------
    * ) echo "
     ERROR: $PRODUCT is not a product we are building here
"
     usage
     exit 1 
     ;;
  esac
  ## --------------------------------------------
  ## build-it
  ## --------------------------------------------
    LOGFILE=$LOGDIR/$PRODUCT.log
    rm -f $LOGFILE
    #----
  (
    print_heading "USING CC: $CC"
    print_heading "Configuring $PRODUCT"
    echo "$configure" 
    eval $configure 
    if [ "$?" != "0" ];then
      print_heading "FAILED in configuring $PRODUCT"
      exit 
    else
      print_heading "SUCCESS in configuring $PRODUCT"
    fi 
   
    #--
    print_heading "Patching Makefile (replacing ssl and cypto libs, adding LDFLAGS to libsaml.la for opensaml)"
    for makefile in $(find . -type f -name Makefile); do
      sed '{s/-lssl /-lssl_gcc32dbg /g;s/-lcrypto /-lcrypto_gcc32dbg /g;s/-lssl$/-lssl_gcc32dbg/g;s/-lcrypto$/-lcrypto_gcc32dbg/g;s/ \$(libsaml_la_LDFLAGS) / $(libsaml_la_LDFLAGS) $(LDFLAGS) /;}' $makefile  > $makefile.patched
      mv $makefile $makefile.original
      mv $makefile.patched $makefile
      echo "\n\n****************************\n***** New Makefile: $makefile \n\n" >> $LOGDIR/$PRODUCT-makefiles.log
      cat $makefile >> $LOGDIR/$PRODUCT-makefiles.log
    done
 
    #----
    print_heading " Making $PRODUCT "
    make 
    if [ "$?" != "0" ];then
      print_heading "FAILED in make for $PRODUCT"
      exit
    else
      print_heading "SUCCESS in make for $PRODUCT"
    fi

    #----
    print_heading " Installing $PRODUCT in $INSTALLDIR"
    make install 
    if [ "$?" != "0" ];then
      print_heading "FAILED in make install for $PRODUCT"
      exit
    else
      print_heading "SUCCESS in make install for $PRODUCT"
    fi
  ) 2>&1 |tee -a $LOGFILE

  grep -qs FAIL $LOGFILE
  if [ "$?" = "0" ];then
     echo "*************FAILED****************"
     exit 1
  fi
done

#--- test the opensaml ----------
#export LOGFILE=$LOGDIR/opensaml-tester-stderr.log
#(
#  testpgm=$BUILD_DIR/$opensaml/test/tester
#  print_heading "Testing OPENSAML ./test/tester program" 
#  if [ ! -f $testpgm ];then
#    print_heading "FAILED: opensaml test program not found." 
#    exit 1
#  else
#    cd $(dirname $testpgm)
#    $(basename $testpgm) -skipis -dump screen 
#  fi
#) 2<&1 | tee $LOGFILE

echo "moving libprima_authz_module libs to $INSTALLDIR/lib"
mv $GLOBUS_LOCATION/lib/libprima_authz_module_gcc32dbg.* $INSTALLDIR/lib

echo "not moving the standard C++ libs"
#echo "copying the standard C++ library of our compiler to $INSTALLDIR/lib"
#cp $cpplibs $INSTALLDIR/lib
 

echo "

  WARNING: If this looks like it built correctly... 
           you should have the binaries in $INSTALLDIR
           
           REMEMBER ... that you do not want to EVER run this script again. 
           Espceially if you have modified any of the source code for any 
           of the products in here. 
           This script will wipe out all your changes when it unpacks all
           the sources and replace the existing binary implementation in
           $INSTALLDIR

"

echo " Do you want to create a source and binary distribution of this build and
scp it to the web archive?"

ask

archive_dir=/usr/local/prima-archive
src_filename=$archive_dir/${prima}-src-date`date +%Y%m%d%H%M`.tar.gz
bin_filename=$archive_dir/${prima}-bin-date`date +%Y%m%d%H%M`.tar.gz
src_distro_files="$prima/${curl}.tar.gz $prima/${log4cpp}.tar.gz $prima/${opensaml}.tar.gz $prima/${prima_authz_module}.tar.gz $prima/${prima_logger}.tar.gz $prima/${prima_saml_support}.tar.gz $prima/${xerces}.tar.gz $prima/${xmlsecurity}.tar.gz $prima/README $prima/fnal-build.sh $prima/nmi-build.sh $prima/CHANGES"


echo "making source distribution with filename $src_filename "
echo "**************************************************************************************"
echo


cd $BUILD_DIR
cd ..
echo -n "I am in: "
pwd
echo "source dir holds"
ls -la $prima

echo "making source distribution"

tar -czf $src_filename $src_distro_files

echo "making binary distribution"

cd $INSTALLDIR
cd .. 
tar -czf $bin_filename ${PRIMA_VERSION}

#---- mark latest build as 'latest' in archive directory ---
echo "... updating 'latest' links in $archive_dir"
cd $archive_dir
rm -f ${prima}-src-latest.tar.gz
ln -s $src_filename ${prima}-src-latest.tar.gz 
rm -f ${prima}-bin-latest.tar.gz
ln -s $bin_filename ${prima}-bin-latest.tar.gz 
ls -l ${prima}-src-latest.tar.gz ${prima}-bin-latest.tar.gz

echo "BUILD complete - $(date)"
