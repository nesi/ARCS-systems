#
#	Copyright Saul Youssef, August 2003
#
from URL import *

class LocalDoc(URL):
	type   = 'localdoc'
	title  = 'Local Docs'
	action = 'localdoc'
	
	
