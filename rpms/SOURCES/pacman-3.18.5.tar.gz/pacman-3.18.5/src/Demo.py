#
#	Copyright Saul Youssef, August 2003
#
from StringAttr import *

class Demo(StringAttr):
	type   = 'demo'
	title  = 'Demos'
	action = 'demo'
	
