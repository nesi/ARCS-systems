#
#	Copyright, Saul Youssef, August 2003
#
from Platform import *

#def versionCheck():
#	pythonVersionCheck(); platformCheck()

