#!/usr/bin/env python
#
#   (If anyone knows a good freeze program, please let me know!  youssef@bu.edu)  S.Y.
#
import os,sys,string,commands

gt = 0
if not 'version_info' in dir(sys):
	gt = 1
else:
	gt = (2,2) > sys.version_info[0:2]
	
print os.getcwd()
if gt and not os.path.exists('python/python/bin'):
	print 'Your Python is version ['+sys.version+'] is too old for Pacman.'
	ans = raw_input('OK to install Python 2.2.3 locally now?: ')
	if ans=='y' or ans=='yes': pass
	else:
		print 'Python version ['+sys.version+'] is too old for Pacman.'
		sys.exit(1)
	print 'Fetching Python-2.2.3 tarball...'
	here = os.getcwd()
	os.chdir('python')
	
	print 'Downloading Python 2.2.3...'
	os.system('wget http://physics.bu.edu/pacman/python/Python-2.2.3.tgz .')
	print 'Unzipping...'
	os.system('gunzip Python-2.2.3.tgz')
	print 'Untarring...'
	os.system('tar xf Python-2.2.3.tar')
	os.system('mkdir python')
	print 'Configure...'
	os.system('cd Python-2.2.3; ./configure --prefix="'+os.path.join(here,'python/python')+'"')
	print 'Making Python 2.2.3...'
	os.system('cd Python-2.2.3; make; make install')
	os.system('rm -r -f Python-2.2.3')
	os.system('rm -f Python-2.2.3.tar')
	print 'Python [2.2.3] has been built.'
	print "Source setup.csh(sh) one more time and you're ready to use Pacman 3."
elif not gt:
	pass
else:
	print 'Using Python 2.2.3 from the Pacman installation area.'
	

	

