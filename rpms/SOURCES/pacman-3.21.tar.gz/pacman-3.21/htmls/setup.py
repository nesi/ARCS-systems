#
#-- Setup script made by Pacman 3.0100 and is often regenerated.  DO NOT EDIT
#
#
#-- package Demo:system
#
