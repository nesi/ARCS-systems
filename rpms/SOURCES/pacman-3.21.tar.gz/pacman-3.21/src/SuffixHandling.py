#
#	Copyright, Saul Youssef, August 2003
#
from IntAttr import *

class SuffixHandling(IntAttr):
	type   = 'suffix handling'
	title  = 'Suffix Handling'
	action = 'suffix handling'
