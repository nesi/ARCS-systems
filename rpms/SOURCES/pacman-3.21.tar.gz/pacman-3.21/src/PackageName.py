#
#	Copyright Saul Youssef, July 2003
#
from StringAttr import *

class PackageName(StringAttr):
	type   = 'packageName'
	title  = 'Package Names'
	action = 'set package name'
	
