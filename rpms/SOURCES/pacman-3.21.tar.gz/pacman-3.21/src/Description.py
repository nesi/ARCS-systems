#
#	Copyright Saul Youssef, July, 2003
#
from StringAttr import *

class Description(StringAttr):
	type   = 'description'
	title  = 'Descriptions'
	action = 'set description'
