#!/usr/bin/env python

'''
Introduction
------------
This script makes a self-contained, standalone executable that can be used 
to install any package from an ATLAS release without requiring Pacman or a 
network connection.  The executable includes a snapshot of a single ATLAS 
release including externals, CMT, Pacman, KV, requirements encoded into 
Pacman, etc.  This kind of file is intended as both an archive of a 
release at a particular moment in time and as a file that can be treated 
like just another kind of input file needed for jobs by DQ2, Panda, etc.

Usage
-----
Usage: makePacball.py <release number>, where <release number> is a 
release in the ATLAS cache.  This creates an executable called 
<release number>+KV.<date>.md5-<md5sum>.sh, where <data> is the current 
UTC time, formatted with %Y-%m-%d-%H-%M-%S, and <md5sum> is the checksum 
of the file.  Run the executable to install <release number> locally, or, 
to install any other package that's included with <release number>+KV, run 
the executable with one argument specifying the name of that package.  
Either way, the executable is meant to be run only once.  After running 
once successfully, subsequent execution in the same directory will do 
nothing, even if a different package is specified on the command line.

Details
-------
This python script makes a tarball archive of a snapshot of the ATLAS 
release specified on the command line (including Kit Validation).  It then 
generates a shell script and appends it to the front of the archive, 
making the executable.  Running the executable runs this script.  The 
script is able to extract and unpack the tarball that is attached to it 
and install a package from the resulting snapshot.

Note that the script at the front of the executable may be manually 
removed (up to and including the line `exit 0'), resulting in a standard 
tarball of the snapshot of the ATLAS release.
'''

import os, sys, popen2, md5, string, time, urllib2 as urllibX

class PacballException(Exception): pass

def runcmd(cmd):
	#(note: this is not the only place where system commands are run)
	try:
		p = popen2.Popen3(cmd, True)
		out = p.fromchild.read()
		err = p.childerr.read()
		retval = p.wait()
	except KeyboardInterrupt: raise
	except                  : raise PacballException('Unable to run ['+cmd+'].')
	if retval:
		msg = 'Error making pacball:'
		if out and err: msg += '\n'
		if out: msg = out+msg
		if err: msg = msg+err
		if msg: raise PacballException(msg)
		else  : raise PacballException('Unable to run ['+cmd+'].')

def quote(text):
	if "'"  not in text: return "'"+text+"'"
	if '"'  not in text: return '"'+text+'"'
	raise PacballException('Unable to quote ['+text+'].')

def encode(c):
	if c not in string.ascii_letters+string.digits+'_'+'.'+'-': return '_'
	else                                                      : return c

def makePacball(cache, snapshot_package, install_package):
	'make a fully self-contained executable to install any package (install_package by default) from cache:snapshot_package'


	#---verify environment
	
	#require pacman
	if os.system('which pacman &> /dev/null'): raise PacballException('Making a pacball requires Pacman.')
	
	#require python version
	verReq = [2,2]
	verSys = [sys.version_info[0],sys.version_info[1],sys.version_info[2]]
	if verSys<verReq: raise PacballException('You are using Python '+'.'.join(map(str,verSys))+'.  This script requires Python >= '+'.'.join(map(str,verReq))+'.')


	#---parameters

	CACHE            = cache
	SNAPSHOT_PACKAGE = snapshot_package
	INSTALL_PACKAGE  = install_package
	
	#keep the following simple (quote characters are not supported as in the above)
	TMPDIR     = 'o..tmp..o'                                                                #will be deleted if it already exists; this is used by this script and by the executable that this script makes
	PACMAN     = 'pacman-latest.tar.gz'                                                     #should exist in the cache that's created by snapshotting CACHE:SNAPSHOT_PACKAGE, or be available on the web at PACMAN_URL
	PACMAN_URL = 'http://physics.bu.edu/pacman/sample_cache/tarballs/pacman-latest.tar.gz'  #only used if PACMAN is not in the snapshot of CACHE:SNAPSHOT_PACKAGE
	SKIP       = '__SKIP__'                                                                 #a unique placeholder string


	#---parameter check

	#quoting in subshell find is not foolproof
	for param in [PACMAN, SKIP]:
		if "'" in param or '"' in param:
			raise PacballException('Parameter ['+param+'] cannot contain quotation marks.')
	#don't want accidental string substitution
	for param in [CACHE, SNAPSHOT_PACKAGE, INSTALL_PACKAGE, TMPDIR, PACMAN]:
		if param.find(SKIP)>-1:
			raise PacballException('Parameter ['+param+'] cannot contain ['+SKIP+'].')


	#---create working area

	#make sandbox (clobber)
	runcmd('rm -rf '+quote(TMPDIR))
	runcmd('mkdir '+quote(TMPDIR))
	os.chdir(TMPDIR)
	

	#---make the archive

	#fetch
	print 'Fetching dependent packages...'
	cmd = 'pacman -allow trust-all-caches -fetch '+quote(CACHE+':'+SNAPSHOT_PACKAGE)
	runcmd(cmd)

	#make the snapshot
	snapshot_name = ''.join([encode(c) for c in SNAPSHOT_PACKAGE])
	print 'Collecting downloads...'
	cmd = 'pacman -snap -o '+quote(snapshot_name)
	runcmd(cmd)

	#get pacman, if necessary
	addpacman = False
	numpacman = len([x for x in os.popen('find . -name '+quote(PACMAN)).read()[:-1].split('\n') if x])
	if numpacman==0:
		try                     : open(PACMAN,'w').write(urllibX.urlopen(PACMAN_URL).read())
		except KeyboardInterrupt: raise
		except                  : raise PacballException('Unable to download ['+PACMAN_URL+'].')
		addpacman = True
	elif numpacman>1:  raise PacballException('Snapshot ['+snapshot_name+'.snapshot] contains more than one ['+PACMAN+'].')

	#tar
	archive = snapshot_name+'.tar'
	cmd = 'tar cf '+quote(archive)+' '+quote(snapshot_name+'.snapshot')
	if addpacman: cmd += ' '+quote(PACMAN)
	runcmd(cmd)


	#---make the header

	abspathJAB = '''
function abspathJAB {
	FILE="$1"
	while true; do
		case "$FILE" in
			/*) 		
				while echo "$FILE" | grep -f "/./" > /dev/null 2>&1; do
					FILE=`echo "$FILE" | sed "s/\\/\\.\\//\\//"`
				done
				while echo "$FILE" | grep "/[^/][^/]*/\\.\\./" > /dev/null 2>&1; do
					FILE=`echo "$FILE" | sed "s/\\/[^/][^/]*\\/\\.\\.\\//\\//"`
				done
				echo "$FILE"
				exit 0
				;;
			*)
				FILE=`pwd`/"$FILE"
				;;
		esac
	done
}
'''
	lines = []
	lines.append('#!/usr/bin/env sh'                                                                                             )
	lines.append('set -e'                                                                                                        )
	lines.extend(abspathJAB.split('\n')                                                                                          )
	lines.append('INSTALL_PACKAGE=$"$1"'                                                                                         )
	lines.append('if [ -z $"$INSTALL_PACKAGE" ]; then INSTALL_PACKAGE='+quote(INSTALL_PACKAGE)+'; fi'                            )
	lines.append('if [ -d o..pacman..o ]; then'                                                                                  )
	lines.append('  if pacman -get $"$INSTALL_PACKAGE" &> /dev/null; then'                                                       )
	lines.append('    exit 0'                                                                                                    )
	lines.append('  else'                                                                                                        )
	lines.append('    echo Error: a Pacman installation already exists here.; exit 1'                                            )
	lines.append('  fi'                                                                                                          )
	lines.append('fi'                                                                                                            )
	lines.append('PACBALL_ABSPATH=`abspathJAB "$0"`'                                                                             )
	lines.append('rm -fr '+quote(TMPDIR)+'; mkdir '+quote(TMPDIR)+'; cd '+quote(TMPDIR)                                          )
	lines.append('echo Untarring...'                                                                                             )
	lines.append('tail -n +'+SKIP+' "$PACBALL_ABSPATH" | tar x'                                                                  )
	lines.append('rm -fr '+quote(TMPDIR)+'; mkdir '+quote(TMPDIR)                                                                )
	lines.append('gunzip -c "`find . -name \''+PACMAN+'\'`" | tar x -C '+quote(TMPDIR)                                           )  #(code above guarantees exactly one PACMAN is present)
	lines.append('cd '+quote(TMPDIR)+'/pacman*'                                                                                  )
	lines.append('source setup.sh'                                                                                               )
	lines.append('cd ../../..'                                                                                                   )
	lines.append('pacman -allow trust-all-caches -get '+quote(TMPDIR)+'/'+quote(snapshot_name)+'.snapshot:$"$INSTALL_PACKAGE"'   )
	lines.append('rm -fr '+quote(TMPDIR)                                                                                         )
	lines.append('exit 0'                                                                                                        )
	headertext = '\n'.join(lines).replace(SKIP, str(len(lines)+1))+'\n'
	header = 'header.sh'
	open(header, 'w').write(headertext)


	#---combine the header and archive into the executable

	#compute md5sum
	print 'Computing md5 checksum...'
	md5sum = md5.md5()
	md5sum.update(headertext)
	f = open(archive,'r')
	megs = 0
	while True:
		x = f.read(10000000)
		if x=='': break
		md5sum.update(x)
		megs = megs + 10
		if not megs%100: sys.stdout.write('\r'+`megs`+' MB...'); sys.stdout.flush()
	sys.stdout.write('\r'); sys.stdout.flush()  #(next line is longer than any of the above)
	f.close()
	md5sum = md5sum.hexdigest()

	#make the executable
	print 'Assembling Pacball...'
	executable = snapshot_name+'.time-'+time.strftime('%Y-%m-%d-%H-%M-%S', time.gmtime())+'.md5-'+md5sum+'.sh'
	runcmd('cat '+quote(header)+' '+quote(archive)+' > '+quote(executable))
	runcmd('chmod 750 '+quote(executable))


	#---cleanup

	runcmd('mv '+quote(executable)+' ..')
	os.chdir('..')
	runcmd('rm -rf '+quote(TMPDIR))
	print 'Pacball ['+executable+'] successfully created.'
	print 'Use % '+executable+' to install '+INSTALL_PACKAGE+'.'


if __name__=='__main__':
	#makePacball('http://atlas000.bu.edu/cache', 'PacmanParser', 'PacmanParser')
	#sys.exit(0)
	
	if not len(sys.argv)==2:
		print 'usage: '+sys.argv[0].split('/')[-1]+' <release number>'
		sys.exit(1)
	RELEASE = sys.argv[1]
	if RELEASE.endswith('+KV'):
		print '*** ERROR ***'
		print "The <release number> should not include `+KV'.  It's handled automatically."
		sys.exit(1)

	makePacball('ATLAS', RELEASE+'+KV', RELEASE)
