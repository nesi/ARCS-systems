#!/usr/bin/env python

# $ARGV[0] = clustername
# $ARGV[1] = uid from apac.pl
# $ARGV[2] = MIP config dir

import os, sys
import apac_lib as lib

def minutes(pbs_time):
	(hours, minutes, seconds) = map(int, pbs_time.split(":"))
	return hours * 60 + minutes

if __name__ == '__main__':

	c = lib.read_config(sys.argv[3])

	lib.assert_contains(c, sys.argv[1])
	lib.assert_contains(c[sys.argv[1]], 'ComputingElement')
	lib.assert_contains(c[sys.argv[1]].ComputingElement, sys.argv[2])

	config = c[sys.argv[1]].ComputingElement[sys.argv[2]]

	ce = lib.ComputingElement()
	ce.users = []

	if config.LRMSType == "Torque" or config.LRMSType == "PBSPro":

		if config.pbsnodes is not None and os.path.isfile(config.pbsnodes):
			ce.TotalCPUs = 0
			ce.FreeCPUs = 0

			lines = lib.run_command([config.pbsnodes, '-a'])
			for line in lines:
				if line.startswith('state ='):
					state = line.split()[-1]

				if line.startswith('np =') or line.startswith('resources_available.ncpus ='):
					np = int(line.split()[-1])
					
					# state can be 'down,job-exclusive'
					if state.find("down") == -1 and state.find("offline") == -1:
						ce.TotalCPUs += np

					if state == "free":
						ce.FreeCPUs += np

				if line.startswith('jobs =') and state == "free":
					ce.FreeCPUs -= 1 + line.count(",")


		if config.qstat is not None and os.path.isfile(config.qstat):
			lines = lib.run_command([config.qstat, '-B', '-f'])

			for line in lines:
				if line.startswith('pbs_version'):
					ce.LRMSVersion = line.split()[-1]


			lines = lib.run_command([config.qstat, '-Q', '-f', config.Name])

			import socket
			hostname = socket.getfqdn()

			do_host_acl = do_user_acl = True
			user_acl_done = enabled = started = False

			for line in lines:
				if line.startswith("queue_type ="):
					if not line.split()[-1] == "Execution":
						print "Not execution queue"
						break
				elif line.startswith("acl_host_enable ="):
					if not line.split()[-1] == "True":
						do_host_acl = False
				elif line.startswith("acl_users_enable ="):
					if not line.split()[-1] == "True":
						do_user_acl = False
				elif line.startswith("acl_hosts = ") and do_host_acl:
					allowed = False
					for name in line.split("=")[1].strip().split(","):
						if name == hostname:
							allowed = True
						# wildcard
						elif hostname.endswith(name.split("*")[-1]):
							allowed = True
					# this host isn't allowed to submit!
					if not allowed:
						pass
						# wipe
#						ce = lib.ComputingElement()
#						break
				elif line.startswith("acl_users = ") and do_user_acl:
					for name in line.split("=")[1].strip().split(","):
						ce.users.append(name)
					user_acl_done = True
				elif line.startswith("enabled = "):
					if line.split()[-1] == "True":
						enabled = True
				elif line.startswith("started = "):
					if line.split()[-1] == "True":
						started = True
				elif line.startswith("max_queuable ="):
					ce.MaxTotalJobs = line.split()[-1]
				elif line.startswith("total_jobs ="):
					ce.TotalJobs = line.split()[-1]
				elif line.startswith("Priority = "):
					ce.Priority = int(line.split()[-1])
				elif line.startswith("max_running = "):
					ce.MaxRunningJobs = int(line.split()[-1])
				elif line.startswith("max_user_run = "):
					ce.MaxTotalJobsPerUser = int(line.split()[-1])
				elif line.startswith("resources_max.cput = "):
					ce.MaxCPUTime = minutes(line.split()[-1])
				elif line.startswith("resources_max.walltime = "):
					ce.MaxWallClockTime = minutes(line.split()[-1])
				elif line.startswith("state_count ="):
					ce.WaitingJobs = 0
					entries = line.split()
					for index in [3, 4, 5]:
						ce.WaitingJobs += int(entries[index].split(":")[-1])

					ce.RunningJobs = int(entries[6].split(":")[-1])

				elif line.startswith("resources_max.ncpus = "):
					ce.resources_max_ncpus = int(line.split()[-1])
				
			if enabled and started:
				# no user acl processing done, grab the list of users from the vo map
				# TODO: hmmm, this work is questionable
				# it just copies from the config to an emtpy VOView!
				if not user_acl_done and len(config.views) > 0:
					ce.ACL = config.ACL

					for viewkey in config.views.keys():
						view = lib.VOView()
						
						for key in ('DefaultSE', 'DataDir', 'RealUser'):
							if config.views[viewkey].__dict__[key] is not None:
								view.__dict__[key] = config.views[viewkey].__dict__[key]

						if len(config.views[viewkey].ACL) > 0:
							view.ACL = config.views[viewkey].ACL
							ce.ACL += view.ACL

						ce.views[viewkey] = view

				for viewkey in ce.views.keys():
					view = ce.views[viewkey]
					view.ApplicationDir = ce.ApplicationDir
					view.TotalJobs = 0
					view.RunningJobs = 0
					view.WaitingJobs = 0
					if ce.FreeCPUs < ce.MaxTotalJobsPerUser:
						view.FreeJobSlots = ce.FreeCPUs
					else:
						view.FreeJobSlots = ce.MaxTotalJobsPerUser

					if view.RealUser is not None:

						lines = lib.run_command([config.qstat, '-u', view.RealUser, config.Name])

						import re

						select_expr = re.compile(r"^\d+")
						running_expr = re.compile(r"\d+\s+[RE]\s+")
						waiting_expr = re.compile(r"\d+\s+[QHTW]\s+")

						for line in lines:
							if select_expr.match(line):
								view.TotalJobs += 1
								if running_expr.search(line):
									view.RunningJobs += 1
								elif waiting_expr.search(line):
									view.WaitingJobs += 1

# TODO: in pbs.pl $jobs{MaxTotalJobsPerUser} is always undefined!
#					$jobs{FreeJobSlots}=$queues{$myqueue}{MaxTotalJobsPerUser}-$jobs{TotalJobs} if defined $jobs{MaxTotalJobsPerUser} and defined $jobs{TotalJobs};
#					conf.user_info.__dict__[user].FreeJobSlots = cp.MaxTotalJobsPerUser - conf.user_info.__dict__[user].TotalJobs

					view.FreeJobSlots -= view.TotalJobs	

	# overridable values
	for key in ['ApplicationDir', 'DataDir', 'DefaultSE', 'ContactString', 'Status', 'HostName', 'GateKeeperPort', 'Name', 'LRMSType', 'LRMSVersion', 'TotalCPUs', 'FreeCPUs', 'MaxWallClockTime', 'MaxCPUTime', 'RunningJobs', 'FreeJobSlots', 'MaxRunningJobs', 'MaxTotalJobs', 'TotalJobs', 'Priority', 'WaitingJobs']:
		if config.__dict__[key] is not None:
			ce.__dict__[key] = config.__dict__[key]


	if ce.MaxTotalJobs is not None and ce.TotalJobs is not None:
		ce.FreeJobSlots = int(ce.MaxTotalJobs) - int(ce.TotalJobs)

	if ce.FreeCPUs < ce.FreeJobSlots:
		ce.FreeJobSlots = ce.FreeCPUs

	# print
	for key in ['ApplicationDir', 'DataDir', 'DefaultSE', 'ContactString', 'Status', 'HostName', 'GateKeeperPort', 'Name', 'LRMSType', 'LRMSVersion', 'TotalCPUs', 'FreeCPUs', 'MaxWallClockTime', 'MaxCPUTime', 'RunningJobs', 'FreeJobSlots', 'MaxRunningJobs', 'MaxTotalJobs', 'TotalJobs', 'Priority', 'WaitingJobs']:
		if ce.__dict__[key] is not None:
			print "<%s>%s</%s>" % (key, ce.__dict__[key], key)


	for viewkey in ce.views.keys():
		view = ce.views[viewkey]

		print "<VOView LocalID=\"%s\">" % viewkey

		for key in ('FreeJobSlots', 'TotalJobs', 'RunningJobs', 'WaitingJobs', 'DefaultSE', 'ApplicationDir', 'DataDir'):
			if view.__dict__[key] is not None:
				print "\t<%s>%s</%s>" % (key, view.__dict__[key], key)

		print "<FreeJobSlots>%s</FreeJobSlots>" % view.FreeJobSlots
		print "\t<ACL>"
		for rule in view.ACL:
			print "\t\t<Rule>%s</Rule>" % rule
		print "\t</ACL>"
		print "</VOView>"


	import sets

	print "<ACL>"
	for rule in sets.Set(ce.ACL):
		print "\t<Rule>%s</Rule>" % rule
	print "</ACL>"



