# the following classes are defined in apac_lib.py
# Package
# Site
# Cluster
# StorageElement
# ComputingElement
# SubCluster
# StorageArea
# AccessProtocol
# VOView
# Processor
# MainMemory
# OperatingSystem

# TODO: move the logic into the classes


# this must be defined for each module
config['apac_py'] = Package()


# SITE INFORMATION
config['apac_py'].Site['TEST'] = Site()
config['apac_py'].Site['TEST'].Name = 'ExampleSite'
config['apac_py'].Site['TEST'].Description = 'An example site'
config['apac_py'].Site['TEST'].OtherInfo = ['some info', 'other info']
config['apac_py'].Site['TEST'].Web = 'http://example.apac.site'

config['apac_py'].Site['TEST'].Sponsor = [ 'sponsor 1', 'sponsor 2' ]
config['apac_py'].Site['TEST'].Location = 'Town, Country'
config['apac_py'].Site['TEST'].Latitude = '0'
config['apac_py'].Site['TEST'].Longitude = '0'

# if you set Contact the you don't need to set the others
config['apac_py'].Site['TEST'].Contact = 'mailto:support@example.apac.site'
#config['apac_py'].Site['TEST'].SysAdminContact = 'mailto:admin@example.apac.site'
#config['apac_py'].Site['TEST'].SecurityContact = 'mailto:security@example.apac.site'
#config['apac_py'].Site['TEST'].UserSupportContact = 'mailto:support@example.apac.site'


# STORAGE ELEMENT
config['apac_py'].StorageElement['storage1'] = StorageElement()
config['apac_py'].StorageElement['storage1'].areas['area1'] = StorageArea()
config['apac_py'].StorageElement['storage1'].areas['area1'].Path = '/path/to/area1'
config['apac_py'].StorageElement['storage1'].areas['area1'].Type = 'volatile'
config['apac_py'].StorageElement['storage1'].areas['area1'].ACL = [ '/VO1', '/VO2' ]

config['apac_py'].StorageElement['storage1'].areas['area2'] = StorageArea()
config['apac_py'].StorageElement['storage1'].areas['area2'].Path = '/path/to/area2'
config['apac_py'].StorageElement['storage1'].areas['area2'].Type = 'volatile'
config['apac_py'].StorageElement['storage1'].areas['area2'].ACL = [ '/VO3', '/VO4' ]

config['apac_py'].StorageElement['storage1'].protocols['prot1'] = AccessProtocol()
config['apac_py'].StorageElement['storage1'].protocols['prot1'].Type = 'gsiftp'
config['apac_py'].StorageElement['storage1'].protocols['prot1'].Version = '1.0.0'
config['apac_py'].StorageElement['storage1'].protocols['prot1'].Endpoint = 'gsiftp://ngdata.example.apac.site:2811'
config['apac_py'].StorageElement['storage1'].protocols['prot1'].Capability = [ 'file transfer', 'other capability' ]


# CLUSTER
config['apac_py'].Cluster['cluster1'] = Cluster()
config['apac_py'].Cluster['cluster1'].Name = 'clusterhostname'
config['apac_py'].Cluster['cluster1'].WNTmpDir = '/working/tmp/dir'
config['apac_py'].Cluster['cluster1'].TmpDir = '/std/tmp/dir'


# SUBCLUSTER
config['apac_py'].SubCluster['sub1'] = SubCluster()
config['apac_py'].SubCluster['sub1'].InboundIP = False
config['apac_py'].SubCluster['sub1'].OutboundIP = True
config['apac_py'].SubCluster['sub1'].PlatformType = ''
config['apac_py'].SubCluster['sub1'].SMPSize = 1

config['apac_py'].SubCluster['sub1'].PhysicalCPUs = 128
config['apac_py'].SubCluster['sub1'].LogicalCPUs = 128
config['apac_py'].SubCluster['sub1'].WNTmpDir = config['apac_py'].Cluster['cluster1'].WNTmpDir
config['apac_py'].SubCluster['sub1'].TmpDir = config['apac_py'].Cluster['cluster1'].TmpDir

# PROCESSOR
config['apac_py'].SubCluster['sub1'].Processor = Processor()
config['apac_py'].SubCluster['sub1'].Processor.File = '/proc/cpuinfo'
# if you want to override any values, just uncomment
#config['apac_py'].SubCluster['sub1'].Processor.Model = 'prossy model'
#config['apac_py'].SubCluster['sub1'].Processor.Vendor = 'prossy vendor'
#config['apac_py'].SubCluster['sub1'].Processor.ClockSpeed = 10000
#config['apac_py'].SubCluster['sub1'].Processor.InstructionSet = 'fpu tsc msr pae mce cx8 apic mtrr mca'

# MAIN MEMORY
config['apac_py'].SubCluster['sub1'].MainMemory = MainMemory()
config['apac_py'].SubCluster['sub1'].MainMemory.File = '/proc/meminfo'
# uncomment to override
#config['apac_py'].SubCluster['sub1'].MainMemory.RAMSize = 1024
#config['apac_py'].SubCluster['sub1'].MainMemory.VirtualSize = 3072

# OPERATING SYSTEM
config['apac_py'].SubCluster['sub1'].OperatingSystem = OperatingSystem()
config['apac_py'].SubCluster['sub1'].OperatingSystem.File = '/usr/bin/lsb_release'
#config['apac_py'].SubCluster['sub1'].OperatingSystem.Name = 'OS of your choice'
#config['apac_py'].SubCluster['sub1'].OperatingSystem.Release = 'hopefully recent'
#config['apac_py'].SubCluster['sub1'].OperatingSystem.Version = '1.0.0'


# COMPUTING ELEMENT
config['apac_py'].ComputingElement['compute1'] = ComputingElement()
config['apac_py'].ComputingElement['compute1'].Name = 'queue_name'
config['apac_py'].ComputingElement['compute1'].Status = 'Queueing'
config['apac_py'].ComputingElement['compute1'].JobManager = 'jobmanager-pbs'
config['apac_py'].ComputingElement['compute1'].HostName = 'ng2.example.apac.site'
config['apac_py'].ComputingElement['compute1'].GateKeeperPort = 8443
config['apac_py'].ComputingElement['compute1'].ContactString = 'ng2.hostname/jobmanager-pbs'
config['apac_py'].ComputingElement['compute1'].DefaultSE = 'ngdata.example.apac.site'
config['apac_py'].ComputingElement['compute1'].ApplicationDir = 'UNAVAILABLE'
config['apac_py'].ComputingElement['compute1'].DataDir = config['apac_py'].Cluster['cluster1'].TmpDir
config['apac_py'].ComputingElement['compute1'].LRMSType = 'Torque' # Torque|PBSPro

config['apac_py'].ComputingElement['compute1'].qstat = '/usr/bin/qstat'
config['apac_py'].ComputingElement['compute1'].pbsnodes = '/usr/bin/pbsnodes'

# this information can be retrieved from your LRMS (if defined)
#config['apac_py'].ComputingElement['compute1'].MaxTotalJobs = 9999999
#config['apac_py'].ComputingElement['compute1'].MaxRunningJobs = 9999999
#config['apac_py'].ComputingElement['compute1'].MaxCPUTime = 9999999
#config['apac_py'].ComputingElement['compute1'].MaxWallClockTime = 9999999
#config['apac_py'].ComputingElement['compute1'].MaxTotalJobsPerUser = 9999999

# you can define these if you want, but it's not advised
#config['apac_py'].ComputingElement['compute1'].LRMSVersion = '2.1.4'
#config['apac_py'].ComputingElement['compute1'].Priority = 1
#config['apac_py'].ComputingElement['compute1'].FreeCPUs = 1
#config['apac_py'].ComputingElement['compute1'].TotalCPUs = 1
        
#config['apac_py'].ComputingElement['compute1'].WaitingJobs = 0
#config['apac_py'].ComputingElement['compute1'].RunningJobs = 0
#config['apac_py'].ComputingElement['compute1'].TotalJobs = 0
#config['apac_py'].ComputingElement['compute1'].FreeJobSlots = 0

#config['apac_py'].ComputingElement['compute1'].ACL = [ '/VO3', '/VO4' ]

# VOVIEW
config['apac_py'].ComputingElement['compute1'].views['view1'] = VOView()
# the RealUser is used in working out the job information for the VOView, ie
# WaitingJobs, TotalCPUs, etc
# it should be retrieved from GUMS in the future
config['apac_py'].ComputingElement['compute1'].views['view1'].RealUser = 'grid-admin'
config['apac_py'].ComputingElement['compute1'].views['view1'].DefaultSE = 'ngdata.example.apac.site'
config['apac_py'].ComputingElement['compute1'].views['view1'].DataDir = '/path/to/area1'
config['apac_py'].ComputingElement['compute1'].views['view1'].ACL = [ '/VO1', '/VO2' ]


