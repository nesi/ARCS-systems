#!/usr/bin/env python

# $ARGV[0] = clustername
# $ARGV[1] = uid from apac.pl
# $ARGV[2] = MIP config dir

import os, sys
import apac_lib as lib

if __name__ == '__main__':
	c = lib.read_config(sys.argv[3])

	lib.assert_contains(c, sys.argv[1])
	lib.assert_contains(c[sys.argv[1]], 'StorageElement')
	lib.assert_contains(c[sys.argv[1]].StorageElement, sys.argv[2])

	config = c[sys.argv[1]].StorageElement[sys.argv[2]]

	# standard glue keys
	for area_key in config.areas.keys():
		area = config.areas[area_key]

		print "<StorageArea LocalID=\"%s\">" % area_key

		# work out free/used space
		if area.Path is not None and os.path.exists(area.Path):
			lines = lib.run_command(['df', '-k', area.Path])

			if len(lines) == 3:
				free_index = 2
				used_index = 1
			else:
				free_index = 3
				used_index = 2

			# config file overrides this
			if area.AvailableSpace is None:
#				free_space = int(lines[-1].split()[3])
				free_space = int(lines[-1].split()[free_index])
				if free_space > 0:
					area.AvailableSpace = free_space

			# config file overrides this
			if area.UsedSpace is None:
#				used_space = int(lines[-1].split()[2])
				used_space = int(lines[-1].split()[used_index])
				if used_space > 0:
					area.UsedSpace = used_space


		for key in ['Path', 'Type', 'AvailableSpace', 'UsedSpace']:
#			if lib.contains(area, key):
			if area.__dict__[key] is not None:
				print "\t<%s>%s</%s>" % (key, area.__dict__[key], key)

		print "\t<ACL>"

		for acl in area.ACL:
			print "\t\t<Rule>%s</Rule>" % acl

		print "\t</ACL>"

		print "</StorageArea>"

	for protocol_key in config.protocols.keys():
		protocol = config.protocols[protocol_key]

		print "<AccessProtocol LocalID=\"%s\">" % protocol_key

		for key in ['Endpoint', 'Type', 'Version']:
#			if lib.contains(protocol, key):
			if protocol.__dict__[key] is not None:
				print "\t<%s>%s</%s>" % (key, protocol.__dict__[key], key)

#		if lib.contains(protocol, 'Capability'):
		for capability in protocol.Capability:
			print "\t<Capability>%s</Capability>" % capability

		print "</AccessProtocol>"





