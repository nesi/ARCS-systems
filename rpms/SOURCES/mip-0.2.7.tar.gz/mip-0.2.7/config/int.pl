clusterlist => [ 
                 'grow-itb', 
               ], 

uids => { 
          Site => 
                     [ 
                       'GROW', 
                     ], 
          ComputingElement => 
                     [ 
                       'ceuid', 
                     ], 
          SubCluster => 
                     [ 
                       'scuidsomething na alkjd aklj lkj', 
                       'scuid', 
                     ], 
          Cluster => 
                     [ 
                       'clusteruid', 
                     ], 
        } 
