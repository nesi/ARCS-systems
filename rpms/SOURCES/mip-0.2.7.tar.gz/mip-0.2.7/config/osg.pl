clusterlist => ['grow-itb'],

uids =>  { 	Site             => [ "GROW", ],
				#SubCluster       => [ "scuid", ],
				Cluster          => [ "clusteruid", ],
				ComputingElement => [ "ceuid", ],
				StorageElement   => [ "seuid", ],
			}
			
