/* $OpenBSD: version.h,v 1.42 2004/08/16 08:17:01 markus Exp $ */

#define SSH_VERSION	"OpenSSH_3.9p1"
