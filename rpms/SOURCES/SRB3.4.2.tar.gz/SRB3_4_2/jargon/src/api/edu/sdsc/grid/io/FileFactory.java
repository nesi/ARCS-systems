//	Copyright (c) 2005, Regents of the University of California
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without
//	modification, are permitted provided that the following conditions are
//	met:
//
//	  * Redistributions of source code must retain the above copyright notice,
//	this list of conditions and the following disclaimer.
//	  * Redistributions in binary form must reproduce the above copyright
//	notice, this list of conditions and the following disclaimer in the
//	documentation and/or other materials provided with the distribution.
//	  * Neither the name of the University of California, San Diego (UCSD) nor
//	the names of its contributors may be used to endorse or promote products
//	derived from this software without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
//	IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
//	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
//	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
//	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
//	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
//	PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//	LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//	NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//  FILE
//	FileFactory.java	-  edu.sdsc.grid.io.FileFactory
//
//  CLASS HIERARCHY
//	java.lang.Object
//	    |
//	    +-.FileFactory
//
//  PRINCIPAL AUTHOR
//	Lucas Gilbert, SDSC/UCSD
//
//
package edu.sdsc.grid.io;

import edu.sdsc.grid.io.local.*;
import edu.sdsc.grid.io.srb.*;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * Operations include creating appropriately typed GeneralFile and
 * GeneralRandomAccessFile objects. Creating a file object can use
 * a "URI" (not a "URL").
 *<P>
 * @author	Lucas Gilbert, San Diego Supercomputer Center
 */
public final class FileFactory
{
//----------------------------------------------------------------------
// Static Methods
//----------------------------------------------------------------------
  /**
   * Creates an account appropriate to the uri. Account objects only store
   * account info and do not attempt to connect to the filesystem; no
   * IOExceptions will occur. Currently supported URI schemes are "file://"
   * and "srb://".
   *
   * @param uri The uri containining the account information.
   * @return a GeneralAccount object instanced from the appropriate subclass.
   * 		null will return a LocalAccount object.
   */
//Maybe these should all be filesystem? what did i need it for?
	static GeneralAccount newAccount( URI uri )
	{
  	if (uri != null) {
			if (uri.getScheme().equals( "srb" )) {
				String host = uri.getHost();
				int port = uri.getPort();
				String path = uri.getPath();
				String userInfo = uri.getUserInfo();
				String userName = null, mdasDomain = null, password = null;
				String homeDirectory = null;



			}
			//else if other types
		}

		//Default to local
		return new LocalAccount();
  }

  /**
   * Creates an abstract pathname using this uri. Currently supported
   * URI schemes are "file://" and "srb://".
   *<P>
   * Including a text password in a URI string is not advisable for security
   * reasons. This method allows the password to obtained by more secure
   * methods. The connection to the file will then be made through the
   * default authorization method of the file's filesystem.
   *
   * @param uri The uri containining the account information.
   * @param password The user's password.
   * @return a GeneralAccount object instanced from the appropriate subclass.
   * 		null will return a LocalAccount object.
   * @throws IllegalArgumentException If the password contains illegal
   * 		charaters.
   */
  static GeneralAccount newAccount( URI uri, String password )
  {
  	if (uri != null) {
			int index = -1;
			String userInfo = uri.getUserInfo();

			if (uri.getScheme().equals( "srb" )) {
				if ((password.indexOf(":") >= 0) || (password.indexOf("@") >= 0))
					throw new IllegalArgumentException(
						"Password contains illegal charaters");

				index = userInfo.indexOf(":");
				if (index >= 0) {
					//remove password already in uri and
					userInfo = userInfo.substring(0,index);
				}
				//add param password
				userInfo += ":"+ password;

				try {
					uri = new URI( uri.getScheme(), userInfo, uri.getHost(),
						uri.getPort(), uri.getPath(), "", "" );
				} catch ( URISyntaxException e ) {
					throw new IllegalArgumentException(
						"Password contains illegal charaters");
				}
				return newAccount( uri );
			}
			//else if other types
		}

		//Default to local
		return new LocalAccount();
  }


  /**
   * Creates an abstract pathname using this uri. Currently supported
   * URI schemes are "file://" and "srb://".
   *<P>
   * Including a text password in a URI string is not advisable for security
   * reasons. This method allows the authentication by GSI, if supported by
   * that filesystem.
   *
   * @param uri A URI object of the supported schemes.
   * @param proxyFilePath The location of the proxy file on the local
   * 		filesystem.
   * @param certificateAurthority The locations of the GSI Certificate
   * 		Authority (CA). The list can contain multiple files that are comma
   * 		separated. By default, the CA definition comes from the user's
   * 		cog.properties file.
   * @return a GeneralFile object instanced from the appropriate subclass.
   * @throws IllegalArgumentException If the password contains illegal
   * 		charaters.
   * @throws IOException If an IO error occurs testing the connection to
   *		the filesystem.
   */
   static GeneralFile newAccount( URI uri, String proxyFilePath,
  	String certificateAurthority )
  {
  	int index = -1;
		String userInfo = uri.getUserInfo();

		if (uri.getScheme().equals( "srb" )) {
			SRBAccount account = null;



		}
		//else if other types

		//Default to local
		return new LocalFile( uri );
  }



  /**
   * Creates a filesystem appropriate to the account object.
   *
   * @param account the account object used to initialize the filesystem.
   * @return a GeneralFileSystem object instanced from the appropriate subclass.
   * 		null will return a LocalFileSystem object.
   * @throws IOException If an IO error occurs during the connection to
   *		the filesystem.
   */
  public static GeneralFileSystem newFileSystem( GeneralAccount account )
  	throws IOException
  {
  	if (account != null) {
			if (account instanceof SRBAccount) {
				return new SRBFileSystem( (SRBAccount) account );
			}
			//else if other types
		}

		//Default to local
		return new LocalFileSystem();
  }
  
  
  /**
   * Creates a filesystem based on the URI.
   *
   * @param uri the uri used to initialize the filesystem.
   * @return a GeneralFileSystem object instanced from the appropriate subclass.
   * 		null will return a LocalFileSystem object.
   * @throws IOException If an IO error occurs during the connection to
   *		the filesystem.
   */
  public static GeneralFileSystem newFileSystem( URI uri )
  	throws IOException
  {
  	if (uri != null) {
      GeneralFile file = newFile( uri );
			return file.getFileSystem();
		}

		//Default to local
		return new LocalFileSystem();
  }



  /**
   * Creates an abstract pathname using this uri. Currently supported
   * URI schemes are "file://" and "srb://".
   *
   *
   * @param uri A URI object of the supported schemes.
   * @return a GeneralFile object instanced from the appropriate subclass.
   * @throws SecurityException The most likely cause is the URI did not
   * 		include a password. For security reasons, uri's are generally given
   *		without the password. Acquire a new password and
   *		@see GeneralFile newFile( URI uri, String password )
   *
   * @throws NullPointerException If uri argument is null.
   * @throws IOException If an IO error occurs testing the connection to
   *		the filesystem.
   */
  public static GeneralFile newFile( URI uri )
  	throws IOException
  {
		if (uri.getScheme().equals( "srb" ))
			return new SRBFile( uri );

		//else if other types

		//Default to local
		else
			return new LocalFile( uri );
  }


  /**
   * Creates an abstract pathname using this uri. Currently supported
   * URI schemes are "file://" and "srb://".
   *<P>
   * Including a text password in a URI string is not advisable for security
   * reasons. This method allows the password to obtained by more secure
   * methods. The connection to the file will then be made through the
   * default authorization method of the file's filesystem.
   *
   * @param uri A URI object of the supported schemes.
   * @param password The user's password.
   * @return a GeneralFile object instanced from the appropriate subclass.
   * @throws IllegalArgumentException If the password contains illegal
   * 		charaters.
   * @throws NullPointerException If uri argument is null.
   * @throws IOException If an IO error occurs testing the connection to
   *		the filesystem.
   */
  public static GeneralFile newFile( URI uri, String password )
  	throws IOException
  {
  	int index = -1;
		String userInfo = uri.getUserInfo();

		if (uri.getScheme().equals( "srb" )) {
			if ((password.indexOf(":") >= 0) || (password.indexOf("@") >= 0))
				throw new IllegalArgumentException(
					"Password contains illegal charaters");

			index = userInfo.indexOf(":");
			if (index >= 0) {
				//remove password already in uri and
				userInfo = userInfo.substring(0,index);
			}
			//add param password
			userInfo += ":"+ password;

			try {
				uri = new URI( uri.getScheme(), userInfo, uri.getHost(),
					uri.getPort(), uri.getPath(), "", "" );
			} catch ( URISyntaxException e ) {
				throw new IllegalArgumentException(
					"Password contains illegal charaters");
			}
			return new SRBFile( uri );
		}
		//else if other types

		//Default to local
		return new LocalFile( uri );
  }


  /**
   * Creates an abstract pathname using this uri. Currently supported
   * URI schemes are "file://" and "srb://".
   *<P>
   * Including a text password in a URI string is not advisable for security
   * reasons. This method allows for authentication with GSI, if supported by
   * that filesystem.
   *
   * @param uri A URI object of the supported schemes.
   * @param proxyFilePath The location of the proxy file on the local
   * 		filesystem.
   * @param certificateAurthority The locations of the GSI Certificate
   * 		Authority (CA). The list can contain multiple files that are comma
   * 		separated. By default, the CA definition comes from the user's
   * 		cog.properties file.
   * @return a GeneralFile object instanced from the appropriate subclass.
   * @throws IllegalArgumentException If the password contains illegal
   * 		charaters.
   * @throws NullPointerException If uri argument is null.
   * @throws IOException If an IO error occurs testing the connection to
   *		the filesystem.
   */
  static GeneralFile newFile( URI uri, String proxyFilePath,
  	String certificateAurthority )
  	throws IOException
  {
  	int index = -1;
		String userInfo = uri.getUserInfo();

		if (uri.getScheme().equals( "srb" )) {
//			return new SRBFile( new SRBFileSystem(
//				uri, proxyFilePath, certificateAurthority ), uri.getPath() );
		}
		//else if other types

		//Default to local
		return new LocalFile( uri );
  }


  /**
   * Creates an abstract pathname using a GeneralFileSystem object. Useful
   * for when you don't know which the file system the file is on. Calls
   * the constructor( FileSystem, String ) of the appropriate subclass.
   *
   * @param fs A generic file system reference object.
   * @param path The path to the file.
   * @return a GeneralFile object instanced from the appropriate subclass.
   * @throws NullPointerException If the path argument is null.
   */
  public static GeneralFile newFile( GeneralFileSystem fs, String path )
  {
  	if (fs != null) {
			if (fs instanceof SRBFileSystem) {
				return new SRBFile( (SRBFileSystem) fs, path );
			}
			//else if other types
		}
		//Default to local
		return new LocalFile( path );
  }


  /**
   * Creates an abstract pathname using a GeneralFileSystem object. Useful
   * for when you don't know which the file system the file is on. Calls
   * the constructor( FileSystem, String, String ) of the appropriate subclass.
   *
   * @param fs A generic file system reference object.
   * @param parent The directory path to the file.
   * @param child The file name string.
   * @return a GeneralFile object instanced from the appropriate subclass.
   * @throws NullPointerException If the child argument is null.
   */
  public static GeneralFile newFile( GeneralFileSystem fs, String parent,
  	String child )
  {
  	if (fs != null) {
			if (fs instanceof SRBFileSystem) {
				return new SRBFile( (SRBFileSystem) fs, parent, child );
			}
			//else if other types
		}

		//Default to local
		return new LocalFile( parent, child );
	}


  /**
   * Creates an abstract pathname using a GeneralFileSystem object. Useful
   * for when you don't know which the file system the file is on. Calls
   * the constructor( File, String ) of the appropriate subclass.
   *
   * @param parent An abstract pathname to the file.
   * @param child The file name string.
   * @return a GeneralFile object instanced from the appropriate subclass.
   * @throws NullPointerException If the child argument is null.
   */
  public static GeneralFile newFile( GeneralFile parent, String child )
  {
  	if (parent != null) {
			if (parent instanceof SRBFile) {
				return new SRBFile( (SRBFile) parent, child );
			}
			//else if other types
		}

		//Default to local
		return new LocalFile( (LocalFile) parent, child );
  }



  /**
   * Opens a random accecss connection to the file on an arbitrary file
   * system. Useful for when you don't know which the file system the
   * file is on.
   *
   * @return a GeneralRandomAccessFile object instanced from the
   *		appropriate subclass.
   * @throws NullPointerException If the file argument is null.
   * @throws IOException If an IO error occurs opening the file.
   */
  public static GeneralRandomAccessFile newRandomAccessFile(
  	GeneralFile file, String mode )
  	throws IOException
  {
		if (file instanceof SRBFile) {
		 return new SRBRandomAccessFile( (SRBFile) file, mode );
		}
		//else if other types

		//Default to local
		return new LocalRandomAccessFile( (LocalFile) file, mode );
  }



  /**
   * Opens a random accecss connection to the file on an arbitrary file
   * system. Useful for when you don't know which the file system the
   * file is on.
   *
   * @return a GeneralRandomAccessFile object instanced from the
   *		appropriate subclass.
   * @throws NullPointerException If the file argument is null.
   * @throws IOException If an IO error occurs opening the file.
   */
  public static GeneralRandomAccessFile newRandomAccessFile( 
    URI uri, String mode )
  	throws IOException
  {
    GeneralFile file = newFile( uri );
    
		if (file instanceof SRBFile) {
		 return new SRBRandomAccessFile( (SRBFile) file, mode );
		}
		//else if other types

		//Default to local
		return new LocalRandomAccessFile( (LocalFile) file, mode );
  }



  /**
   * Opens an input stream for the file on an arbitrary file
   * system. Useful for when you don't know which the file system the
   * file is on.
   *
   * @return a GeneralFileInputStream object instanced from the
   *		appropriate subclass.
   * @throws NullPointerException If the file argument is null.
   * @throws IOException If an IO error occurs opening the file.
   */
  public static GeneralFileInputStream newFileInputStream( GeneralFile file )
  	throws IOException
  {
		if (file instanceof SRBFile) {
		 return new SRBFileInputStream( (SRBFile) file );
		}
		//else if other types

		//Default to local
		return new LocalFileInputStream( (LocalFile) file );
  }


  /**
   * Opens an input stream for the file on an arbitrary file
   * system. Useful for when you don't know which the file system the
   * file is on.
   *
   * @return a GeneralFileInputStream object instanced from the
   *		appropriate subclass.
   * @throws NullPointerException If the file argument is null.
   * @throws IOException If an IO error occurs opening the file.
   */
  public static GeneralFileInputStream newFileInputStream( URI uri )
  	throws IOException
  {
    GeneralFile file = newFile(uri);
    
		if (file instanceof SRBFile) {
		 return new SRBFileInputStream( (SRBFile) file );
		}
		//else if other types

		//Default to local
		return new LocalFileInputStream( (LocalFile) file );
  }


  /**
   * Opens an output stream for the file on an arbitrary file
   * system. Useful for when you don't know which the file system the
   * file is on.
   *
   * @return a GeneralFileOutputStream object instanced from the
   *		appropriate subclass.
   * @throws NullPointerException If the file argument is null.
   * @throws IOException If an IO error occurs opening the file.
   */
  public static GeneralFileOutputStream newFileOutputStream( GeneralFile file )
  	throws IOException
  {
		if (file instanceof SRBFile) {
			return new SRBFileOutputStream( (SRBFile) file );
		}
		//else if other types

		//Default to local
		return new LocalFileOutputStream( (LocalFile) file );
  }

  /**
   * Opens an output stream for the file on an arbitrary file
   * system. Useful for when you don't know which the file system the
   * file is on.
   *
   * @return a GeneralFileOutputStream object instanced from the
   *		appropriate subclass.
   * @throws NullPointerException If the file argument is null.
   * @throws IOException If an IO error occurs opening the file.
   */
  public static GeneralFileOutputStream newFileOutputStream( URI uri )
  	throws IOException
  {
    GeneralFile file = newFile(uri);
    
		if (file instanceof SRBFile) {
			return new SRBFileOutputStream( (SRBFile) file );
		}
		//else if other types

		//Default to local
		return new LocalFileOutputStream( (LocalFile) file );
  }
  
  /**
   * Opens an output stream for the file on an arbitrary file
   * system. Useful for when you don't know which the file system the
   * file is on.
   *
   * @return a GeneralFileOutputStream object instanced from the
   *		appropriate subclass.
   * @throws NullPointerException If the file argument is null.
   * @throws IOException If an IO error occurs opening the file.
   */
  public static MetaDataRecordList newMetaDataRecordList( 
    GeneralFileSystem fileSystem, MetaDataField field, int recordValue)
  {
    if (fileSystem instanceof SRBFileSystem) {
      return new SRBMetaDataRecordList( field, recordValue );
    }
    else {
      return new LocalMetaDataRecordList();
    }
  }
  
  /**
   * Opens an output stream for the file on an arbitrary file
   * system. Useful for when you don't know which the file system the
   * file is on.
   *
   * @return a GeneralFileOutputStream object instanced from the
   *		appropriate subclass.
   * @throws NullPointerException If the file argument is null.
   * @throws IOException If an IO error occurs opening the file.
   */
  public static MetaDataRecordList newMetaDataRecordList( 
    GeneralFileSystem fileSystem, MetaDataField field, float recordValue)
  {
    if (fileSystem instanceof SRBFileSystem) {
      return new SRBMetaDataRecordList( field, recordValue );
    }
    else {
      return new LocalMetaDataRecordList();
    }    
  }
  
  /**
   * Opens an output stream for the file on an arbitrary file
   * system. Useful for when you don't know which the file system the
   * file is on.
   *
   * @return a GeneralFileOutputStream object instanced from the
   *		appropriate subclass.
   * @throws NullPointerException If the file argument is null.
   * @throws IOException If an IO error occurs opening the file.
   */
  public static MetaDataRecordList newMetaDataRecordList( 
    GeneralFileSystem fileSystem, MetaDataField field, String recordValue)
  {
    if (fileSystem instanceof SRBFileSystem) {
      return new SRBMetaDataRecordList( field, recordValue );
    }
    else {
      return new LocalMetaDataRecordList();
    }
  }
  
  /**
   * Opens an output stream for the file on an arbitrary file
   * system. Useful for when you don't know which the file system the
   * file is on.
   *
   * @return a GeneralFileOutputStream object instanced from the
   *		appropriate subclass.
   * @throws NullPointerException If the file argument is null.
   * @throws IOException If an IO error occurs opening the file.
   */
  public static MetaDataRecordList newMetaDataRecordList( 
    GeneralFileSystem fileSystem, MetaDataField field, MetaDataTable recordValue)
  {
    if (fileSystem instanceof SRBFileSystem) {
      return new SRBMetaDataRecordList( field, recordValue );
    }
    else {
      return new LocalMetaDataRecordList();
    }
  }
}



