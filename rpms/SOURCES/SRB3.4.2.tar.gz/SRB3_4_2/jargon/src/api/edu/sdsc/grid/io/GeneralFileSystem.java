//	Copyright (c) 2005, Regents of the University of California
//	All rights reserved.
//
//	Redistribution and use in source and binary forms, with or without
//	modification, are permitted provided that the following conditions are
//	met:
//
//	  * Redistributions of source code must retain the above copyright notice,
//	this list of conditions and the following disclaimer.
//	  * Redistributions in binary form must reproduce the above copyright
//	notice, this list of conditions and the following disclaimer in the
//	documentation and/or other materials provided with the distribution.
//	  * Neither the name of the University of California, San Diego (UCSD) nor
//	the names of its contributors may be used to endorse or promote products
//	derived from this software without specific prior written permission.
//
//	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
//	IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
//	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
//	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
//	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
//	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
//	PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//	LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//	NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//  FILE
//	GeneralFileSystem.java	-  edu.sdsc.grid.io.GeneralFileSystem
//
//  CLASS HIERARCHY
//	java.lang.Object
//	    |
//	    +-.GeneralFileSystem
//
//  PRINCIPAL AUTHOR
//	Lucas Gilbert, SDSC/UCSD
//
//
package edu.sdsc.grid.io;


import java.io.IOException;
import java.io.FileNotFoundException;

/**
 * The GeneralFileSystem class is the common superclass for connection
 * implementations to any file system. It provides the framework
 * to support specific file system semantics.
 * Specifically, the functions needed to interact with a file system
 * are provided abstractly by GeneralFileSystem and concretely by its
 * subclass(es).
 *<P>
 * @author	Lucas Gilbert, San Diego Supercomputer Center
 */
public abstract class GeneralFileSystem extends Object implements Cloneable
{
//----------------------------------------------------------------------
//  Constants
//----------------------------------------------------------------------


//----------------------------------------------------------------------
//  Fields
//----------------------------------------------------------------------
	/**
	 * The account info for connecting to the server.
	 */
	protected GeneralAccount account;



//----------------------------------------------------------------------
//  Constructors and Destructors
//----------------------------------------------------------------------
	/**
	 * Finalizes the object by explicitly letting go of each of
	 * its internally held values.
	 * <P>
	 */
	protected void finalize( )
		throws Throwable
	{
		account = null;
	}



//----------------------------------------------------------------------
// Setters and Getters
//----------------------------------------------------------------------
	/**
	 * Sets the account object, the info used to connect to the file system.
	 */
	protected abstract void setAccount( GeneralAccount account )
		throws FileNotFoundException, IOException;

	/**
	 * Returns a copy of the account object used by this GeneralFileSystem.
	 */
	public GeneralAccount getAccount( )
		throws NullPointerException
	{
		if ( account != null )
			return (GeneralAccount) account.clone();

		throw new NullPointerException();
	}

	/**
	 * Returns the homeDirectory used by this account on GeneralFileSystem.
	 */
	public String getHomeDirectory( )
	{
		return account.getHomeDirectory( );
	}

	/**
	 * Returns the rootDirectory used by this file system.
	 */
	public abstract String[] getRootDirectories( );


//----------------------------------------------------------------------
// Methods
//----------------------------------------------------------------------
	/**
	 *
	 */
	public abstract MetaDataRecordList[] query(
  	MetaDataCondition[] conditions, MetaDataSelect[] selects )
  	throws IOException;

	/**
	 *
	 */
	public abstract MetaDataRecordList[] query(	MetaDataCondition[] conditions,
		MetaDataSelect[] selects, int numberOfRecordsWanted )
  	throws IOException;



	/**
	 * @return a copy of this account object.
	 */
	public Object clone() {
		try {
				return super.clone();
		} catch (CloneNotSupportedException e) {
			//Shouldn't happen
			throw new InternalError();
		}
	}


	/**
	 * Tests this filesystem object for equality with the given object.
	 * Returns <code>true</code> if and only if the argument is not
	 * <code>null</code> and both are filesystem objects connected to the
	 * same filesystem using the same account information.
	 *
	 * @param   obj   The object to be compared with this abstract pathname
	 *
	 * @return  <code>true</code> if and only if the objects are the same;
	 *          <code>false</code> otherwise
	 */
	public abstract boolean equals( Object obj );


	/**
	 * Checks if the fileSystem is connected.
	 */
//TODO	public abstract boolean isConnected();


	/**
	 * Returns a string representation of this file system object.
	 */
	public String toString( )
	{
		return new String( "GeneralFileSystem, "+getHomeDirectory() );
	}
}
