import edu.sdsc.grid.io.local.*;
import edu.sdsc.grid.io.srb.*;
import edu.sdsc.grid.io.*;

import java.net.URI;
import java.io.*;



public class MoreTests
{
	/**
	 * Open a connection to the file system.
	 * The filesystem object represents the connection to the filesystem.
	 * Only one filesystem object is needed to access all the files on
	 * that system.
	 */
	GeneralAccount account = null;
	GeneralFileSystem fileSystem = null;


	/**
	 * The GeneralFile class is used in much the same manner as the
	 * java.io.File class. A GeneralFile object can represent
	 * a file or directory.
	 */
	GeneralFile file = null;


	/**
	 * The metadata records list for each file (directory, or other value
	 * the query selected for) is stored in this array.
	 */
	MetaDataRecordList[] rl = null;


//----------------------------------------------------------------------
// Constructors
//----------------------------------------------------------------------
	/**
	 * Testing for various small bugs that could possibly occur. Not really
	 * for showing examples of the functionality.
	 */
	public MoreTests()
		throws Throwable
	{
		this( new String[0] );
	}

	/**
	 * Testing the metaData
	 */
	public MoreTests(GeneralFile file)
		throws Throwable
	{
		if (file != null) {
			this.file = file;
			fileSystem = file.getFileSystem();
			run();
		}
		else {
			String uri[] = { file.toString() };

			new MetaDataTest( uri );
		}
	}

	/**
	 * Testing the metaData
	 */
	public MoreTests(String args[])
		throws Throwable
	{
		if (args == null) args = new String[0];

System.out.println("\n Connect to the fileSystem.");
		/**
		 * You can query any filesystem object though not all,
		 * such as LocalFileSystem, will return useful results.
		 */
		if (args.length == 1) {
			//url to file
			file = FileFactory.newFile(new URI( args[0] ));
			fileSystem = file.getFileSystem();
		}
		else if (args.length == 0) {
			fileSystem = FileFactory.newFileSystem( new SRBAccount( ) );

			String fileName = "myJARGONMoreTestsFile";
			file = FileFactory.newFile( fileSystem, fileName );
		}
		else {
			throw new IllegalArgumentException(
				"Wrong number of arguments sent to Test.");
		}

		run();
	}


	public void run()
		throws Throwable
	{
		//Make sure file exists
		file.createNewFile();

System.out.println("***No tests yet!***");

	}




//----------------------------------------------------------------------
// Methods
//----------------------------------------------------------------------

	/**
	 * Stand alone testing.
	 */
	public static void main(String args[])
	{
		try {
			MoreTests mdt = new MoreTests(args);
    	} catch ( Throwable e ) {
			System.out.println( "\nJava Error Message: "+ e.toString() );
			e.printStackTrace();
    		System.exit(1);
		}

		System.exit(0);
	}
}
