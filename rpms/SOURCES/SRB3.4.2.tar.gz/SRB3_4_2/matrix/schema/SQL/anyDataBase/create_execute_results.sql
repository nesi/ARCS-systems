
DROP TABLE M_EXECUTE_RESULTS CASCADE CONSTRAINTS;

--
-- M_EXECUTE_RESULT  (Table) 
--
CREATE TABLE M_EXECUTE_RESULTS
(
  MER_THREAD      NUMBER(10)                        NULL,
  MER_OUTPUT      VARCHAR2(1000 CHAR)               NULL,
  MER_STD_OUT_FK  NUMBER(10)                        NULL,
  MER_STD_ERR_FK  NUMBER(10)                        NULL
)
TABLESPACE USERS
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           );

COMMENT ON COLUMN M_EXECUTE_RESULTS.MER_THREAD IS 'references m_threads(pk)';

COMMENT ON COLUMN M_EXECUTE_RESULTS.MER_OUTPUT IS 'string out put';

COMMENT ON COLUMN M_EXECUTE_RESULTS.MER_STD_OUT_FK IS 'references m_stream_data(id)';

COMMENT ON COLUMN M_EXECUTE_RESULTS.MER_STD_ERR_FK IS 'references m_stream_data(id)';


