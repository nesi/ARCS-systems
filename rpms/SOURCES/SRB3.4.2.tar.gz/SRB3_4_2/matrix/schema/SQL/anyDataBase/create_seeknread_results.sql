CREATE TABLE ARUN.M_SEEKNREAD_RESULTS
(
  msr_thread        NUMBER(10),
  msr_content_id    VARCHAR2(25 CHAR),
  msr_external_uri  VARCHAR2(75 CHAR),
  msr_comments      VARCHAR2(40 CHAR)
)

LOGGING 
NOCACHE
NOPARALLEL
NOMONITORING;

COMMENT ON COLUMN ARUN.M_SEEKNREAD_RESULTS.msr_thread IS 'references m_threads(primary_key)';

COMMENT ON COLUMN ARUN.M_SEEKNREAD_RESULTS.msr_content_id IS 'references m_attachments(ma_attach_id)';


