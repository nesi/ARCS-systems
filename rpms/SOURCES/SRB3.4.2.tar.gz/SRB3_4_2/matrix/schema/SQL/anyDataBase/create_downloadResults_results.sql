CREATE TABLE ARUN.M_DOWNLOAD_RESULTS
(
  mdr_thread        NUMBER(10),
  mdr_content_id    VARCHAR2(25 CHAR),
  mdr_external_uri  VARCHAR2(75 CHAR),
  mdr_external_url  VARCHAR2(75 CHAR),
  mdr_comments      VARCHAR2(40 CHAR)
)

LOGGING 
NOCACHE
NOPARALLEL
NOMONITORING;

COMMENT ON COLUMN ARUN.M_DOWNLOAD_RESULTS.mdr_thread IS 'references m_thread(threadid_pk)';

COMMENT ON COLUMN ARUN.M_DOWNLOAD_RESULTS.mdr_content_id IS 'references m_attachments(ma_attach_id)';

COMMENT ON COLUMN ARUN.M_DOWNLOAD_RESULTS.mdr_external_url IS 'not used - redundant';


