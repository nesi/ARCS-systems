CREATE TABLE ARUN.M_METADATA_QUERY_RESULTS
(
  mqr_thread      NUMBER(10),
  mqr_query       VARCHAR2(250 CHAR),
  mqr_result_XML  VARCHAR2(1000 CHAR)
)

LOGGING 
NOCACHE
NOPARALLEL
NOMONITORING;

COMMENT ON COLUMN ARUN.M_METADATA_QUERY_RESULTS.mqr_thread IS 'references m_threads(pk)';

COMMENT ON COLUMN ARUN.M_METADATA_QUERY_RESULTS.mqr_result_XML IS 'the whole thing marshallized into XML';


