
DROP TABLE M_ATTACHMENTS CASCADE CONSTRAINTS;

--
-- M_ATTACHMENTS  (Table) 
--
CREATE TABLE M_ATTACHMENTS
(
  MA_UPDATE         DATE                            NULL,
  MA_THREAD_ID      NUMBER(10)                      NULL,
  MA_ATTACH_ID      VARCHAR2(25 CHAR)               NULL,
  MA_TYPE           CHAR(1 CHAR)                    NULL,
  MA_FILE_LOCATION  VARCHAR2(50 CHAR)               NULL
)
TABLESPACE USERS
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           );


--
-- M_ATTACHMENTS_U01  (Index) 
--
CREATE UNIQUE INDEX M_ATTACHMENTS_U01 ON M_ATTACHMENTS
(MA_THREAD_ID, MA_ATTACH_ID, MA_TYPE)
TABLESPACE USERS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           );


-- 
-- Non Foreign Key Constraints for Table M_ATTACHMENTS 
-- 
ALTER TABLE M_ATTACHMENTS ADD (
  CONSTRAINT M_ATTACHMENTS_U01
 UNIQUE (MA_THREAD_ID, MA_ATTACH_ID, MA_TYPE)
    USING INDEX 
    TABLESPACE USERS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));



