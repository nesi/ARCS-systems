DROP TABLE ARUN.MATRIX_THREADS;

CREATE TABLE ARUN.MATRIX_THREADS
(
  th_expDate_ck         DATE                    NOT NULL,
  th_threadID_ck        NUMBER(10)              NOT NULL,
  th_statusCode         SMALLINT,
  th_statusDescription  VARCHAR2(100 CHAR),
  th_abortRequested     SMALLINT,
  th_startTime          DATE,
  th_endTime            DATE,
  th_flowType           SMALLINT,
  th_iteration          INT,
  th_lineageCode        VARCHAR2(150 CHAR),
  th_instage            VARCHAR2(150 CHAR)
)

LOGGING 
NOCACHE
NOPARALLEL
NOMONITORING;


ALTER TABLE ARUN.MATRIX_THREADS ADD (
  CONSTRAINT MATRIX_THREADS_PK
 PRIMARY KEY
 (th_expDate_ck, th_threadID_ck));

