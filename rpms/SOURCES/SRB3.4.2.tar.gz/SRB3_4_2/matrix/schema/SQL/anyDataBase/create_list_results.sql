CREATE TABLE ARUN.M_LIST_RESULTS
(
  mlr_thread         NUMBER(10),
  mlr_list_XML       VARCHAR2(1000 CHAR),
  mlr_variable_name  VARCHAR2(50 CHAR),
  mlr_depth          SMALLINT
)

LOGGING 
NOCACHE
NOPARALLEL
NOMONITORING;

COMMENT ON COLUMN ARUN.M_LIST_RESULTS.mlr_thread IS 'references m_threads(pk)';

COMMENT ON COLUMN ARUN.M_LIST_RESULTS.mlr_list_XML IS 'the whole thing is converted to XML';

COMMENT ON COLUMN ARUN.M_LIST_RESULTS.mlr_variable_name IS 'reference';


