drop table MATRIX_THREADS;

create table MATRIX_THREADS (
th_expDate_ck date not null,
th_threadID_ck long not null,
th_statusCode small number

)

commit;
