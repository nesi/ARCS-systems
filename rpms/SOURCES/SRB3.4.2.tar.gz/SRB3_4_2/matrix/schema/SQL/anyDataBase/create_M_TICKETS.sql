CREATE TABLE ARUN.M_TICKETS
(
  mt_expired        DATE,
  mt_ticket_pk      NUMBER(10),
  mt_type           VARCHAR2(15 CHAR),
  mt_start          DATE,
  mt_end            DATE,
  mt_usage          INTEGER,
  mt_parent_ticket  NUMBER(10),
  mt_parent_user    VARCHAR2(15 CHAR),
  mt_organization   VARCHAR2(15 CHAR),
  mt_zone           VARCHAR2(15 CHAR),
  mt_passwd         VARCHAR2(15 CHAR),
  mt_home           VARCHAR2(15 CHAR),
  mt_resource       VARCHAR2(15 CHAR),
  mt_phone          VARCHAR2(15 CHAR),
  mt_email          VARCHAR2(25 CHAR)
)

LOGGING 
NOCACHE
NOPARALLEL
NOMONITORING;


ALTER TABLE ARUN.M_TICKETS ADD (
  CONSTRAINT M_TICKETS_PK
 PRIMARY KEY
 (mt_ticket_pk));

