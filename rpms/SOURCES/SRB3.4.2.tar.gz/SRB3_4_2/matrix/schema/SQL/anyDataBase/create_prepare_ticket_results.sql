CREATE TABLE ARUN.M_PREPARE_TICKET_RESULTS
(
  ptr_thread  NUMBER(10),
  ptr_ticket  NUMBER(10)
)

LOGGING 
NOCACHE
NOPARALLEL
NOMONITORING;

COMMENT ON COLUMN ARUN.M_PREPARE_TICKET_RESULTS.ptr_thread IS 'references m_thread(th_threadid_pk)';

COMMENT ON COLUMN ARUN.M_PREPARE_TICKET_RESULTS.ptr_ticket IS 'references m_tickets(mt_ticket_pk)';


