import java.io.File;

import javax.swing.JPasswordField;
import javax.xml.bind.Marshaller;

import edu.sdsc.matrix.srb.client.DataGridResponse;
import edu.sdsc.matrix.srb.client.FlowStatusResponse;
import edu.sdsc.matrix.srb.client.MatrixClientException;
import edu.sdsc.matrix.srb.client.MatrixRunner;
import edu.sdsc.matrix.srb.client.PrepareTicketStep;
import edu.sdsc.matrix.srb.client.SequentialFlow;
import edu.sdsc.matrix.srb.client.StepStatusResponse;
import edu.sdsc.matrix.srb.util.MatrixUtil;

import org.apache.commons.cli.Options;

/**
	* This class is the first of the three classes that demonstrate the GridTickets in Matrix
	*
	* This class makes a gridflow description in Data Grid Languge (DGL) to Login
			* to the data grid (SRB). Once logged in, the connection (socket) is kept alive
	* to handle further requests until an explicit logout request is received. The
			* advantage here is that individual connections need not be made for the further
			* requests. A TicketID is provided on a valid login as key to be used in future.
	* Any user with this key can use the alive connection from the Matrix server. So, multiple
	* programs could be using the same ticket. Matrix internally has the capability to manage
	* these alive connections (sockets as a connection pool). Matrix can internally restart a
	* connection once SRB servers comeback after a maintenace.
	*
	* Apart from this login/logout "session" paradigm, another pardigm that developers must
	* note is that each DGL request by itself could have multiple SRB statements executed as
	* a "batch" using a single connection. So, if all you need is to execute multiple SRB
	* statemtements, you can do that without doing a login/logout session. Both the "session"
	* concept using tickets and the "batch-ing" of certain requests have their own-advantages.
	* They can be even used together based on your user requirements. As software developers,
	* we need to use the right options for the right requirements
	*
	* 	@author Arun swaran Jagatheesan (arun@sdsc.edu)
	*/
public class Part1_NirvanaLoginExample extends SequentialFlow{

			public Part1_NirvanaLoginExample() throws
					MatrixClientException,javax.xml.soap.SOAPException
                    {
						//// Name the top flow as "outerFlow"
						// add a sequential flow by name loginFlow as a child to the top flow.
						super("outerFlow");
						SequentialFlow loginFlow = new SequentialFlow("LoginFlow");
						this.addChild(loginFlow);
						///////////////// Prepare ticket /////////////
						//the prepare ticket step prepares a session kind of stuff
						// it will return a ticket that can be used to login again.
						// The parameters are stepName, UserInfo and VOInfo
						PrepareTicketStep prepareTicStep = new PrepareTicketStep("prepareTic",
								MatrixRunner.getDefaultUserInfo(), MatrixRunner.getDefaultVO());
						// the ticket could be set valid from  a start date till end date
						// but the default is infinite
						// the ticket could also be set valid for a specifed number of login or usage
						// the default is again infinite. Here, we set the number of usage to 100
						prepareTicStep.setUsageCount(100);
						///////////////// Create collection /////////////
						// This step is added just to illustrate that multiple SRB commands can
						// be combined together as a single batch request (without the need to
						// to use multiple requests or sessions).
						loginFlow.addChild(prepareTicStep);
			}

//=========================== Main method ====================================//

			/* creates and sends a DGRequest containing a CreateDataSetFlow */

			public static void main(String args[]){
						try{
									// run the flow using the Matrix Runner
                                    // Commented Parameters that could be updated if required.
                                    // MatrixRunner.DEFAULT_SERVER = "http://localhost:8090/matrix/receiver";  
                                    PropertiesManager propertiesManager = new PropertiesManager("MATRIX_HOME","conf" +File.separator+ "matrix.properties", 1);
                                    MatrixRunner.DEFAULT_SERVER = propertiesManager.getProperty("server.url");
                                    MatrixRunner.DEFAULT_USER_ID = "admin";
									MatrixRunner.DEFAULT_PASSWORD = "WONTDO123";
									MatrixRunner.DEFAULT_HOMEDIR = "/home/admin.nirvana";
									MatrixRunner.DEFAULT_ORGANIZATION = "nirvana";
									MatrixRunner.DEFAULT_SRB_SERVER = propertiesManager.getProperty("srb.server");
                                    MatrixRunner.DEFAULT_SRB_PORT = Integer.parseInt(propertiesManager.getProperty("srb.port"));
                                    MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = "p125244.5625.disk_vault";
									// MatrixRunner.DEFAULT_DGL_NAME = "LoginExample.dgl";
									// Matrix Runner will run the flow as a synchronous request
									// Will again prompt for input (as the last parameter is set to true)
									
                                    if (MatrixRunner.processCommandLine("Part1_NirvanaLoginExample", args, false,new Options()))
									{
										DataGridResponse dg_res = MatrixRunner.startFlow(new 
												Part1_NirvanaLoginExample(), "synchronous", true);
										// printout the response
										System.out.println("Received Data Grid Acknowledgement from: " +
												MatrixRunner.DEFAULT_SERVER);
										MatrixRunner.printStatusResponse(dg_res);
										FlowStatusResponse fsr = dg_res.getFSR();
										StepStatusResponse ssr = fsr.getSSRbyName("prepareTic");
										System.out.println("The ticketID to use for Part2_NirvanaLoginExample:" + ssr.getPrepareTicketString());
										
										System.out.println("\n You may use the following commands:");
										System.out.println("java Part1a_NirvanaCreateExample -t " +
												ssr.getPrepareTicketString() + " -C <Collection / Container Name> -Y <Data Object Type> (optional)");
										System.out.println("java Part2_NirvanaIngestExample -t " +
												ssr.getPrepareTicketString() + " -I <Ingest FilePath> (optional) -T <Target Collection>");
										System.out.println("java Part3_NirvanaCopyExample -t " +
												ssr.getPrepareTicketString() + " -c <SourceFilePath> -T <Target Collection> -Y <Object Type>");
										System.out.println("java Part4_NirvanaDeleteExample -t "+
												ssr.getPrepareTicketString() + " -d <Source Nirvana SRB Path> -Y <Object Type>");
										System.out.println("java Part5_NirvanaRenameExample -t "+
												ssr.getPrepareTicketString() + " -r <Source Nirvana SRB Path> -N <New Name> -Y <Data Object Type>");
										System.out.println("java Part6_NirvanaLogOutExample -t "+ ssr.getPrepareTicketString()+ " <to logout>");
										System.out.println("java Part7_NirvanaReplicateExample -t "+
												ssr.getPrepareTicketString() + " -r <Source Nirvana SRB Path> -T <Target Resource> -Y <Data Object Type>");
                                        System.out.println("java Part8_NirvanaChangePermissionExample -t "+
                                                ssr.getPrepareTicketString() + " -r <Source Nirvana SRB Path> -U <Target User> -D <Target Domain> -p <Access Control> -Y <Data Object Type>");
                                        System.out.println("java Part9_NirvanaDownloadExample -t "+
                                                ssr.getPrepareTicketString() + " -r <Source Nirvana SRB Path> -Y <Mime ID used to differentiate between attachments>");
                                        System.out.println("java Part10_NirvanaSeekNReadExample -t " +
                                                ssr.getPrepareTicketString() +" -r <Source Nirvana SRB Path> -o <Offset> -l <length> -Y <Mime ID> used to differentiate between attachments>");
                                        System.out.println("java Part11_NirvanaSeekNWriteExample -t " +
                                                ssr.getPrepareTicketString() +" -r <Local FilePath to be Partial Written> -o <Offset> -l <length> -T <Target Collection(optional)> -Y <(optional) Mime ID  used to differentiate between attachments>");
												
									}
						} catch (Exception e){
									e.printStackTrace();
									System.err.println(e.getMessage());
						}
			}

			public static void usage(){
						System.out.println("Usage:");
						System.out.println("java Part1_NirvanaLoginExample");
						System.out.println("use \'java Part1_NirvanaLoginExample --help\' for more options");
						System.exit(1);
			}
}
