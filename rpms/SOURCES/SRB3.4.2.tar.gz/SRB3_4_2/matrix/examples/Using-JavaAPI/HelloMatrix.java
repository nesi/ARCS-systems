import javax.xml.bind.Marshaller;

import edu.sdsc.matrix.srb.client.Collection;
import edu.sdsc.matrix.srb.client.CreateStep;
import edu.sdsc.matrix.srb.client.DataGridResponse;
import edu.sdsc.matrix.srb.client.FlowStatusResponse;
import edu.sdsc.matrix.srb.client.MatrixClientException;
import edu.sdsc.matrix.srb.client.MatrixRunner;
import edu.sdsc.matrix.srb.client.PrepareTicketStep;
import edu.sdsc.matrix.srb.client.SequentialFlow;
import edu.sdsc.matrix.srb.client.Step;
import edu.sdsc.matrix.srb.client.StepStatusResponse;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionGroup;

/**
 * This class is the first of many classes that facilitate the learning process
 * of the Data Grid Language(DGL) and the Matrix Client API.
 *
 * This class makes a gridflow description in Data Grid Languge (DGL) to create
 * a directory and consists of a Flow and a Step.  A Flow can be thought of as a
 * method which may contains any number of Flows and Steps.  A Step can be
 * thought of as a single atomic operation.  The HelloMatrix example contains
 * a single Flow named "outerFlow", which is the top SequentialFlow we are
 * extending in this class, and a single Step called "makeDirStep".  This
 * Step creates a directory.
 *
 * 	@author Mark Tran (mdtran@sdsc.edu)
 */
public class HelloMatrix extends SequentialFlow {

  public HelloMatrix(String COLLECTION_NAME) throws MatrixClientException {
    // Name the top Sequentialflow as "outerFlow" (which we are extending in this class)
    super("outerFlow");
    ///////////////// Single step to create collection /////////////
    Collection testDir = new Collection(COLLECTION_NAME);
    // new CreateStep(name_of_the_step, SRB_object_to_create)
    Step makeTestDirStep = new CreateStep("makeDirStep", testDir);
    // Attach the step to the outerFlow
    super.addChild(makeTestDirStep);
  }

//=============== Execute Flow using Main method =========================//

  /* creates and sends a DGLRequest containing a CreateDataSetFlow */

  private static Marshaller marshaller;

  public static void main(String args[]) {
    String thisClassName = "HelloMatrix";
    try {
      setDefaults();
      // run the flow using the Matrix Runner
      String collectionName = "myTestDirectory";
      if (args.length > 0) collectionName = args[0];
      // Matrix Runner will run the flow as a synchronous request
      // Will again prompt for input (as the last parameter is set to true)
      DataGridResponse dg_res = MatrixRunner.startFlow(new HelloMatrix(
          collectionName),
          "synchronous", true);
      // printout the response
      System.out.println("Received Data Grid Acknowledgement from: " +
                         MatrixRunner.DEFAULT_SERVER);
      MatrixRunner.printStatusResponse(dg_res);
    }
    catch (Exception e) {
      e.printStackTrace();
      System.err.println(e.getMessage());
    }
  }

  public static void setDefaults() {
    //Commented Parameters that could be updated if required.
    MatrixRunner.DEFAULT_SERVER =
        "http://appfarm1.sdsc.edu:8080/matrix/receiver";
    MatrixRunner.DEFAULT_SERVER = "http://localhost:8080/matrix/receiver";
    //MatrixRunner.DEFAULT_USER_ID = "Matrix-demo";
    //MatrixRunner.DEFAULT_PASSWORD = args[0];
    //MatrixRunner.DEFAULT_HOMEDIR = "/home/Matrix-demo.sdsc";
    //MatrixRunner.DEFAULT_ORGANIZATION = "sdsc";
    //MatrixRunner.DEFAULT_SRB_SERVER = "orion.sdsc.edu";
    //MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = "sfs-tape2-dtf";
    //MatrixRunner.DEFAULT_SRB_PORT = 7824;
    //MatrixRunner.DEFAULT_DGL_NAME = "LoginExample.dgl";
  }
}
