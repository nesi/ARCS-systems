import java.io.File;

import edu.sdsc.matrix.srb.client.Collection;
import edu.sdsc.matrix.srb.client.Container;
import edu.sdsc.matrix.srb.client.DataSet;
import edu.sdsc.matrix.srb.client.CreateStep;
import edu.sdsc.matrix.srb.client.DataGridResponse;
//import edu.sdsc.matrix.srb.client.DataSet;
import edu.sdsc.matrix.srb.client.FlowStatusResponse;
import edu.sdsc.matrix.srb.client.MatrixClientException;
import edu.sdsc.matrix.srb.client.MatrixRunner;
import edu.sdsc.matrix.srb.client.SequentialFlow;
import edu.sdsc.matrix.srb.client.Step;
import edu.sdsc.matrix.srb.client.StepStatusResponse;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

/**
	* This class is the first of the three classes that demonstrate the GridTickets in Matrix
	*
	* This class makes a gridflow description in Data Grid Languge (DGL) to Login
			* to the data grid (SRB). Once logged in, the connection (socket) is kept alive
	* to handle further requests until an explicit logout request is received. The
			* advantage here is that individual connections need not be made for the further
			* requests. A TicketID is provided on a valid login as key to be used in future.
	* Any user with this key can use the alive connection from the Matrix server. So, multiple
	* programs could be using the same ticket. Matrix internally has the capability to manage
	* these alive connections (sockets as a connection pool). Matrix can internally restart a
	* connection once SRB servers comeback after a maintenace.
	*
	* Apart from this login/logout "session" paradigm, another pardigm that developers must
	* note is that each DGL request by itself could have multiple SRB statements executed as
	* a "batch" using a single connection. So, if all you need is to execute multiple SRB
	* statemtements, you can do that without doing a login/logout session. Both the "session"
	* concept using tickets and the "batch-ing" of certain requests have their own-advantages.
	* They can be even used together based on your user requirements. As software developers,
	* we need to use the right options for the right requirements
	*
	* 	@author Arun swaran Jagatheesan (arun@sdsc.edu)
	*/
public class Part1a_NirvanaCreateExample extends SequentialFlow{

			public Part1a_NirvanaCreateExample(String NAME, String objectType) throws
					MatrixClientException,javax.xml.soap.SOAPException{
						//// Name the top flow as "outerFlow"
						// add a sequential flow by name loginFlow as a child to the top flow.
						super("outerFlow");
						SequentialFlow loginFlow = new SequentialFlow("LoginFlow");
						this.addChild(loginFlow);
						
						///////////////// Create collection /////////////
						// This step is added just to illustrate that multiple SRB commands can
						// be combined together as a single batch request (without the need to
						// to use multiple requests or sessions).
						
						this.addVariable("NAME",NAME);
						if(objectType.equals("collection"))
						{
							Collection testDir = new Collection("$NAME");
							Step makeTestDirStep = new CreateStep("makeDirStep", testDir);
							loginFlow.addChild(makeTestDirStep);
						}
						else if(objectType.equals("container"))
						{
							Container sourceSet = new Container("$NAME");
							Step makeContainerStep =new CreateStep("makeContainerStep", sourceSet);
							loginFlow.addChild(makeContainerStep);
						}
                        else if(objectType.equals("dataObject"))
                        {
                            DataSet sourceSet = new DataSet("$NAME");
                            Step makeDataSetStep =new CreateStep("makeDataSetStep", sourceSet);
                            loginFlow.addChild(makeDataSetStep);
                        }
			}

//=========================== Main method ====================================//

			/* creates and sends a DGRequest containing a CreateDataSetFlow */
			public static void main(String args[]){
						try{
									// run the flow using the Matrix Runner
                                    PropertiesManager propertiesManager = new PropertiesManager("MATRIX_HOME","conf" +File.separator+ "matrix.properties", 1);
                                    MatrixRunner.DEFAULT_SERVER = propertiesManager.getProperty("server.url");
//                                  MatrixRunner.DEFAULT_SERVER = "http://localhost:8090/matrix/receiver";
//									MatrixRunner.DEFAULT_SERVER = "http://localhost:8080/matrix/receiver";
//									MatrixRunner.DEFAULT_USER_ID = "admin";
//									MatrixRunner.DEFAULT_PASSWORD = "WONTDO123";
//									MatrixRunner.DEFAULT_HOMEDIR = "/home/admin.nirvana";
//									MatrixRunner.DEFAULT_ORGANIZATION = "nirvana";
//									MatrixRunner.DEFAULT_SRB_SERVER = "p125244.nirvanaware.com";
//									MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = "p125244.5625.cache";
//									MatrixRunner.DEFAULT_SRB_PORT = 5625;
//									MatrixRunner.DEFAULT_DGL_NAME = "LoginExample.dgl";
									// Matrix Runner will run the flow as a synchronous request
									// Will again prompt for input (as the last parameter is set to true)
									Options options = new Options();
									options.addOption(new Option("C", "newCollection", true, "New collection/container to create"));
									options.addOption(new Option("Y", "dataObject Type", true, "DataObject type"));
									
									if (MatrixRunner.processCommandLine("Part1a_NirvanaCreateExample", args, false,options))
									{
												if (MatrixRunner.hasOptionInCmdLine('t')&& MatrixRunner.hasOptionInCmdLine('C') && MatrixRunner.hasOptionInCmdLine('Y'))
												{
													String collectionName = MatrixRunner.getCmdLineValue('C');
													String dataObjectType = MatrixRunner.getCmdLineValue('Y');
													DataGridResponse dg_res = MatrixRunner.startFlow(new 
															Part1a_NirvanaCreateExample(collectionName,dataObjectType), "synchronous", false);
													// printout the response
													System.out.println("Received Data Grid Acknowledgement from: " +
															MatrixRunner.DEFAULT_SERVER);
													MatrixRunner.printStatusResponse(dg_res);
													FlowStatusResponse fsr = dg_res.getFSR();
													StepStatusResponse ssr = fsr.getSSRbyName("prepareTic");
													System.out.println("\n You may use the following commands:");
													System.out.println("java Part3_NirvanaCopyExample -t " +
															MatrixRunner.getCmdLineValue('t') + " -c <SourceFilePath> -T <Target Collection> -Y <Object Type>");
													System.out.println("java Part4_NirvanaDeleteExample -t"+
															MatrixRunner.getCmdLineValue('t') + " -d <Source Nirvana SRB Path> -Y <Object Type>");
													System.out.println("java Part5_NirvanaRenameExample -t "+ MatrixRunner.getCmdLineValue('t') + " -r <Source Nirvana SRB Path> -N <New Name> -Y <Data Object Type>");
													System.out.println("java Part7_NirvanaReplicateExample -t "+ MatrixRunner.getCmdLineValue('t') + " -r <Source Nirvana SRB Path> -T <Target Resource> -Y <Data Object Type>");
													System.out.println("java Part6_NirvanaLogOutExample -t "+ MatrixRunner.getCmdLineValue('t')+ " <to logout>");
												} 
												else{
															usage();
												}
									}
						} catch (Exception e){
									e.printStackTrace();
									System.err.println(e.getMessage());
						}
			}

			public static void usage(){
						System.out.println("Usage:");
						System.out.println("java Part1a_NirvanaCreateExample -t ticketID -C <Collection / Container Name> Y <Data Object Type> (optional) -P <Parent Collection>");
						System.out.println("use \'java Part1a_NirvanaCreateExample --help\' for more options");
						System.exit(1);
			}
}