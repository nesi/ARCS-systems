import java.io.File;

import java.io.IOException;

import javax.xml.bind.Marshaller;



import edu.sdsc.matrix.srb.client.Collection;

import edu.sdsc.matrix.srb.client.CreateStep;

import edu.sdsc.matrix.srb.client.DataGridResponse;

import edu.sdsc.matrix.srb.client.DataSet;

import edu.sdsc.matrix.srb.client.IngestDataSetStep;

import edu.sdsc.matrix.srb.client.MatrixRunner;

import edu.sdsc.matrix.srb.client.SequentialFlow;

import edu.sdsc.matrix.srb.client.Step;



import org.apache.commons.cli.Option;

import org.apache.commons.cli.Options;



import edu.sdsc.grid.io.srb.SRBAccount;



/**

	* Demonstrates how to create flows/steps for uploading files into SRB

	* <p>

	* Creates 3 steps:

	* 1 - create a collection for this flow

	* 2 - Ingest a local file (default is this class UploadExamples.class)

	* 3 - Ingest a URL (Google home page)

	* </p>

	* @ author Arun swaran Jagatheesan

	* @ e-mail arun@sdsc.edu

	*/



/* Developer log

	*

	* Original Code: Arun 6/21/05

	*/



public class UploadExamples extends SequentialFlow{



	private static String COLLECTION_NAME = "myCollection";





    public UploadExamples() throws Exception{

		this(COLLECTION_NAME, "UploadExamples.class");

}



	public UploadExamples(String localFileName) throws Exception{

		this(COLLECTION_NAME, localFileName);

}



	public UploadExamples(String COLLECTION, String localFileName) throws

		Exception{



		//////////////////////////////////////////////////

		// SET UP

		/////////////////////////////////////////////////



		// name this flow (the big outer request as "outerFlow")

		super("outerFlow");

		// DGL variables for the collection where the file will be ingested

		this.addVariable("collectionNow", COLLECTION.trim());

		Collection testDir = new Collection("$collectionNow");

		// DGL variables for name of the files (dataSet) to be ingested

		this.addVariable("localIngestName", COLLECTION + "/uploadedFile");

		DataSet localDataSet = new DataSet("$localIngestName");

		this.addVariable("extIngestName", COLLECTION + "/extIngestFile.html");

		DataSet extDataSet = new DataSet("$extIngestName");

		// local file to ingest

		File localFile = new File(localFileName);



		////////// first we make a step to set up a test directory //////

		Step makeTestDirStep = new CreateStep("makeTestDirStep", testDir);



		//////////////////////////////////////////////////////////////////

		// Ingest local file into test directory or collection

		// Look at IngestDataSetStep.java in client package for more usage details

		//////////////////////////////////////////////////////////////////

		// destination dataSet in SRB



		IngestDataSetStep ingestLocalFile = new IngestDataSetStep("ingestLocalFile",

			"MIME-ID-localFile", localDataSet, localFile);

		// overwrite if file already exists (if false, appends at the end).

		ingestLocalFile.allowOverWrite(true);



		//////////////////////////////////////////////////////////////////

		// Ingest external file (URL) into test directory or collection

		// In this example, we ingest the index.html page from google

		// Look at IngestDataSetStep.java in client package for more usage details

		//////////////////////////////////////////////////////////////////

		Step extIngestStep = new IngestDataSetStep("ingestFile",
                        "\"http://www.google.com\"", extDataSet);



		// We are all set now to add each step to this flow (in order

		this.addChild(makeTestDirStep);

		this.addChild(ingestLocalFile);

		this.addChild(extIngestStep);



		// the flow is now ready to be submitted as a request to the Matrix



}



//=========================== Main method ====================================//



	/* creates and sends a DGRequest containing a CreateDataSetFlow */



	private static Marshaller marshaller;



	public static void main(String args[]){

		String thisClassName = "UploadExamples";

		//MatrixRunner.DEFAULT_SERVER = "http://localhost:8080/matrix/receiver";

		try{

			SRBAccount srbAccountToUse = new SRBAccount();

			MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = srbAccountToUse.

				getDefaultStorageResource();

			MatrixRunner.DEFAULT_ORGANIZATION = srbAccountToUse.getDomainName();

			MatrixRunner.DEFAULT_HOMEDIR = srbAccountToUse.getHomeDirectory();

			MatrixRunner.DEFAULT_SRB_SERVER = srbAccountToUse.getHost();

			MatrixRunner.DEFAULT_SRB_PORT = srbAccountToUse.getPort();

			MatrixRunner.DEFAULT_USER_ID = srbAccountToUse.getUserName();

		} catch(IOException ioe){

			System.err.println(

				"SRB Profile not found (MdasEnv and MdasAuth files).");

			System.err.print("You will need to enter your login info manually");

		}

		Options options = new Options();

		try{

			options.addOption(new Option("C", "CollectionName", true,

																		"Name of the new collection for processing"));

			options.addOption(new Option("F", "LocalFile", true,

																		"Local File to upload"));

			if(MatrixRunner.processCommandLine(thisClassName, args, false,

																					options)){

				if(MatrixRunner.hasOptionInCmdLine('C')){

					String collectionName = MatrixRunner.getCmdLineValue('C');

					String localFileName = "UploadExamples.class";

					if(MatrixRunner.hasOptionInCmdLine('F'))

						localFileName = MatrixRunner.getCmdLineValue('F');

					DataGridResponse dg_res = MatrixRunner.startFlow(new

						UploadExamples(collectionName, localFileName),

						"synchronous", true);

					// printout the response

					System.out.println(	"Received Data Grid Acknowledgement from: " +	MatrixRunner.DEFAULT_SERVER);

					MatrixRunner.printStatusResponse(dg_res);

				} else{

					usage(thisClassName);

				}

			}

		} catch(Exception e){

			e.printStackTrace();

			System.err.println(e.getMessage());

		}



}



	public void usage(){

		usage(this.getClass().getName());

}



	public static void usage(String className){

		System.out.println("Usage:");

		System.out.println("java " + className + " -C <CollectionName> -F <Local File to Upload>");

		System.out.println("use \'java " + className +

												" --help\' for more options");

		System.exit(1);

}



}