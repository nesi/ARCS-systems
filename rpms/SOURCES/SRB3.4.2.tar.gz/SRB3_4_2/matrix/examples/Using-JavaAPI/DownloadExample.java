import java.io.File;

import java.io.FileOutputStream;

import java.io.IOException;

import java.util.Iterator;

import javax.activation.DataHandler;

import javax.activation.DataSource;

import javax.xml.bind.Marshaller;

import javax.xml.soap.AttachmentPart;

import javax.xml.soap.SOAPException;


import edu.sdsc.matrix.srb.client.ByteArrayDataSource;

import edu.sdsc.matrix.srb.client.DataGridResponse;

import edu.sdsc.matrix.srb.client.DataSet;

import edu.sdsc.matrix.srb.client.DownloadDataSetStep;

import edu.sdsc.matrix.srb.client.MatrixRunner;

import edu.sdsc.matrix.srb.client.SequentialFlow;

import edu.sdsc.matrix.srb.client.Step;


import org.apache.commons.cli.Option;

import org.apache.commons.cli.Options;


import edu.sdsc.grid.io.srb.SRBAccount;


/**
 * Demonstrates how to create flows/steps for uploading files into SRB
 * <p/>
 * <p/>
 * <p/>
 * Creates 1 step within the flow:
 * <p/>
 * Step 1 - Download a SRB file (as a SOAP attachment)
 * <p/>
 * </p>
 *
 * @ author Arun swaran Jagatheesan
 * @ e-mail arun@sdsc.edu
 */

/* Developer log

    * Original Code: Arun 6/21/05

    */



public class DownloadExample extends SequentialFlow {


    public DownloadExample(String downloadDataSet, String mimeID) {

        //////////////////////////////////////////////////

        // SET UP

        /////////////////////////////////////////////////

        // name this flow (the big outer request as "outerFlow")

        super("outerFlow");

        // DGL variables for the dataset (file) that has to be downloaded

        this.addVariable("downloadFile", downloadDataSet.trim());

        DataSet sourceDataSet = new DataSet("$downloadFile");

        //////////////////////////////////////////////////////////////////

        // Download Step to get the file as a SOAP attachment

        // new DownloadDataSetStep( step_id, dataSource, SOAP-AttachemntMIME-ID)

        //////////////////////////////////////////////////////////////////

        Step downloadStep = new DownloadDataSetStep("downloadStep", sourceDataSet,

                mimeID);

        // We are all set now to the step to this flow (in order

        this.addChild(downloadStep);

        // the flow is now ready to be submitted as a request to the Matrix

    }

//=========================== Main method ====================================//

    /* creates and sends a DGRequest containing a CreateDataSetFlow */


    private static Marshaller marshaller;


    public static void main(String args[]) {

        String thisClassName = "DownloadExample";

        MatrixRunner.DEFAULT_SERVER = "http://localhost:8080/matrix/receiver";

        try {

            SRBAccount srbAccountToUse = new SRBAccount();

            MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = srbAccountToUse.

                    getDefaultStorageResource();

            MatrixRunner.DEFAULT_ORGANIZATION = srbAccountToUse.getDomainName();

            MatrixRunner.DEFAULT_HOMEDIR = srbAccountToUse.getHomeDirectory();

            MatrixRunner.DEFAULT_SRB_SERVER = srbAccountToUse.getHost();

            MatrixRunner.DEFAULT_SRB_PORT = srbAccountToUse.getPort();

            MatrixRunner.DEFAULT_USER_ID = srbAccountToUse.getUserName();

        } catch (IOException ioe) {

            System.err.println(

                    "SRB Profile not found (MdasEnv and MdasAuth files).");

            System.err.print("You will need to enter your login info manually");

        }

        Options options = new Options();

        try {

            options.addOption(new Option("F", "DownloadFile", true,

                    "SRB File to download"));

            if (MatrixRunner.processCommandLine(thisClassName, args, false,

                    options)) {

                if (MatrixRunner.hasOptionInCmdLine('F')) {

                    String fileName = MatrixRunner.getCmdLineValue('F');

                    // run the flow and get data grid response

                    DataGridResponse dg_res = MatrixRunner.startFlow(new

                            DownloadExample(fileName, "myMIME"), "synchronous", true);

                    // printout the response

                    System.out.println("Received Data Grid Acknowledgement from: " +

                            MatrixRunner.DEFAULT_SERVER);

                    MatrixRunner.printStatusResponse(dg_res);

                    // store downloaded attachment into a new file

                    File storedFile = dg_res.storeAttachmentToFile("myMIME", new File("mydownload.ext"));

                    if (storedFile != null) {

                        System.out.println("location of downloaded file" +

                                storedFile.getAbsolutePath());

                    } else {

                        System.out.println("Error in getting file");

                    }

                } else {

                    usage(thisClassName);

                }

            }

        } catch (Exception e) {

            e.printStackTrace();

            System.err.println(e.getMessage());

        }

    }


    public void usage() {

        usage(this.getClass().getName());

    }


    public static void usage(String className) {

        System.out.println("Usage:");

        System.out.println("java " + className + " -F <SRB-FileName> ");

        System.out.println("use \'java " + className +

                " --help\' for more options");

        System.exit(1);

    }

}