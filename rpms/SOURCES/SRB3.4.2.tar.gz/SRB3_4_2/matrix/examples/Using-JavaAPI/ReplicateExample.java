import java.io.File;

import java.io.FileOutputStream;

import java.io.IOException;

import java.util.Iterator;

import javax.activation.DataHandler;

import javax.activation.DataSource;

import javax.xml.bind.Marshaller;

import javax.xml.soap.AttachmentPart;

import javax.xml.soap.SOAPException;



import edu.sdsc.matrix.srb.client.ByteArrayDataSource;

import edu.sdsc.matrix.srb.client.DataGridResponse;

import edu.sdsc.matrix.srb.client.DataSet;

import edu.sdsc.matrix.srb.client.DownloadDataSetStep;

import edu.sdsc.matrix.srb.client.ReplicateStep;

import edu.sdsc.matrix.srb.client.MatrixRunner;

import edu.sdsc.matrix.srb.client.SequentialFlow;

import edu.sdsc.matrix.srb.client.Step;



import org.apache.commons.cli.Option;

import org.apache.commons.cli.Options;



import edu.sdsc.grid.io.srb.SRBAccount;



/**

	* Demonstrates how to create flows/steps for replicating files in SRB datagrid.

	* <p>

	* Creates 1 step within the flow:

	*  Step 1 - Replicate a SRB file that already exists in SRB

	* Assumes that the file is already in SRB. If no file, use the UploadExamples.java, to

	* upload new file into SRB

	* </p>

	* @ author Arun swaran Jagatheesan

	* @ e-mail arun@sdsc.edu

	*/



/* Developer log

	*

	* Original Code: Arun 6/24/05

	*/



public class ReplicateExample extends SequentialFlow{



			public ReplicateExample(String replicateDataSet, String resourceName){

						//////////////////////////////////////////////////

						// SET UP - Input

						/////////////////////////////////////////////////



						// name this flow (the big outer request as "outerFlow")

						super("outerFlow");

						// DGL variables for the dataset (file) that has to be downloaded

						this.addVariable("replicateFile", replicateDataSet.trim());

						if (resourceName != null) resourceName = resourceName.trim();

						this.addVariable("resource", resourceName);

						DataSet sourceDataSet = new DataSet("$replicateFile");





						//////////////////////////////////////////////////////////////////

						// new ReplicateStep( step_id, dataSet, targetResouceName)

						//////////////////////////////////////////////////////////////////

						Step downloadStep = new ReplicateStep("replicateStep", sourceDataSet,

																																																		"$resource");

						// We are all set now to the step to this flow (in order

						this.addChild(downloadStep);

						// the flow is now ready to be submitted as a request to the Matrix

			}



//=========================== Main method ====================================//



			/* creates and sends a DGRequest containing a CreateDataSetFlow */



			private static Marshaller marshaller;



			public static void main(String args[]){

						String thisClassName = "ReplicateExample";

						MatrixRunner.DEFAULT_SERVER = "http://localhost:8080/matrix/receiver";

						try{

									SRBAccount srbAccountToUse = new SRBAccount();

									MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = srbAccountToUse.

											getDefaultStorageResource();

									MatrixRunner.DEFAULT_ORGANIZATION = srbAccountToUse.getDomainName();

									MatrixRunner.DEFAULT_HOMEDIR = srbAccountToUse.getHomeDirectory();

									MatrixRunner.DEFAULT_SRB_SERVER = srbAccountToUse.getHost();

									MatrixRunner.DEFAULT_SRB_PORT = srbAccountToUse.getPort();

									MatrixRunner.DEFAULT_USER_ID = srbAccountToUse.getUserName();

						} catch(IOException ioe){

									System.err.println(

											"SRB Profile not found (MdasEnv and MdasAuth files).");

									System.err.print("You will need to enter your login info manually");

						}

						Options options = new Options();

						try{

									options.addOption(new Option("F", "ReplicateFile", true,

																																						"SRB File to replicated"));

									options.addOption(new Option("R", "ResourceToUse", true,

																																						"SRB Resource to use for Replica"));

									if(MatrixRunner.processCommandLine(thisClassName, args, false,

																																												options)){

												if(MatrixRunner.hasOptionInCmdLine('F')){

															String fileName = MatrixRunner.getCmdLineValue('F');

															String resourceName = MatrixRunner.getCmdLineValue('R');

															// run the flow and get data grid response

															DataGridResponse dg_res = MatrixRunner.startFlow(new

																	ReplicateExample(fileName, resourceName), "synchronous", true);

															// printout the response

															System.out.println("Received Data Grid Acknowledgement from: " +

																																		MatrixRunner.DEFAULT_SERVER);

															MatrixRunner.printStatusResponse(dg_res);

												} else{

															usage(thisClassName);

												}

									}

						} catch(Exception e){

									e.printStackTrace();

									System.err.println(e.getMessage());

						}

			}



			public void usage(){

						usage(this.getClass().getName());

			}



			public static void usage(String className){

						System.out.println("Usage:");

						System.out.println("java " + className + " -F <SRB-FileName> -R <SRB-Resource>");

						System.out.println("use \'java " + className +

																									" --help\' for more options");

						System.exit(1);

			}

}