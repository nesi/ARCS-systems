import java.io.File;

import javax.xml.bind.Marshaller;

import edu.sdsc.matrix.srb.client.Collection;
import edu.sdsc.matrix.srb.client.ReplicateStep;
import edu.sdsc.matrix.srb.client.DataGridResponse;
import edu.sdsc.matrix.srb.client.MatrixClientException;
import edu.sdsc.matrix.srb.client.MatrixRunner;
import edu.sdsc.matrix.srb.client.PrepareTicketStep;
import edu.sdsc.matrix.srb.client.SequentialFlow;
import edu.sdsc.matrix.srb.client.Step;
import edu.sdsc.matrix.srb.client.*;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

/**
	* This class is the second part of the three classes that demonstrate the GridTickets in Matrix
	*
	* This class makes a gridflow description in Data Grid Languge (DGL) to and uses the
	* Login ticket created from Part1. It uses the connection (socket) that was  kept alive
	* from Part1 to handle further requests until an explicit logout request is received. The
			* advantage here is that individual connections need not be made for the further
	* requests. The TicketID provided from Part1 is used to validate.
	* Any user with this key can use the alive connection from the Matrix server. So, multiple
	* programs could be using the same ticket. Matrix internally has the capability to manage
	* these alive connections (sockets as a connection pool). Matrix can internally restart a
	* connection once SRB servers comeback after a maintenace.
	*
	* Apart from this login/logout "session" paradigm, another pardigm that developers must
	* note is that each DGL request by itself could have multiple SRB statements executed as
	* a "batch" using a single connection. So, if all you need is to execute multiple SRB
	* statemtements, you can do that without doing a login/logout session. Both the "session"
	* concept using tickets and the "batch-ing" of certain requests have their own-advantages.
	* They can be even used together based on your user requirements. As software developers,
	* we need to use the right options for the right requirements
	*
	* 	@author Arun swaran Jagatheesan (arun@sdsc.edu)
	*/
public class Part7_NirvanaReplicateExample extends SequentialFlow
{
	public Part7_NirvanaReplicateExample(String sourcePath, String targetResource, String ObjectType) 
	throws MatrixClientException,javax.xml.soap.SOAPException
	{
/////////////    Name the top flow as "outerFlow"
		// add a sequential flow by name CopyFlow as a child to the top flow.
		super("outerFlow");
		SequentialFlow replicateFlow = new SequentialFlow("ReplicateFlow");
		this.addChild(replicateFlow);
		
		this.addVariable("sourceName",sourcePath);
		this.addVariable("targetResource",targetResource);
		
		//Step replicateStep =new ReplicateStep("replicate", "$sourcePath","$targetResource");
		//replicateFlow.addChild(replicateStep);
		
		if(ObjectType.equals("dataObject"))
		{
			System.out.println("inside dataObject");
			DataSet replicateSet = new DataSet("$sourceName");
			Step replicateStep =new ReplicateStep("replicate", replicateSet,"$targetResource");
			replicateFlow.addChild(replicateStep);
		}
		else if(ObjectType.equals("collection"))
		{
			Collection replicateSet = new Collection("$sourceName");
			Step replicateStep =new ReplicateStep("replicate", replicateSet,"$targetResource");
			replicateFlow.addChild(replicateStep);
		}
		else if(ObjectType.equals("container"))
		{
			Container replicateSet = new Container("$sourceName");
			Step replicateStep =new ReplicateStep("replicate", replicateSet,"$targetResource");
			replicateFlow.addChild(replicateStep);
		}
		
		
	}

//=========================== Main method ====================================//

/* creates and sends a DGRequest containing a CreateDataSetFlow */

	private static Marshaller marshaller;
	
	public static void main(String args[])
	{
		String COLLECTION_NAME = "";
		try
		{
		            PropertiesManager propertiesManager = new PropertiesManager("MATRIX_HOME","conf" +File.separator+ "matrix.properties", 1);
		            MatrixRunner.DEFAULT_SERVER = propertiesManager.getProperty("server.url");

//					MatrixRunner.DEFAULT_SERVER = "http://localhost:8090/matrix/receiver";
//					MatrixRunner.DEFAULT_USER_ID = "Matrix-demo";
//					MatrixRunner.DEFAULT_PASSWORD = args[0];
//					MatrixRunner.DEFAULT_HOMEDIR = "/home/Matrix-demo.sdsc";
//					MatrixRunner.DEFAULT_ORGANIZATION = "sdsc";
//					MatrixRunner.DEFAULT_SRB_SERVER = "orion.sdsc.edu";
//					MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = "sfs-tape2-dtf";
//					MatrixRunner.DEFAULT_SRB_PORT = 7824;
//					MatrixRunner.DEFAULT_DGL_NAME = "LoginExample.dgl";
//					MatrixRunner.DEFAULT_ticketID = args[0];
					
					Options options = new Options();
					options.addOption(new Option("r", "replicateDataSet", true, "Source Nirvana SRB Path"));
					options.addOption(new Option("T","Target Resource", true, "Target Resource"));
					options.addOption(new Option("Y", "dataObjectType", true, "Data Object Type"));
					
					if (MatrixRunner.processCommandLine("Part7_NirvanaReplicateExample.java", args, false,options))
					{
								if (MatrixRunner.hasOptionInCmdLine('t')&&
										MatrixRunner.hasOptionInCmdLine('r')&& 
											MatrixRunner.hasOptionInCmdLine('T')&&
											MatrixRunner.hasOptionInCmdLine('Y'))
								{
											// Matrix Runner will run the flow as a synchronous request
											String sourcePath =MatrixRunner.getCmdLineValue('r');
											String targetResource = MatrixRunner.getCmdLineValue('T');
											String type =MatrixRunner.getCmdLineValue('Y');
											
											DataGridResponse dg_res = MatrixRunner.startFlow(new
													Part7_NirvanaReplicateExample(sourcePath,targetResource,type), "synchronous", MatrixRunner.getCmdLineValue('t'), false);
											
											System.out.println("Received Data Grid Acknowledgement from: " +
													MatrixRunner.DEFAULT_SERVER);
											MatrixRunner.printStatusResponse(dg_res);
											
											System.out.println("java Part6_NirvanaLogoutExample -t "+ MatrixRunner.getCmdLineValue('t')+ " <to logout>");

								} 
								else
								{
											usage();
											
								}
					}
		}
		catch (Exception e)
		{
					e.printStackTrace();
					System.err.println(e.getMessage());
		}
		
	}
	
	
	public static void usage()
	{
		System.out.println("Usage:");
		System.out.println("java Part7_NirvanaReplicateExample.java -t <TicketValue> -r <Source Nirvana SRB Path> -T <Target Resource> -Y <Data Object Type>");
		System.out.println("use \'java Part7_NirvanaReplicateExample.java --help\' for more options");
		System.exit(1);
	}
}


