import java.io.IOException;

import javax.xml.bind.Marshaller;

import edu.sdsc.matrix.srb.client.BackupStep;
import edu.sdsc.matrix.srb.client.DataGridResponse;
import edu.sdsc.matrix.srb.client.DataSet;
import edu.sdsc.matrix.srb.client.MatrixRunner;
import edu.sdsc.matrix.srb.client.SequentialFlow;
import edu.sdsc.matrix.srb.client.Step;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import edu.sdsc.grid.io.srb.SRBAccount;

/**
	* Demonstrates how to create flows/steps for backing up files in SRB datagrid.
	* <p>
	* Creates 1 step within the flow:
	*  Step 1 - Backup a SRB file that already exists in SRB
	* Assumes that the file is already in SRB. If no file, use the UploadExamples.java, to
	* upload new file into SRB
	* </p>
	* @ author Adil Hasan
	* @ e-mail A.Hasan@rl.ac.uk
	*/

/* Developer log
	*
	* Copied from Arun's ReplicateExample: Adil Hasan 9/1/05
	* Original Code: Arun 6/24/05
	*/

public class BackupExample extends SequentialFlow{

			public BackupExample(String backupDataSet, String resourceName){
						//////////////////////////////////////////////////
						// SET UP - Input
						/////////////////////////////////////////////////
						// name this flow (the big outer request as "outerFlow")
						super("outerFlow");
						// DGL variables for the dataset (file) that has to be downloaded
						this.addVariable("backupFile", backupDataSet.trim());
						if (resourceName != null)
									resourceName = resourceName.trim();
						this.addVariable("resource", resourceName);
						DataSet sourceDataSet = new DataSet("$backupFile");
						//////////////////////////////////////////////////////////////////
						// new BackupStep( step_id, dataSet, targetResouceName)
						//////////////////////////////////////////////////////////////////
						Step downloadStep = new BackupStep("backupStep", sourceDataSet,
								"$resource");
						// We are all set now to add the step to this flow (in order
						this.addChild(downloadStep);
						// the flow is now ready to be submitted as a request to the Matrix

			}

//=========================== Main method ====================================//

			/* creates and sends a DGRequest containing a CreateDataSetFlow */

			private static Marshaller marshaller;

			public static void main(String args[]){
						String thisClassName = "BackupExample";
						MatrixRunner.DEFAULT_SERVER = "http://localhost:8080/matrix/receiver";
						try{
									SRBAccount srbAccountToUse = new SRBAccount();
									MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = srbAccountToUse.
											getDefaultStorageResource();
									MatrixRunner.DEFAULT_ORGANIZATION = srbAccountToUse.getDomainName();
									MatrixRunner.DEFAULT_HOMEDIR = srbAccountToUse.getHomeDirectory();
									MatrixRunner.DEFAULT_SRB_SERVER = srbAccountToUse.getHost();
									MatrixRunner.DEFAULT_SRB_PORT = srbAccountToUse.getPort();
									MatrixRunner.DEFAULT_USER_ID = srbAccountToUse.getUserName();
						} catch (IOException ioe){
									System.err.println(
											"SRB Profile not found (MdasEnv and MdasAuth files).");
									System.err.print("You will need to enter your login info manually");
						}
						Options options = new Options();
						try{
									options.addOption(new Option("F", "BackupFile", true,
											"SRB File to replicated"));
									options.addOption(new Option("R", "ResourceToUse", true,
											"SRB Resource to use for Replica"));
									if (MatrixRunner.processCommandLine(thisClassName, args, false,
											options)){
												if (MatrixRunner.hasOptionInCmdLine('F')){
															String fileName = MatrixRunner.getCmdLineValue('F');
															String resourceName = MatrixRunner.getCmdLineValue('R');
															// run the flow and get data grid response
															DataGridResponse dg_res = MatrixRunner.startFlow(new
																	BackupExample(fileName, resourceName), "synchronous", true);
															// printout the response
															System.out.println("Received Data Grid Acknowledgement from: " +
																	MatrixRunner.DEFAULT_SERVER);
															MatrixRunner.printStatusResponse(dg_res);
												} else{
															usage(thisClassName);
												}
									}
						} catch (Exception e){
									e.printStackTrace();
									System.err.println(e.getMessage());
						}

			}

			public void usage(){
						usage(this.getClass().getName());

			}

			public static void usage(String className){
						System.out.println("Usage:");
						System.out.println("java " + className + " -F <SRB-FileName> -R <SRB-Resource>");
						System.out.println("use \'java " + className +
								" --help\' for more options");
						System.exit(1);
			}
}