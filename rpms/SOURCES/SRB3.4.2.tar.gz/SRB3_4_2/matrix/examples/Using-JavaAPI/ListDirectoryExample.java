import java.io.IOException;

import javax.xml.bind.Marshaller;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import edu.sdsc.matrix.srb.client.Collection;
import edu.sdsc.matrix.srb.client.CollectionList;
import edu.sdsc.matrix.srb.client.DataGridResponse;
import edu.sdsc.matrix.srb.client.ListStep;
import edu.sdsc.matrix.srb.client.MatrixRunner;
import edu.sdsc.matrix.srb.client.SequentialFlow;
import edu.sdsc.matrix.srb.client.StepStatusResponse;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import edu.sdsc.grid.io.srb.SRBAccount;

/**
	* Creates a  sequential flow with a subflow that lists a collection.
	*
	* @author Arun Jagatheesan
	*/
public class ListDirectoryExample extends SequentialFlow{

			private static final String COLLECTION_NAME_FINAL = "myTestDirArun";

			/**
				* No arg constructor - never used
				*/
			public ListDirectoryExample(){
						this(COLLECTION_NAME_FINAL);
			}

			public ListDirectoryExample(String COLLECTION_NAME){
						// name this flow "outerFlow"; create a DGL variables
						super("outerFlow");
						this.addVariable("collectionNow", COLLECTION_NAME.trim());
						Collection testDir = new Collection("$collectionNow");
						//////////////////// Flow        ///////////////////////////////
						///////////////// list collection /////////////
						SequentialFlow getListingFlow = new SequentialFlow("getListingFlow");
						ListStep getListingStep = new ListStep("getListingStep", testDir);
						// add each step to this flow (in order
						this.addChild(getListingFlow);
						getListingFlow.addChild(getListingStep);

			}

//=========================== Main method ====================================//

			/* creates and sends a DGRequest containing a CreateDataSetFlow */

			//private static Marshaller marshaller;

			public static void main(String args[]){
						String thisClassName = "ListDirectoryExample";
						//MatrixRunner.DEFAULT_SERVER = "http://web4.sdsc.edu:8080/matrix/receiver";
						try{
									SRBAccount srbAccountToUse = new SRBAccount();
									MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = srbAccountToUse.getDefaultStorageResource();
									MatrixRunner.DEFAULT_ORGANIZATION = srbAccountToUse.getDomainName();
									MatrixRunner.DEFAULT_HOMEDIR = srbAccountToUse.getHomeDirectory();
									MatrixRunner.DEFAULT_SRB_SERVER = srbAccountToUse.getHost();
									MatrixRunner.DEFAULT_SRB_PORT = srbAccountToUse.getPort();
									MatrixRunner.DEFAULT_USER_ID = srbAccountToUse.getUserName();
						} catch (IOException ioe){
									System.err.println("SRB Profile not found (MdasEnv and MdasAuth files).");
									System.err.print("You will need to enter your login info manually");
						}
						Options options = new Options();
						try{
									options.addOption(new Option("C", "CollectionName", true,
											"Name of the new collection for processing"));
									if (MatrixRunner.processCommandLine(thisClassName, args, false, options)){
												if (MatrixRunner.hasOptionInCmdLine('C')){
															String collectionName = MatrixRunner.getCmdLineValue('C');
															DataGridResponse dg_res = MatrixRunner.startFlow(new
																	ListDirectoryExample(collectionName), "synchronous", true);
															// printout the response
															System.out.println("Received Data Grid Acknowledgement from: " +
																	MatrixRunner.DEFAULT_SERVER);
															MatrixRunner.printStatusResponse(dg_res);
															//// nithya wants the response on screen ///
															System.out.println("Listing of the Collection:");
															// Get the step that has this response
															StepStatusResponse ssr = dg_res.getFSR().getSSRbyName("getListingStep");
															// get the collection listing from the list result in the step
															CollectionList cls = ssr.getListResult().getListingForClient();
															// get the names of both collections and datasets from this listign
															String[] result = cls.getCollectionAndDataSetNames();
															// print it out on screen
															if (result == null){
																		System.out.println("No listing found for the Collection");
															} else{
																		for (int i = 0; i < result.length; i++){
																					System.out.println("\t" + result[i]);
																		}
																		// print it out in XML (for GEON as requested by vishu)
																		System.out.println("Listing converted to XML:\n");
																		// the marshaller to convert object to XML (heavy duty thing)
																		JAXBContext jc = JAXBContext.newInstance("edu.sdsc.matrix.srb.parser");
																		Marshaller marshaller = jc.createMarshaller();
																		// send this to screen
																		marshaller.marshal(cls,System.out);
															}
												} else{
															usage(thisClassName);
												}
									}
						} catch (Exception e){
									e.printStackTrace();
									System.err.println(e.getMessage());
						}

			}

			public void usage(){
						usage(this.getClass().getName());
			}

			public static void usage(String className){
						System.out.println("Usage:");
						System.out.println("java " + className + " -C <CollectionName> ");
						System.out.println("use \'java " + className + " --help\' for more options");
						System.exit(1);
			}

}