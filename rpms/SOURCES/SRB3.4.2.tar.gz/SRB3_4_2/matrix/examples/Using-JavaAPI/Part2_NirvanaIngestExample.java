import java.io.File;

import javax.xml.bind.Marshaller;

import edu.sdsc.matrix.srb.client.Collection;
import edu.sdsc.matrix.srb.client.CreateStep;
import edu.sdsc.matrix.srb.client.DataGridResponse;
import edu.sdsc.matrix.srb.client.MatrixClientException;
import edu.sdsc.matrix.srb.client.MatrixRunner;
import edu.sdsc.matrix.srb.client.PrepareTicketStep;
import edu.sdsc.matrix.srb.client.SequentialFlow;
import edu.sdsc.matrix.srb.client.Step;
import edu.sdsc.matrix.srb.client.*;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

/**
	* This class is the second part of the three classes that demonstrate the GridTickets in Matrix
	*
	* This class makes a gridflow description in Data Grid Languge (DGL) to and uses the
	* Login ticket created from Part1. It uses the connection (socket) that was  kept alive
	* from Part1 to handle further requests until an explicit logout request is received. The
			* advantage here is that individual connections need not be made for the further
	* requests. The TicketID provided from Part1 is used to validate.
	* Any user with this key can use the alive connection from the Matrix server. So, multiple
	* programs could be using the same ticket. Matrix internally has the capability to manage
	* these alive connections (sockets as a connection pool). Matrix can internally restart a
	* connection once SRB servers comeback after a maintenace.
	*
	* Apart from this login/logout "session" paradigm, another pardigm that developers must
	* note is that each DGL request by itself could have multiple SRB statements executed as
	* a "batch" using a single connection. So, if all you need is to execute multiple SRB
	* statemtements, you can do that without doing a login/logout session. Both the "session"
	* concept using tickets and the "batch-ing" of certain requests have their own-advantages.
	* They can be even used together based on your user requirements. As software developers,
	* we need to use the right options for the right requirements
	*
	* 	@author Arun swaran Jagatheesan (arun@sdsc.edu)
	*/
public class Part2_NirvanaIngestExample extends SequentialFlow
{

			public Part2_NirvanaIngestExample(String ingestFilePath, String targetCollection) 
				throws MatrixClientException,javax.xml.soap.SOAPException
				{
						//////////////    Name the top flow as "outerFlow"
						// add a sequential flow by name DemoTicketUseFlow as a child to the top flow.
						super("outerFlow");
						SequentialFlow ingestFlow = new SequentialFlow("IngestFlow");
						this.addChild(ingestFlow);
						String file = ingestFilePath.substring(ingestFilePath.lastIndexOf("\\") + 1);
						/**
                        System.out.println("file -> " +file);
                        String fileName = file.substring(0,file.lastIndexOf("."));
						System.out.println("fileName -> " +fileName);
						
						String fileType = file.substring(file.lastIndexOf(".") + 1);
						System.out.println("fileType -> " +fileType);
						*/
						if(!targetCollection.equals(""))
							file = targetCollection+"/"+file;
						
						super.addVariable("fileName",file);
						
						DataSet dataSet = new DataSet("$fileName");
						//DataSet dataSet = new DataSet(fileNameVar);
						Step ingestStep = new IngestDataSetStep("ingestFile","attachment1",dataSet,ingestFilePath);
											
						// wrap up
						// attach ingestStep
						ingestFlow.addChild(ingestStep);

			}

//=========================== Main method ====================================//

			/* creates and sends a DGRequest containing a CreateDataSetFlow */

			public static void main(String args[])
            {
						try{
									// run the flow using the Matrix Runner
//									MatrixRunner.DEFAULT_SERVER = "http://localhost:8090/matrix/receiver";
                                    PropertiesManager propertiesManager = new PropertiesManager("MATRIX_HOME","conf" +File.separator+ "matrix.properties", 1);
                                    MatrixRunner.DEFAULT_SERVER = propertiesManager.getProperty("server.url");
//									MatrixRunner.DEFAULT_USER_ID = "Matrix-demo";
//									MatrixRunner.DEFAULT_PASSWORD = args[0];
//									MatrixRunner.DEFAULT_HOMEDIR = "/home/Matrix-demo.sdsc";
//									MatrixRunner.DEFAULT_ORGANIZATION = "sdsc";
//									MatrixRunner.DEFAULT_SRB_SERVER = "orion.sdsc.edu";
//									MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = "sfs-tape2-dtf";
//									MatrixRunner.DEFAULT_SRB_PORT = 7824;
//									MatrixRunner.DEFAULT_DGL_NAME = "LoginExample.dgl";
//									MatrixRunner.DEFAULT_ticketID = args[0];
									Options options = new Options();
									options.addOption(new Option("I", "ingestFilePath", true, "FilePath to be ingested"));
									options.addOption(new Option("T", "targetCollection", true, "Full / Relative path of Target Collection"));
									
									if (MatrixRunner.processCommandLine("Part2_NirvanaIngestExample", args, false,options))
									{
												if (MatrixRunner.hasOptionInCmdLine('I') &&
														MatrixRunner.hasOptionInCmdLine('t')){
															// Matrix Runner will run the flow as a synchronous request
																			
															String filePath =MatrixRunner.getCmdLineValue('I');
															String ticketID= MatrixRunner.getCmdLineValue('t');
															String targetCollection ="";
															if(MatrixRunner.hasOptionInCmdLine('T'))
															{
																targetCollection =MatrixRunner.getCmdLineValue('T');
															}
															DataGridResponse dg_res = MatrixRunner.startFlow(new
																	Part2_NirvanaIngestExample(filePath,targetCollection), "synchronous", ticketID, false);
															
															System.out.println("Received Data Grid Acknowledgement from: " +
																	MatrixRunner.DEFAULT_SERVER);
															MatrixRunner.printStatusResponse(dg_res);
															
															System.out.println("\n You may use the following commands:");
															System.out.println("java Part3_NirvanaCopyExample -t " +
																	MatrixRunner.getCmdLineValue('t') + " -c <SourceFilePath> -T <Target Collection> -Y <Object Type>");
															System.out.println("java Part4_NirvanaDeleteExample -t"+
																	MatrixRunner.getCmdLineValue('t') + " -d <Source Nirvana SRB Path> -Y <Object Type>");
															System.out.println("java Part5_NirvanaRenameExample -t "+ MatrixRunner.getCmdLineValue('t') + " -r <Source Nirvana SRB Path> -N <New Name> -Y <Data Object Type>");
															System.out.println("java Part7_NirvanaReplicateExample -t "+ MatrixRunner.getCmdLineValue('t') + " -r <Source Nirvana SRB Path> -T <Target Resource> -Y <Data Object Type>");
															System.out.println("java Part6_NirvanaLogoutExample -t "+ MatrixRunner.getCmdLineValue('t')+ " <to logout>");
												} 
												else
												{
															usage();
															
												}
									}
						} catch (Exception e){
									e.printStackTrace();
									System.err.println(e.getMessage());
						}
			}

			public static void usage(){
						System.out.println("Usage:");
						System.out.println("java Part2_NirvanaIngestExample -t <TicketValue> -I <Ingest FilePath> (optional) -T <Target Collection> ");
						System.out.println("use \'java Part2_NirvanaIngestExample --help\' for more options");
						System.exit(1);
			}
}