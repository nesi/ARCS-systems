import java.io.File;

import edu.sdsc.matrix.srb.client.DataGridResponse;
import edu.sdsc.matrix.srb.client.MatrixClientException;
import edu.sdsc.matrix.srb.client.MatrixRunner;
import edu.sdsc.matrix.srb.client.SequentialFlow;
import edu.sdsc.matrix.srb.client.Step;
import edu.sdsc.matrix.srb.client.*;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

/**
	* *
	* 	@author Ravi Sathish (ravi.sathish@GA.com)
	*/
public class Part10_NirvanaSeekNReadExample extends SequentialFlow
{
	public Part10_NirvanaSeekNReadExample(String sourcePath, String offset,String length,String mimeID) 
	throws MatrixClientException,javax.xml.soap.SOAPException
	{
	    /////////////    Name the top flow as "outerFlow"
		// add a sequential flow by name ChangePermissionFlow as a child to the top flow.
		super("outerFlow");
		SequentialFlow downloadFlow = new SequentialFlow("SeekNRead");
		this.addChild(downloadFlow);
		
		this.addVariable("sourceName",sourcePath);
        DataSet partialReadSet = new DataSet("$sourceName");
        Step seekNReadStep = new SeekNReadStep("SeekNRead", partialReadSet, offset,length,mimeID);
        downloadFlow.addChild(seekNReadStep);
    }
//=========================== Main method ====================================//

/* creates and sends a DGRequest containing a CreateDataSetFlow */

	
	public static void main(String args[])
	{
		try
		{
		            PropertiesManager propertiesManager = new PropertiesManager("MATRIX_HOME","conf" +File.separator+ "matrix.properties", 1);
		            MatrixRunner.DEFAULT_SERVER = propertiesManager.getProperty("server.url");
//					MatrixRunner.DEFAULT_SERVER = "http://localhost:8090/matrix/receiver";
//					MatrixRunner.DEFAULT_USER_ID = "Matrix-demo";
//					MatrixRunner.DEFAULT_PASSWORD = args[0];
//					MatrixRunner.DEFAULT_HOMEDIR = "/home/Matrix-demo.sdsc";
//					MatrixRunner.DEFAULT_ORGANIZATION = "sdsc";
//					MatrixRunner.DEFAULT_SRB_SERVER = "orion.sdsc.edu";
//					MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = "sfs-tape2-dtf";
//					MatrixRunner.DEFAULT_SRB_PORT = 7824;
//					MatrixRunner.DEFAULT_DGL_NAME = "LoginExample.dgl";
//					MatrixRunner.DEFAULT_ticketID = args[0];
					
					Options options = new Options();
					options.addOption(new Option("s", "sourceDataPath", true, "Source Nirvana SRB Path"));
                    options.addOption(new Option("o", "offset", true, "Source Nirvana SRB Path"));
                    options.addOption(new Option("l", "length", true, "Source Nirvana SRB Path"));
					options.addOption(new Option("Y", "Target MimeID", true, "Target MimeID"));
                    
					if (MatrixRunner.processCommandLine("Part10_NirvanaSeekNReadExample", args, false,options))
					{
								if (MatrixRunner.hasOptionInCmdLine('t')&& MatrixRunner.hasOptionInCmdLine('r') &&
                                        MatrixRunner.hasOptionInCmdLine('o') && MatrixRunner.hasOptionInCmdLine('l') && 
                                        MatrixRunner.hasOptionInCmdLine('Y'))
								{
											// Matrix Runner will run the flow as a synchronous request
											String sourcePath = MatrixRunner.getCmdLineValue('r');
											String mimeID = MatrixRunner.getCmdLineValue('Y');
                                            String offset = MatrixRunner.getCmdLineValue('o');
                                            String length = MatrixRunner.getCmdLineValue('l');
											DataGridResponse dg_res = MatrixRunner.startFlow(new 
                                                    Part10_NirvanaSeekNReadExample(sourcePath,offset,length,mimeID), "synchronous", MatrixRunner.getCmdLineValue('t'), false);
											
											System.out.println("Received Data Grid Acknowledgement from: " +
													MatrixRunner.DEFAULT_SERVER);
											MatrixRunner.printStatusResponse(dg_res);
											
											System.out.println("java Part6_NirvanaLogoutExample -t "+ MatrixRunner.getCmdLineValue('t')+ " <to logout>");
								} 
								else
								{
											usage();
											
								}
					}
		}
		catch (Exception e)
		{
					e.printStackTrace();
					System.err.println(e.getMessage());
		}
		
	}
	
	
	public static void usage()
	{
		System.out.println("Usage:");
		System.out.println("java Part10_NirvanaSeekNReadExample -t <TicketValue> -r <Source Nirvana SRB Path> -o <Offset> -l <length> -Y <Mime ID> used to differentiate between attachments>");
		System.out.println("use \'java Part10_NirvanaSeekNReadExample --help\' for more options");
		System.exit(1);
	}
}


