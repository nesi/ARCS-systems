import java.io.File;

import javax.xml.bind.Marshaller;

import edu.sdsc.matrix.srb.client.Collection;
import edu.sdsc.matrix.srb.client.CopyStep;
import edu.sdsc.matrix.srb.client.DataGridResponse;
import edu.sdsc.matrix.srb.client.MatrixClientException;
import edu.sdsc.matrix.srb.client.MatrixRunner;
import edu.sdsc.matrix.srb.client.PrepareTicketStep;
import edu.sdsc.matrix.srb.client.SequentialFlow;
import edu.sdsc.matrix.srb.client.Step;
import edu.sdsc.matrix.srb.client.*;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

/**
	* This class is the second part of the three classes that demonstrate the GridTickets in Matrix
	*
	* This class makes a gridflow description in Data Grid Languge (DGL) to and uses the
	* Login ticket created from Part1. It uses the connection (socket) that was  kept alive
	* from Part1 to handle further requests until an explicit logout request is received. The
			* advantage here is that individual connections need not be made for the further
	* requests. The TicketID provided from Part1 is used to validate.
	* Any user with this key can use the alive connection from the Matrix server. So, multiple
	* programs could be using the same ticket. Matrix internally has the capability to manage
	* these alive connections (sockets as a connection pool). Matrix can internally restart a
	* connection once SRB servers comeback after a maintenace.
	*
	* Apart from this login/logout "session" paradigm, another pardigm that developers must
	* note is that each DGL request by itself could have multiple SRB statements executed as
	* a "batch" using a single connection. So, if all you need is to execute multiple SRB
	* statemtements, you can do that without doing a login/logout session. Both the "session"
	* concept using tickets and the "batch-ing" of certain requests have their own-advantages.
	* They can be even used together based on your user requirements. As software developers,
	* we need to use the right options for the right requirements
	*
	* 	@author Arun swaran Jagatheesan (arun@sdsc.edu)
	*/
public class Part5_NirvanaRenameExample extends SequentialFlow
{

			public Part5_NirvanaRenameExample(String sourcePath, String newName, String ObjectType) 
				throws MatrixClientException,javax.xml.soap.SOAPException
				{
						//////////////    Name the top flow as "outerFlow"
						// add a sequential flow by name CopyFlow as a child to the top flow.
						super("outerFlow");
						SequentialFlow renameFlow = new SequentialFlow("DeleteFlow");
						this.addChild(renameFlow);
						
						super.addVariable("sourceName",sourcePath);
						super.addVariable("newName",newName);
						
						if(ObjectType.equals("dataObject"))
						{
							System.out.println("inside dataObject");
							DataSet renameSet = new DataSet("$sourceName");
							Step renameStep =new RenameStep("rename", renameSet,"$newName");
							renameFlow.addChild(renameStep);
						}
						else if(ObjectType.equals("collection"))
						{
							Collection renameSet = new Collection("$sourceName");
							Step renameStep =new RenameStep("rename", renameSet,"$newName");
							renameFlow.addChild(renameStep);
						}
						else if(ObjectType.equals("container"))
						{
							Container renameSet = new Container("$sourceName");
							Step renameStep =new RenameStep("rename", renameSet,"$newName");
							renameFlow.addChild(renameStep);
						}
						
			}

//=========================== Main method ====================================//

			/* creates and sends a DGRequest containing a CreateDataSetFlow */

			private static Marshaller marshaller;

			public static void main(String args[])
			{
						String COLLECTION_NAME = "";
						try
						{
                                    PropertiesManager propertiesManager = new PropertiesManager("MATRIX_HOME","conf" +File.separator+ "matrix.properties", 1);
                                    MatrixRunner.DEFAULT_SERVER = propertiesManager.getProperty("server.url");
//									MatrixRunner.DEFAULT_SERVER = "http://localhost:8090/matrix/receiver";
//									MatrixRunner.DEFAULT_USER_ID = "Matrix-demo";
//									MatrixRunner.DEFAULT_PASSWORD = args[0];
//									MatrixRunner.DEFAULT_HOMEDIR = "/home/Matrix-demo.sdsc";
//									MatrixRunner.DEFAULT_ORGANIZATION = "sdsc";
//									MatrixRunner.DEFAULT_SRB_SERVER = "orion.sdsc.edu";
//									MatrixRunner.DEFAULT_DEFAULT_STORAGE_RESOURCE = "sfs-tape2-dtf";
//									MatrixRunner.DEFAULT_SRB_PORT = 7824;
//									MatrixRunner.DEFAULT_DGL_NAME = "LoginExample.dgl";
//									MatrixRunner.DEFAULT_ticketID = args[0];
									
									Options options = new Options();
									options.addOption(new Option("r", "renameDataSet", true, "Source Nirvana SRB Path"));
									options.addOption(new Option("N", "newName", true, "New Name"));
									options.addOption(new Option("Y", "dataObjectType", true, "Data Object Type"));
									
									if (MatrixRunner.processCommandLine("Part5_NirvanaRenameExample", args, false,options))
									{
												if (MatrixRunner.hasOptionInCmdLine('t')&&
														MatrixRunner.hasOptionInCmdLine('r')&& 
															MatrixRunner.hasOptionInCmdLine('N')&&
															MatrixRunner.hasOptionInCmdLine('Y'))
												{
															// Matrix Runner will run the flow as a synchronous request
															String sourcePath =MatrixRunner.getCmdLineValue('r');
															String newName = MatrixRunner.getCmdLineValue('N');
															String type =MatrixRunner.getCmdLineValue('Y');
															
															DataGridResponse dg_res = MatrixRunner.startFlow(new
																	Part5_NirvanaRenameExample(sourcePath,newName,type), "synchronous", MatrixRunner.getCmdLineValue('t'), false);
															
															System.out.println("Received Data Grid Acknowledgement from: " +
																	MatrixRunner.DEFAULT_SERVER);
															MatrixRunner.printStatusResponse(dg_res);
															System.out.println("java Part6_NirvanaLogoutExample -t "+ MatrixRunner.getCmdLineValue('t')+ " <to logout>");

												} 
												else
												{
															usage();
															
												}
									}
						}
						catch (Exception e){
									e.printStackTrace();
									System.err.println(e.getMessage());
						}
			}

			public static void usage(){
						System.out.println("Usage:");
						System.out.println("java Part5_NirvanaRenameExample -t <TicketValue> -r <Source Nirvana SRB Path> -N <New Name> -Y <Data Object Type>");
						System.out.println("use \'java Part5_NirvanaRenameExample --help\' for more options");
						System.exit(1);
			}
}