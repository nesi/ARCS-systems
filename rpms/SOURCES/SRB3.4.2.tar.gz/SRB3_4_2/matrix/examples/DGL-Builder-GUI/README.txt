SDSC Matrix Project
~~~~~~~~~~~~~~~~~~~

This directory contains some examples.The examples illustrate the use of the Data Grid Language (DGL) in the Grid Workflow (GridFlow) Management


The DGL document can be created using an XML editor like (XML Spy), programmatically using the JAVA API, or using a Graphical User Interface customized for the end-user environment.


This directory "DGL-Builder-GUI" is supposed to house the customizable GUI for end users to prepare, save and execute DGL requests. The DGL builder ideally could be customized for each project, with domain specific flows. This would be available in version 3.3. 
If you are interested in participating with DGL-Builder (as projects would like this), please e-mail talk2matrix@sdsc.edu. 

