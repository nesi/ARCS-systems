Hooray, you are the right place to get started with the Matrix Gridflow Managment System.

There is no documentation or google help. The only way to run this is by contacting srb-chat@sdsc.edu or arun@sdsc.edu


We help you with this thing - dont get frustrated. We have done this before for SRB and can do it again - helping our users start with a new software.
    i
