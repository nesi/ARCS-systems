/*
	* 	SDSC Matrix. A Gridflow Management System for data grids and digtal libraries
	*  Copyright (C) 2004 SDSC Matrix Project
	*
	* This library is free software; you can redistribute it and/or
	* modify it under the terms of the GNU Lesser General Public
	* License as published by the Free Software Foundation; either
	* version 2.1 of the License, or (at your option) any later version.
	*
	* This library is distributed in the hope that it will be useful,
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	*	Lesser General Public License for more details.
	*
	*	You should have received a copy of the GNU Lesser General Public
	*	License along with this library; if not, write to the Free Software
	*	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	*
	* ====================================================================
	*
	* This software consists of voluntary contributions from the developers of the SDSC
	* Matrix Project. We request that all redistribution and software made using this code
	* acknowledge their use of the �SDSC Matrix project� in their end-user documentation or
	* in their website.
	*
	* SDSC Matrix Project (list of developers as of Dec 2005)
	*	Designer & Architect: Arun swaran Jagatheesan (arun@sdsc.edu)
	* 9500 Gilman Drive, MC0505
	* San Diego Supercomputer Center
	* University of California
	* La Jolla CA 92093
	*
	* Allen Ding (alding@sdsc.edu)
	* Lucas Gilbert (iktome@sdsc.edu)
	* Arun Jagatheesan (arun@sdsc.edu)
	* Reena Mathew	(rmathew@sdsc.edu)
	* Daniel Moore (mixx@umail.ucsb.edu)
	* Erik Vandekieft (evk@sdsc.edu)
	* Jonathan Weinberg (jonw@sdsc.edu)
	*
	*/
package edu.sdsc.matrix.srb.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/*
	* Developer Log: Collection.java
	* Added getDataSetList() 6/17/05 Arun
	* Added getCollections(), getCollectionsNames(), getDatSetFullNmae() 6/17/05 Arun
	* Added getDataSetExtendedList() and corresponding imports 06/17/05 - ARun
	* Formatting 06/16/05 - Arun
	* Created on July 7, 2003, 3:43 AM - Allen Ding
	*/

public class CollectionList extends edu.sdsc.matrix.srb.parser.impl.CollectionListImpl{

			public CollectionList(edu.sdsc.matrix.srb.parser.CollectionList collectionList){
						if (collectionList.getStdCollectionList() != null){
									this.setStdCollectionList(new StdCollectionList(collectionList.getStdCollectionList()));
						}else{
									this.setStdCollectionList(null);
						}
						if (collectionList.getCollectionListReference() != null){
									// references are used only by the system and not in the clientside developer API
									this.setCollectionListReference( new VariableReference( collectionList.getCollectionListReference()));
						}
			}

			public CollectionList(String reference){
						VariableReference var = new VariableReference(reference);
						this.setCollectionListReference(var);
			}

			public CollectionList(StdCollectionList std){
						this.setStdCollectionList(std);
			}

			/**
				* Gets the DataSetExtendedList from Collection list
				* <p>
				* DataSetExtendedList is supposed to be a list of datasets. It is supposed have
				* additional information including canRead(), canWrite, allAccessI() etc. But, in the
				* current matrix implementation this is not provided. It is just a list of datasets.
				* Even then this is provided for future compatibility. For now, you may wish to directly
				* get the list of data sets (or strings of the datasets).
				* </p>
				* @return  list of DataSetExtendedList (null if not present)
				*/
			public List getDataSetExtendedList(){
						if (getStdCollectionList() == null){
									return null;
						} else{
									if (getStdCollectionList().getDataSets() == null){
												return null;
									} else{
												ArrayList alist = new ArrayList(getStdCollectionList().getDataSets().size());
												for (Iterator iter = getStdCollectionList().getDataSets().iterator(); iter.hasNext(); ){
															alist.add(new DataSetExtendedList((edu.sdsc.matrix.srb.parser.DataSetExtendedList)
																	iter.next()));
												}
												return alist;
									}
						}
			}

			/**
				* Gets the list of DataSets that are present in this collection listing
				* <p>
				* </p>
				* @return  list of DataSets (null if this is a reference)
				*/
			public List getDataSetList(){
						List extList = this.getDataSetExtendedList();
						if (extList == null){
									return null;
						} else{
									ArrayList alist = new ArrayList(extList.size());
									for (Iterator iter = extList.iterator(); iter.hasNext(); ){
												alist.add(( (DataSetExtendedList) iter.next()).getDataSetUnWrapped());
									}
									return alist;
						}
			}

			/**
				* Gets the list of all Collections that are present in this collection listing
				* <p>
				* </p>
				* @return  list of Collection (null if this is reference)
				*/
			public List getCollections(){
						if (getStdCollectionList() == null){
									return null;
						} else{
									if (this.getStdCollectionList().getCollections() == null){
												return null;
									} else{
												ArrayList alist = new ArrayList( this.getStdCollectionList().getCollections().size());
												for (Iterator iter = this.getStdCollectionList().getCollections().iterator(); iter.hasNext(); ){
															alist.add( new Collection( (edu.sdsc.matrix.srb.parser.Collection) iter.next()));
												}
												return alist;
									}
						}
			}

			/**
				* Gets the list of all Collection Names (as strings) that are present in this collection listing
				* <p>
				* </p>
				* @return  String array of Collections in this listing (null if this is reference)
				*/
			public String[] getCollectionsNames(){
						if (getStdCollectionList() == null){
									return null;
						} else{
									if (this.getStdCollectionList().getCollections() == null){
												return null;
									} else{
												String[] slist = new String[this.getStdCollectionList().getCollections().size()];
												int i = 0;
												for (Iterator iter = this.getStdCollectionList().getCollections().iterator(); iter.hasNext();i++ ){
															slist [i] = ( new Collection( (edu.sdsc.matrix.srb.parser.Collection) iter.next())).getName();
												}
												return slist;
									}
						}
			}

			/**
				* Gets the list of Full names (paths) of the data sets that are present in this collection listing
				* <p>
				*
				* </p>
				* @return  String array of fullpath names of datasets (null if not present)
				*/
			public String[] getDataSetFullNames(){
						List extList = this.getDataSetExtendedList();
						if (extList == null){
									return null;
						} else{
									String[] slist = new String[extList.size()];
									int i = 0;
									for (Iterator iter = extList.iterator(); iter.hasNext(); i++ ){
												slist [i] = ( (DataSetExtendedList) iter.next()).getFullName();
									}
									return slist;
						}
			}

			/**
				* Get string array with names of all collections and data sets in this collection listing
				* @return string array of collections and datasets in this colection listing
				*/

			public String[] getCollectionAndDataSetNames(){
						return getCollectionAndDataSetNames(0);
			}

			/**
				* Get string array with names of all collections and data sets in this collection listing
				*  <P> The output array can be sorted based on the ordering mentioned. Currenly no order supported
				* </p>
				* @param order ordering of the combined string 0 = random order.
				* @return string array of collections and datasets in this colection listing
				*/
			public String[] getCollectionAndDataSetNames(int order){
						int reqSize = 0;
						String[] colArray = this.getCollectionsNames();
						String[] dasArray = this.getDataSetFullNames();
						if (colArray == null){
						// ignore
						toLog("Collection array = null");
						} else{
									reqSize += colArray.length;
						}
						if (dasArray == null){
						// ignore
												toLog("dataset array = null");
						} else{
									reqSize += dasArray.length;
						}
						if (reqSize == 0){
									return new String[] {};
						} else{
									String[] retArray = new String[reqSize];
									int colArrayLength = 0;
									if (colArray != null){
												colArrayLength = colArray.length;
												System.arraycopy(colArray, 0, retArray, 0, colArrayLength);
									}
									if (dasArray != null){
												System.arraycopy(dasArray, 0, retArray, colArrayLength, dasArray.length);
									}
									return retArray;
						}
			}

			protected static void toLog(String s){
			System.out.println(s);
			}
}