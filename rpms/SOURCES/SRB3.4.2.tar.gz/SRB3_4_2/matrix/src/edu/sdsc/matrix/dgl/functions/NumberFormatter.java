/*
	* 	SDSC Matrix. A Gridflow Management System for data grids and digtal libraries
	*  Copyright (C) 2004 SDSC Matrix Project
	*
	* This library is free software; you can redistribute it and/or
	* modify it under the terms of the GNU Lesser General Public
	* License as published by the Free Software Foundation; either
	* version 2.1 of the License, or (at your option) any later version.
	*
	* This library is distributed in the hope that it will be useful,
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	*	Lesser General Public License for more details.
	*
	*	You should have received a copy of the GNU Lesser General Public
	*	License along with this library; if not, write to the Free Software
	*	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	*
	* ====================================================================
	*
	* This software consists of voluntary contributions from the developers of the SDSC
	* Matrix Project. We request that all redistribution and software made using this code
	* acknowledge their use of the �SDSC Matrix project� in their end-user documentation or
	* in their website.
	*
	* SDSC Matrix Project (list of developers as of Dec 2005)
	*	Designer & Architect: Arun swaran Jagatheesan (arun@sdsc.edu)
	* 9500 Gilman Drive, MC0505
	* San Diego Supercomputer Center
	* University of California
	* La Jolla CA 92093
	*
	* Allen Ding (alding@sdsc.edu)
	* Lucas Gilbert (iktome@sdsc.edu)
	* Arun Jagatheesan (arun@sdsc.edu)
	* Reena Mathew	(rmathew@sdsc.edu)
	* Daniel Moore (mixx@umail.ucsb.edu)
	* Erik Vandekieft (evk@sdsc.edu)
	* Jonathan Weinberg (jonw@sdsc.edu)
	*
	*/

package edu.sdsc.matrix.dgl.functions;

import java.text.DecimalFormat;
import java.util.Stack;

import org.nfunk.jep.function.PostfixMathCommand;
import org.nfunk.jep.ParseException;

/**
	* JEP function to format numbers based on user-defined pattern.
	* Formats the number based on the pattern and outputs its as a string on the stack
	*
	* Refer http://java.sun.com/docs/books/tutorial/i18n/format/decimalFormat.html for defining patterns
	*/

/* Developer log
* Orignial Code by Arun Jagatheesan 6/2/05
*/

public class NumberFormatter extends PostfixMathCommand {

			public NumberFormatter(){
						numberOfParameters = 2;
			}

			public void run(Stack inStack) throws ParseException {
						// check the stack
						checkStack(inStack);
						// get the parameters from the stack
						// second parameter will be poped first from stack
						Object patternO = inStack.pop();
						Object numberO = inStack.pop();
						String pattern = "";
						String result = "";
						if (patternO instanceof String){
									pattern = (String)patternO;
						}else{
									throw new ParseException("Expected String as pattern in NumberFormatter. Found "+patternO.toString());
						}

						if(numberO instanceof Number){
														//System.out.println("Number"+((Number)numberO).doubleValue());
														result = customFormat(pattern, ((Number)numberO).doubleValue());
						}else{
								try{
											double d =  (Double.valueOf(numberO.toString())).doubleValue();
											result = customFormat(pattern, d);
								}catch(NumberFormatException nfe){
											throw new ParseException("Can not format "+numberO.toString());
								}
						}
						inStack.push(result);
			}

			static private String customFormat(String pattern, double value ) {
						DecimalFormat myFormatter = new DecimalFormat(pattern);
						return myFormatter.format(value);
			}
}