/*
	* 	SDSC Matrix. A Gridflow Management System for data grids and digtal libraries
	*  Copyright (C) 2004 SDSC Matrix Project
	*
	* This library is free software; you can redistribute it and/or
	* modify it under the terms of the GNU Lesser General Public
	* License as published by the Free Software Foundation; either
	* version 2.1 of the License, or (at your option) any later version.
	*
	* This library is distributed in the hope that it will be useful,
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	*	Lesser General Public License for more details.
	*
	*	You should have received a copy of the GNU Lesser General Public
	*	License along with this library; if not, write to the Free Software
	*	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	*
	* ====================================================================
	*
	* This software consists of voluntary contributions from the developers of the SDSC
	* Matrix Project. We request that all redistribution and software made using this code
	* acknowledge their use of the �SDSC Matrix project� in their end-user documentation or
	* in their website.
	*
	* SDSC Matrix Project (list of developers as of Dec 2005)
	*	Designer & Architect: Arun swaran Jagatheesan (arun@sdsc.edu)
	* 9500 Gilman Drive, MC0505
	* San Diego Supercomputer Center
	* University of California
	* La Jolla CA 92093
	*
	* Allen Ding (alding@sdsc.edu)
	* Lucas Gilbert (iktome@sdsc.edu)
	* Arun Jagatheesan (arun@sdsc.edu)
	* Reena Mathew	(rmathew@sdsc.edu)
	* Daniel Moore (mixx@umail.ucsb.edu)
	* Erik Vandekieft (evk@sdsc.edu)
	* Jonathan Weinberg (jonw@sdsc.edu)
	*
	*/

package edu.sdsc.matrix.srb.client;

/**
	* Create a step to Rename or Move a data grid object usign DGL
	* <p>
	* Rename a collection or data set. Can also be considered as logical move. THis
	* does not physically move a data set or collection. It just renames at the MCAT.
	* </p>
	* @author  Jon Weinberg, Arun Jagatheesan
	*/

/* Developer Log: RenameStep.java
	*
	* All Java docs 6/24/05 Arun
	* Arun's formatting 6/24/05 Arun
	* Original code: Jon Weinberg
	*/
public class RenameStep extends Step{

			/**
				* RenameStep to renames the collection to a new name
				* @param collection The collection to rename
				* @param newName The new name for the collection
				*/
			public RenameStep(String id, Collection collection, String newName){
						super(id, new Operation(new RenameOp(collection, newName)));
			}

			/**
				* RenameStep to renaming dataset name to a new name
				* @param dataset The dataset to rename
				* @param newName The new name for the collection
				*/
			public RenameStep(String id, DataSet dataSet, String newName){
						super(id, new Operation(new RenameOp(dataSet, newName)));
			}

			/**
				* RenameStep renaming the container name to a new name.
				* @param container The container to rename
				* @param newName The new name for the collection
				*/
			public RenameStep(String id, Container container, String newName){
						super(id, new Operation(new RenameOp(container, newName)));
			}

			// not so useful constructors...
			public RenameStep(String id, RenameParams stdParams){
						super(id, new Operation(new RenameOp(stdParams)));
			}

			public RenameStep(String id, ParamList flexParams){
						super(id, new Operation(new RenameOp(flexParams)));
			}

			public RenameStep(String id, StdDatagridObject dataObject, String newName){
						super(id, new Operation(new RenameOp(dataObject, newName)));
			}

}