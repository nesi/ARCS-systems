/*
	* 	SDSC Matrix. A Gridflow Management System for data grids and digtal libraries
	*  Copyright (C) 2004 SDSC Matrix Project
	*
	* This library is free software; you can redistribute it and/or
	* modify it under the terms of the GNU Lesser General Public
	* License as published by the Free Software Foundation; either
	* version 2.1 of the License, or (at your option) any later version.
	*
	* This library is distributed in the hope that it will be useful,
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	*	Lesser General Public License for more details.
	*
	*	You should have received a copy of the GNU Lesser General Public
	*	License along with this library; if not, write to the Free Software
	*	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	*
	* ====================================================================
	*
	* This software consists of voluntary contributions from the developers of the SDSC
	* Matrix Project. We request that all redistribution and software made using this code
	* acknowledge their use of the �SDSC Matrix project� in their end-user documentation or
	* in their website.
	*
	* SDSC Matrix Project (list of developers as of Dec 2005)
	*	Designer & Architect: Arun swaran Jagatheesan (arun@sdsc.edu)
	* 9500 Gilman Drive, MC0505
	* San Diego Supercomputer Center
	* University of California
	* La Jolla CA 92093
	*
	* Allen Ding (alding@sdsc.edu)
	* Lucas Gilbert (iktome@sdsc.edu)
	* Arun Jagatheesan (arun@sdsc.edu)
	* Reena Mathew	(rmathew@sdsc.edu)
	* Daniel Moore (mixx@umail.ucsb.edu)
	* Erik Vandekieft (evk@sdsc.edu)
	* Jonathan Weinberg (jonw@sdsc.edu)
	*
	*/

package edu.sdsc.matrix.srb.client;

import java.io.IOException;
import java.io.File;
import javax.xml.soap.SOAPException;

/**
	* DownloadDataSetStep used in DGL to download datasets from grid
	* <p>
	* Contains methods to create DownloadDataSetOp objects. Download from SRB
	* could be either done as an attachment or to an external URL (e.g) FTP url.
	* <br>
	* Multiple files can be downloaded using a single DGL flow request. When
	* downloading as an attahment to a local client (local system), each donload
	* is uniquely identified using an ID that is supplied by the user.
	* </p>
	* @author  Allen Ding, Arun Jagatheesan
	*/

/*
	* DownloadDataSetStep.java
	*
	* Original Code 6/21/05  Arun
	*/

public class SeekNWriteStep extends Step{

			/**
			RAVI: added a new Step for SeekNRead, Dec 01 2005	
            */
            public SeekNWriteStep(String id, DataSet dataSet, String offset, String length, String fileName,String contentMIMEID) throws SOAPException
            {
                        super(id, new Operation(new SeekNWriteOp(dataSet, offset, length, fileName,contentMIMEID)));
            }
			public SeekNWriteStep(String id, DataSet dataSet, String offset, String length, String contentMIMEID)
            {
						super(id, new Operation(new SeekNWriteOp(dataSet, offset, length, contentMIMEID)));
			}

            public SeekNWriteStep(String id, DataSet dataSet, String offset, String length)
            {
                        super(id, new Operation(new SeekNWriteOp(dataSet, offset, length)));
            }

			// not of much use to API user
			public SeekNWriteStep(String id, SeekNWriteParams stdParams){
						super(id, new Operation(new SeekNWriteOp(stdParams)));
			}

			//not of much to API user
			public SeekNWriteStep(String id, ParamList flexParams){
						super(id, new Operation(new SeekNWriteOp(flexParams)));
			}

}