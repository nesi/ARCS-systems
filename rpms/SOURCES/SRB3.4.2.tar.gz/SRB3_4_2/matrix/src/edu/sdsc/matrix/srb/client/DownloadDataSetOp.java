/*
	* 	SDSC Matrix. A Gridflow Management System for data grids and digtal libraries
	*  Copyright (C) 2004 SDSC Matrix Project
	*
	* This library is free software; you can redistribute it and/or
	* modify it under the terms of the GNU Lesser General Public
	* License as published by the Free Software Foundation; either
	* version 2.1 of the License, or (at your option) any later version.
	*
	* This library is distributed in the hope that it will be useful,
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	*	Lesser General Public License for more details.
	*
	*	You should have received a copy of the GNU Lesser General Public
	*	License along with this library; if not, write to the Free Software
	*	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	*
	* ====================================================================
	*
	* This software consists of voluntary contributions from the developers of the SDSC
	* Matrix Project. We request that all redistribution and software made using this code
	* acknowledge their use of the �SDSC Matrix project� in their end-user documentation or
	* in their website.
	*
	* SDSC Matrix Project (list of developers as of Dec 2005)
	*	Designer & Architect: Arun swaran Jagatheesan (arun@sdsc.edu)
	* 9500 Gilman Drive, MC0505
	* San Diego Supercomputer Center
	* University of California
	* La Jolla CA 92093
	*
	* Allen Ding (alding@sdsc.edu)
	* Lucas Gilbert (iktome@sdsc.edu)
	* Arun Jagatheesan (arun@sdsc.edu)
	* Reena Mathew	(rmathew@sdsc.edu)
	* Daniel Moore (mixx@umail.ucsb.edu)
	* Erik Vandekieft (evk@sdsc.edu)
	* Jonathan Weinberg (jonw@sdsc.edu)
	*
	*/

/*
	* DownloadDataSetOp.java
	*
	* Arun's formatting, java docs 6/21/05 - Arun
	* Created on July 9, 2003, 3:52 AM - Allen Ding
	*/
package edu.sdsc.matrix.srb.client;

/**
	* DownloadDataSetOp Object used in DGL to download datasets from grid
	* <p>
	* Contains methods to create DownloadDataSetOp objects. Download from SRB
	* could be either done as an attachment or to an external URL (e.g) FTP url.
	* <br>
	* Multiple files can be downloaded using a single DGL flow request. When
	* downloading as an attahment to a local client (local system), each donload
	* is uniquely identified using an ID that is supplied by the user.
	* </p>
	* @author  Allen Ding, Arun Jagatheesan
	*/

public class DownloadDataSetOp extends edu.sdsc.matrix.srb.parser.impl.
		DownloadDataSetOpImpl{

			public DownloadDataSetOp(edu.sdsc.matrix.srb.parser.DownloadDataSetOp op){
						if (op.getStdParams() != null)
									this.setStdParams(new DownloadDataSetParams(op.getStdParams()));
						else if (op.getFlexParams() != null)
									this.setFlexParams(new ParamList(op.getFlexParams()));
			}

			/**
				* Creates a DownloadDataSetOp
				* <P>
				* Multiple files can be downloaded using a single DGL flow request. When
				* downloading as an attahment to a local client (local system), each download
				* is uniquely identified using an MIME ID that is supplied by the user.
				* </P>
				* @param dataSource file to download from datagrid
				* @param mime name to be used to identify the downloaded dime
				*/
			public DownloadDataSetOp (DataSet dataSource, String mime){
						this.setStdParams(	new DownloadDataSetParams(dataSource, mime));
			}

			/**
				* Creates a DownloadDataSetOp
				* <P>
				* Download dataset to a URL that is specified
				* </P>
				* @param dataSource file to download from datagrid
				* @param mime name to be used to identify the downloaded dime
				*/
			public DownloadDataSetOp(DataSet dataSource, String url, UserInfo externalUser){
						this.setStdParams(	new DownloadDataSetParams(dataSource, url, externalUser));
				}



			/**
				* Creates a new DownloadDataSetOp object using DownloadDataSetParams.
				* @param stdParams DownloadDataSet Parameters.
				*/
			public DownloadDataSetOp(DownloadDataSetParams stdParams){
						super.setStdParams(stdParams);
			}

			/**
				* Creates a new DownloadDataSetOp object using flexParams.
				* @param flexParams Flex Parameters.
				*/
			public DownloadDataSetOp(ParamList flexParams){
						super.setFlexParams(flexParams);
			}

			/**
				* Makes the DownloadDataSetOp use the specified DownloadDataSetParams. Using this
				* method clobbers any flexParams paremeter.
				* @param stdParams A DownloadDataSetParams.
				*/
			public void useStdParams(DownloadDataSetParams stdParams){
						super.setFlexParams(null);
						super.setStdParams(stdParams);
			}

			/**
				* Makes the DownloadDataSetOp use the specified ParamList. Using this
				* method clobbers any stdParams parameter.
				* @param flexParams A ParamList.
				*/
			public void useFlexParams(ParamList flexParams){
						super.setStdParams(null);
						super.setFlexParams(flexParams);
			}
}