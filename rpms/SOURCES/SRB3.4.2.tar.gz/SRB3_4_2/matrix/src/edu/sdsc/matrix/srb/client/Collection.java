/*
	* 	SDSC Matrix. A Gridflow Management System for data grids and digtal libraries
	*  Copyright (C) 2004 SDSC Matrix Project
	*
	* This library is free software; you can redistribute it and/or
	* modify it under the terms of the GNU Lesser General Public
	* License as published by the Free Software Foundation; either
	* version 2.1 of the License, or (at your option) any later version.
	*
	* This library is distributed in the hope that it will be useful,
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	*	Lesser General Public License for more details.
	*
	*	You should have received a copy of the GNU Lesser General Public
	*	License along with this library; if not, write to the Free Software
	*	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	*
	* ====================================================================
	*
	* This software consists of voluntary contributions from the developers of the SDSC
	* Matrix Project. We request that all redistribution and software made using this code
	* acknowledge their use of the �SDSC Matrix project� in their end-user documentation or
	* in their website.
	*
	* SDSC Matrix Project (list of developers as of Dec 2005)
	*	Designer & Architect: Arun swaran Jagatheesan (arun@sdsc.edu)
	* 9500 Gilman Drive, MC0505
	* San Diego Supercomputer Center
	* University of California
	* La Jolla CA 92093
	*
	* Allen Ding (alding@sdsc.edu)
	* Lucas Gilbert (iktome@sdsc.edu)
	* Arun Jagatheesan (arun@sdsc.edu)
	* Reena Mathew	(rmathew@sdsc.edu)
	* Daniel Moore (mixx@umail.ucsb.edu)
	* Erik Vandekieft (evk@sdsc.edu)
	* Jonathan Weinberg (jonw@sdsc.edu)
	*
	*/

/*
	* Collection.java
	*
	* Added getName() and Arun's formating 6/16/05 Arun
	* Created on July 7, 2003, 3:43 AM Allen Ding
	*/
package edu.sdsc.matrix.srb.client;

public class Collection extends edu.sdsc.matrix.srb.parser.impl.CollectionImpl{

			public Collection(edu.sdsc.matrix.srb.parser.Collection collection){
						if (collection.getStdCollection() != null)
									this.setStdCollection(new StdCollection(collection.getStdCollection()));
						if (collection.getCollectionReference() != null)
									this.setCollectionReference(new VariableReference(collection.getCollectionReference()));
						if (collection.getAnyDirectory() != null)
									this.setAnyDirectory(new ParamList(collection.getAnyDirectory()));
			}

			/**
				* creates a collection with the given name as dataIdentifier
				* @param name String
				*/
			public Collection(String name){
						initCollection(name, false);
			}

			/**
				* If isReference, creates this collection as a reference to the given name
				* otherwise, creates a collection with the given name as dataIdentifier
				* @param name String
				* @param isReference boolean
				*/
			public Collection(String name, boolean isReference){
						initCollection(name, isReference);
			}

			private void initCollection(String name, boolean isReference){
						if (isReference){
									VariableReference var = new VariableReference(name);
									this.setCollectionReference(var);
						} else
									this.setStdCollection(new StdCollection(name));
			}

			public Collection(edu.sdsc.matrix.srb.parser.StdCollection stdCollection){
						this.setStdCollection(stdCollection);
			}

			public Collection(ParamList paramList){
						this.setAnyDirectory(paramList);
			}

			/**
				* Get the name of the collection represented by this DGL object
				* @return Name of the collection (null if this is not a collection but a reference)
				*/
			public String getName(){
						if (this.getStdCollection() == null){
									return null;
						}else{
									return this.getStdCollection().getCollectionName();
						}
			}

}