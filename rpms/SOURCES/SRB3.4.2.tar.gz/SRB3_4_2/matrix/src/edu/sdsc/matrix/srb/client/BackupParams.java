/*
	* 	SDSC Matrix. A Gridflow Management System for data grids and digtal libraries
	*  Copyright (C) 2004 SDSC Matrix Project
	*
	* This library is free software; you can redistribute it and/or
	* modify it under the terms of the GNU Lesser General Public
	* License as published by the Free Software Foundation; either
	* version 2.1 of the License, or (at your option) any later version.
	*
	* This library is distributed in the hope that it will be useful,
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	*	Lesser General Public License for more details.
	*
	*	You should have received a copy of the GNU Lesser General Public
	*	License along with this library; if not, write to the Free Software
	*	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	*
	* ====================================================================
	*
	* This software consists of voluntary contributions from the developers of the SDSC
	* Matrix Project. We request that all redistribution and software made using this code
	* acknowledge their use of the �SDSC Matrix project� in their end-user documentation or
	* in their website.
	*
	* SDSC Matrix Project (list of developers as of Dec 2005)
	*	Designer & Architect: Arun swaran Jagatheesan (arun@sdsc.edu)
	* 9500 Gilman Drive, MC0505
	* San Diego Supercomputer Center
	* University of California
	* La Jolla CA 92093
	*
	* Adil Hasan (A.Hasan@rl.ac.uk)
	* Allen Ding (alding@sdsc.edu)
	* Lucas Gilbert (iktome@sdsc.edu)
	* Arun Jagatheesan (arun@sdsc.edu)
	* Reena Mathew	(rmathew@sdsc.edu)
	* Daniel Moore (mixx@umail.ucsb.edu)
	* Erik Vandekieft (evk@sdsc.edu)
	* Jonathan Weinberg (jonw@sdsc.edu)
	*
	*/

/*
	* BackupParams.java
	*
	* Created on Sept 1, 2005, Adil Hasan
	* 	*/
package edu.sdsc.matrix.srb.client;

/**
	* Contains methods to create BackupParams objects. You may wish to directly use
	* BackupStep
	* @author  Adil Hasan, Allen Ding, Arun Jagatheesan
	*/
public class BackupParams extends edu.sdsc.matrix.srb.parser.impl.
		BackupOpParamsImpl{

			/**
				* Creates a BackupParams object with the <b>required</b> dataSource
				* parameter.
				* <p>
				* If no target resource is specified, the default storage resource provided
				* while logging in is used.
				* </p>
				* @param dataSource The data source.
				*/
			public BackupParams(StdDatagridObject dataSource){
						super.setDatagridObject(dataSource);
			}

			/**
				* Creates a ReplicateParams object that can be used to replicate the DataGridObject
				* to the specified resource. Replicas are copies of the same data on a different resource
				* Unlike just being physical copies in the data grid, they ensure data integrity if
				* original is lost and can also enhance performance if the original copy has higher latency
				* <p>
				* If target resource is null, the default storage resource provided
				* while logging in is used.
				* </p>
				* @param dataSource The data source object that needs to be replicated
				* @param targetResource Target resource where the data needs to be replicated
				*/
			public BackupParams(StdDatagridObject dataSource, Resource targetResource){
						super.setDatagridObject(dataSource);
						super.setResource(targetResource);
			}

			/**
				* Creates a ReplicateParams object that can be used to replicate the DataGridObject
				* to the specified resource. Replicas are copies of the same data on a different resource
				* Unlike just being physical copies in the data grid, they ensure data integrity if
				* original is lost and can also enhance performance if the original copy has higher latency
				* <p>
				* If target resource is null, the default storage resource provided
				* while logging in is used.
				* </p>
				* @param dataSource The data source object that needs to be replicated
				* @param targetResource Name of target resource where the data needs to be replicated
				*/

			public BackupParams(StdDatagridObject dataSource, String targetResource){
						super.setDatagridObject(dataSource);
						if (targetResource != null) super.setResource(new Resource(targetResource));
			}

}