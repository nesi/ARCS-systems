/*
	* 	SDSC Matrix. A Gridflow Management System for data grids and digtal libraries
	*  Copyright (C) 2004 SDSC Matrix Project
	*
	* This library is free software; you can redistribute it and/or
	* modify it under the terms of the GNU Lesser General Public
	* License as published by the Free Software Foundation; either
	* version 2.1 of the License, or (at your option) any later version.
	*
	* This library is distributed in the hope that it will be useful,
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	*	Lesser General Public License for more details.
	*
	*	You should have received a copy of the GNU Lesser General Public
	*	License along with this library; if not, write to the Free Software
	*	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	*
	* ====================================================================
	*
	* This software consists of voluntary contributions from the developers of the SDSC
	* Matrix Project. We request that all redistribution and software made using this code
	* acknowledge their use of the �SDSC Matrix project� in their end-user documentation or
	* in their website.
	*
	* SDSC Matrix Project (list of developers as of Dec 2005)
	*	Designer & Architect: Arun swaran Jagatheesan (arun@sdsc.edu)
	* 9500 Gilman Drive, MC0505
	* San Diego Supercomputer Center
	* University of California
	* La Jolla CA 92093
	*
	* Allen Ding (alding@sdsc.edu)
	* Lucas Gilbert (iktome@sdsc.edu)
	* Arun Jagatheesan (arun@sdsc.edu)
	* Reena Mathew	(rmathew@sdsc.edu)
	* Daniel Moore (mixx@umail.ucsb.edu)
	* Erik Vandekieft (evk@sdsc.edu)
	* Jonathan Weinberg (jonw@sdsc.edu)
	*
	*/

/*
	* Deverloper Log: DataSetExtendedList.java
	*
	* Formatting, documentation for class 6/17/05 Arun
	* Created on August 25, 2003, 11:28 AM
	*/
package edu.sdsc.matrix.srb.client;

/**
	* Represents the DataSetExtendedList in DGL and the operations that can be performed on this.
	* <p>
	* DataSetExtendedList is supposed to be a list of datasets. It is supposed have
	* additional information including canRead(), canWrite, allAccessI() etc. But, in the
	* current matrix implementation this is not provided. It is just a list of datasets.
	* Even then this is provided for future compatibility. For now, you may wish to directly
	* get the list of data sets (or strings of the datasets).
	* </p>
	* @author  allen
	*/
public class DataSetExtendedList extends edu.sdsc.matrix.srb.parser.impl.
		DataSetExtendedListImpl{
			protected DataSetExtendedList(edu.sdsc.matrix.srb.parser.
					DataSetExtendedList datasetEL){
						super.setDataSet(new DataSet(datasetEL.getDataSet()));
						super.setCanRead(datasetEL.isCanRead());
						super.setCanWrite(datasetEL.isCanWrite());
						super.setAllAccess(datasetEL.isAllAccess());
			}

			/**
				* Gets the dataset extended (or wrapped) by this class
				* <p>
				* Use this method to get the dataset. The method getDataSet() will return also return
				* DataSet. But, it is of type parser.DataSet (which is not that useful).
				* </p>
				* @return DataSet
				*/
			public DataSet getDataSetUnWrapped(){
						return new DataSet(super.getDataSet());
			}

			/**
				* Get the full logical name of this dataset
				* <p>
				* Get the dataset full name by appending it logicaLocation and identifier.
				* </p>
				* @return Full path name of this dataset. Returns null if this does not represent a dataset
				*/
			public String getFullName(){
						return this.getDataSetUnWrapped().getFullName();
			}
}