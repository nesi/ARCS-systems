package edu.sdsc.matrix.dgl.functions;

import java.util.Stack;

import org.nfunk.jep.ParseException;
import org.nfunk.jep.function.PostfixMathCommand;

public class StartsWith extends PostfixMathCommand{
			public StartsWith(){
						numberOfParameters = 2;
			}

			public void run(Stack inStack) throws ParseException{
						// check the stack
						checkStack(inStack);
						// get the parameter from the stack
						// the query is the second parameter, so it is popped first
						String queryString = (String) inStack.pop();
						String searchString = (String) inStack.pop();
						int i = searchString.startsWith(queryString) ? 1 : 0;
						inStack.push(new Double(i));
			}
}