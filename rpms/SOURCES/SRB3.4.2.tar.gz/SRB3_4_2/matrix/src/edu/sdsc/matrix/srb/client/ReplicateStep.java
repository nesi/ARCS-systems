/*
	* 	SDSC Matrix. A Gridflow Management System for data grids and digtal libraries
	*  Copyright (C) 2004 SDSC Matrix Project
	*
	* This library is free software; you can redistribute it and/or
	* modify it under the terms of the GNU Lesser General Public
	* License as published by the Free Software Foundation; either
	* version 2.1 of the License, or (at your option) any later version.
	*
	* This library is distributed in the hope that it will be useful,
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	*	Lesser General Public License for more details.
	*
	*	You should have received a copy of the GNU Lesser General Public
	*	License along with this library; if not, write to the Free Software
	*	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	*
	* ====================================================================
	*
	* This software consists of voluntary contributions from the developers of the SDSC
	* Matrix Project. We request that all redistribution and software made using this code
	* acknowledge their use of the �SDSC Matrix project� in their end-user documentation or
	* in their website.
	*
	* SDSC Matrix Project (list of developers as of Dec 2005)
	*	Designer & Architect: Arun swaran Jagatheesan (arun@sdsc.edu)
	* 9500 Gilman Drive, MC0505
	* San Diego Supercomputer Center
	* University of California
	* La Jolla CA 92093
	*
	* Allen Ding (alding@sdsc.edu)
	* Lucas Gilbert (iktome@sdsc.edu)
	* Arun Jagatheesan (arun@sdsc.edu)
	* Reena Mathew	(rmathew@sdsc.edu)
	* Daniel Moore (mixx@umail.ucsb.edu)
	* Erik Vandekieft (evk@sdsc.edu)
	* Jonathan Weinberg (jonw@sdsc.edu)
	*
	*/

package edu.sdsc.matrix.srb.client;

/**
	* Creates a step to replicate a StdDatagridObject (Collection, DataSet or Container).
	*  <p>
	* Creates a ReplicateParams object that can be used to replicate the DataGridObject
	* to the specified resource. Replicas are copies of the same data on a different resource
	* Unlike just being physical copies in the data grid, they ensure data integrity if
	* original is lost and can also enhance performance if the original copy has higher latency
	* If target resource is null, the default storage resource provided
	* while logging in is used.
	* </p>
	* @author  Allen Ding, Arun Jagatheesan
	*/

	/* Developer log: ReplicateStep.java
		*
		* java docs additional constructor, this developer log 6/24/05 Arun
		* Almost rewrote the class after changes in DGL
		* Origianal Code: Jon
		*/

public class ReplicateStep extends Step{

				/**
					* Replicate a collection's datsets (files) in a new resource
					* @param id DGL Identifier for this step
					* @param collection Name oft collection to replicate
					* @param targetResource the target resource to replicate
					*/
			public ReplicateStep(String id, Collection collection, String targetResource)	{
						super(id, new Operation(new ReplicateOp(new StdDatagridObject(collection), targetResource)));
			}

			/**
				* Replicate a dataset in new resource
				* @param id DGL Identifier for this step
				* @param dataSet Name of the dataset (full path)
				* @param targetResource name of the target resource
				*/
			public ReplicateStep(String id, DataSet dataSet, String targetResource){
						super(id, new Operation(new ReplicateOp(new StdDatagridObject(dataSet), targetResource)));
			}

			public ReplicateStep(String id, Container container, String targetResource){
						super(id, new Operation(new ReplicateOp(new StdDatagridObject(container), targetResource)));
			}

			// not so useful steps just for compliance
			public ReplicateStep(String id, ReplicateParams stdParams){
						super(id, new Operation(new ReplicateOp(stdParams)));
			}

			public ReplicateStep(String id, ParamList flexParams){
						super(id, new Operation(new ReplicateOp(flexParams)));
			}
}