
use DBI;

$db_handle;

sub connectDB {
    $db_handle = DBI->connect ( "DBI:mysql:host=localhost;database=project_id", "srb", "somepassword" )
	 or die "<FONT COLOR=\"red\">ERROR! Cannot connect to database: $DBI::errstr</FONT><P>\n";
    return;
}

sub disconnectDB {
    $db_handle->disconnect();
    return;
}

#
# Incoming argument : month
#
sub month2Num {
    my ($month) = @_;

    if ( $month eq "January" ) {
	return "1";

    } elsif ( $month eq "February" ) {
	return "2";

    } elsif ( $month eq "March" ) {
	return "3";

    } elsif ( $month eq "April" ) {
	return "4";

    } elsif ( $month eq "May" ) {
	return "5";

    } elsif ( $month eq "June" ) {
	return "6";

    } elsif ( $month eq "July" ) {
	return "7";

    } elsif ( $month eq "August" ) {
	return "8";

    } elsif ( $month eq "September" ) {
	return "9";

    } elsif ( $month eq "October" ) {
	return "10";

    } elsif ( $month eq "November" ) {
	return "11";

    } elsif ( $month eq "December" ) {
	return "12";

    } else {
	return 0;
    }
}

#
# Incoming arguments : month, day, year
#
sub mysqlDate {
    my ( $month, $day, $year ) = @_;
    #print "month = $month, day = $day, year = $year<P>\n";

    if ( $year eq "(unknown)" ) {
	return "";

    } elsif ( $month eq "(unknown)" ) {
	return "$year-00-00";

    } elsif ( $day eq "(unknown)" ) {
	my $new_month = month2Num ( $month );
	return "$year-$new_month-00";

    } else {
	my $new_month = month2Num ( $month );
	return "$year-$new_month-$day";
    }

}

#
# Incoming arguments : table name, project id (must be int), one or
# more string values
#
sub insert {
    my $table = shift ( @_ );
    my $value = shift ( @_ );
    my $statement = "INSERT INTO $table VALUES ( $value";
    for my $value ( @_ ) {
	$statement = $statement . ", \"$value\"";
    }
    $statement = $statement . " \)";
    #print "statement = $statement<P>\n";
    $statement_handle = $db_handle->prepare_cached ( $statement );
    $statement_handle->execute()
	or die "<FONT COLOR=\"red\">ERROR! Cannot add new entry to datase: $DBI::$errstr</FONT><P>\n";
    return;
}

#
# Incoming arguments :
#	table - the table to query
#	where_clause - a condition to satisfy
#	order_clause - a field to sort on
#
sub query {
    my ( $table, $where_clause, $order_clause ) = @_;
    my $statement = "SELECT * FROM $table $where_clause $order_clause";
    my $statement_handle = $db_handle->prepare ( "$statement" )
	or die "<FONT COLOR=\"red\">ERROR! Cannot prepare the query '$statement': $DBI::$errstr</FONT><P>\n";
    $statement_handle->execute()
	or die "<FONT COLOR=\"red\">ERROR! Cannot query the $table table: $DBI::$errstr</FONT><P>\n";
    
    return $statement_handle;
}

sub getLastID {
    my $statement_handle = $db_handle->prepare ( "SELECT MAX\(id\) FROM project" )
	or die "<FONT COLOR=\"red\">ERROR! Cannot prepare project ID query: $DBI::$errstr</FONT><P>\n";
    $statement_handle->execute()
	or die "<FONT COLOR=\"red\">ERROR! Cannot query the $table table: $DBI::$errstr</FONT><P>\n";
    my @data = $statement_handle->fetchrow_array();
    return $data[0];
}

