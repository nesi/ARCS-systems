#!/usr/bin/perl
################################################################################
## AccountAdmin.cgi
##   by Tim Warnock, Roman Olschanowsky
##
##   SRB Account Admin page
################################################################################

## Required libraries
require "../htdocs/includes/portaldb.inc";

################################################################################
## (optional) Add a SRB user
################################################################################
my $reqid = $cgi->param('ADDUSER');
my $username  = $cgi->param('USERNAME');
my $first_name = $cgi->param('FIRST_NAME');
my $last_name = $cgi->param('LAST_NAME');
my $gpopid = $cgi->param('g_id');
my $phone = $cgi->param('PHONE');
my $email = $cgi->param('EMAIL');
my $message = $cgi->param('email');
my $comments = $cgi->param('COMMENTS');
my @request = portalSQLRef("select * from gpop where gpopid = $gpopid");
my $req = $request[0];
my $domain = $req->{'domain'};
my $institution = $req->{'institution'};
my @pass = portalSQLRef("select decode(passwd,'andthisisthekey') as pw from SRBUserReq where reqid = $reqid");
my $pw = $pass[0];
my $passwd = $pw->{'pw'};

portalSQL("INSERT INTO SRBUser (username, domain, first_name, last_name, phone, email, comments)
           VALUES ('$username', '$domain', '$first_name', '$last_name', '$phone', '$email', '$comments')");
exit;
