#!/bin/bash

rm -f bin/grid-statusd

cat > bin/grid-statusd << 'EOT'
#!/bin/bash
SLEEP=1
while [ `ps h -o sz -C grid-statusd | tail -1` -lt 5000 ]
do
  bin/grid-status.php
  sleep $SLEEP
done
EOT

chmod 770 bin/grid-statusd
nohup bin/grid-statusd &
