<?php

$grid = $_GET["grid"];
$version = $_GET["version"];
$host = $_GET["host"];
$resource = $_GET["resource"];
$path = $_GET["path"];
$display = $_GET["display"];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php echo "$grid $version $host $resource stats" ?></title>
</head>
<body>
  <h2><?php echo "$grid $version" ?></h2>
<?php
if (!empty($host)) {
  echo "  <hr>\n";
  echo "  <b>\n";
  echo "  Host: $host<br>\n";
}
if (!empty($resource)) {
  echo "  Resource: $resource<br>\n";
  echo "  Path: $path<br>\n";
}
?>
  </b>
  <hr>
  <form method="get" action="uptime.php">
    Display:
    <select name="display">
      <option value="daily">daily
      <option value="weekly">weekly
      <option value="monthly">monthly
    </select>
    <input type="submit" value="Submit">
    <input type="hidden" name="grid" value="<?php echo $grid ?>">
    <input type="hidden" name="version" value="<?php echo $version ?>">
    <input type="hidden" name="host" value="<?php echo $host ?>">
    <input type="hidden" name="resource" value="<?php echo $resource ?>">
    <input type="hidden" name="path" value="<?php echo $path ?>">
  </form>
<?php
if (!empty($resource)) {
  echo "  <img src=\"uptime-graph.php?display=$display&grid=$grid&version=$version&host=$host&resource=$resource\" alt=\"Resource uptime graph\" name=\"uptime.png\" border=\"0\"><br>\n";
}
if (!empty($host)) {
  echo "  <img src=\"uptime-graph.php?display=$display&grid=$grid&version=$version&host=$host\" alt=\"Host uptime graph\" name=\"uptime.png\" border=\"0\"><br>\n";
}
  echo "  <img src=\"uptime-graph.php?display=$display&grid=$grid&version=$version\" alt=\"Grid uptime graph\" name=\"uptime.png\" border=\"0\"><br>\n";
?>

</body>
</html>
