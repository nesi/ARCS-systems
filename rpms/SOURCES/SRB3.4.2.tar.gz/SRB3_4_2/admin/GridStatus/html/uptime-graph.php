<?php
require ("config.inc");
require ($dbcp_path . "web-connect.inc");
require ("uptime-bar-graph.php");

$display = $_GET["display"];
$grid = $_GET["grid"];
$version = $_GET["version"];
$host = $_GET["host"];
$resource = $_GET["resource"];
$path = $_GET["path"];

if (!empty($resource)) {
  $title="Uptime Resource:  $resource";
}
elseif (!empty($host)) {
  $title="Uptime Host:  $host";
}
else {
  $title="Uptime Grid:  $grid";
}

if (empty($display)) {
  $display="monthly";
}

/*
$today = date("F j, Y");
$sqltoday = date("Y-m-d");
$lastyear = date("Y", mktime(0,0,0,1,1,date("Y")-1));
$month = date("m");

//Arrays for all statistics
$dates = array();
$u_fcount_hist = array();
$fcount_hist = array();
$u_fsize_hist = array();
$fsize_hist = array();
$users_hist = array();
$resources = array();
$r_names = array();
$r_fcount = array();
$r_fsize = array();
$domains = array();
$d_names = array();
$d_fcount = array();
$d_fsize = array();

//Query to get downtime history for last 12 measures
for($i=1; $i < 13; $i++) {
  $get_month = date("Y-m", mktime(0,0,0,$month + $i,1,$lastyear));
  
  $query = "select max(day) from general_stats where
  day like '$get_month%'";
  $result = dbx_query($web_db, $query);
  $qdate = $result->data[0][0];

  $query = "select * from
  general_stats where day = '$qdate'";
  $result = dbx_query($web_db, $query);

  array_push($dates, date("M-y", strtotime($result->data[0][0])));
  array_push($users_hist, $result->data[0][1]);
  array_push($u_fcount_hist, $result->data[0][2]/1000);
  array_push($fcount_hist, $result->data[0][3]/1000);
  array_push($u_fsize_hist, $result->data[0][4]);
  array_push($fsize_hist, $result->data[0][5]);
}

//Query and execute to get file and size count for resources
$query = "select resource, fc, fs from resource_stats a,
logical_resources b where a.day = '$sqltoday' and
a.id = b.id group by resource"; 
$result = dbx_query($web_db, $query);

for($i=0; $i < $result->rows; $i++) {
   $rname = $result->data[$i][0];
   $rcount = $result->data[$i][1];
   $rsize = $result->data[$i][2];

   //Add new Resource element
   $resources[$rname] = array( 'count' => $rcount, 'size' => $rsize );
}

function resource_print ($vals, $key) {
    global $MAIL, $r_names, $r_fcount, $r_fsize;
    array_push( $r_names, $key . " (" . number_format($vals['count']) . ")" );
    array_push( $r_fcount, $vals['count'] );
    array_push( $r_fsize, $vals['size'] );
}

function domain_print ($vals, $key) {
    global $MAIL, $d_names, $d_fcount, $d_fsize;
    array_push( $d_names, $key . " (" . number_format($vals['count']) . ")" );
    array_push( $d_fcount, $vals['count'] );
    array_push( $d_fsize, $vals['size'] );
}

array_walk ($resources, 'resource_print');

//Query and execute to get file and size count for domains
$query = "select domain, fc, fs from domain_stats a,
domains b where a.day = '$sqltoday' and
a.id = b.id group by domain";
$result = dbx_query($web_db, $query);

for($i=0; $i < $result->rows; $i++) {
   $dname = $result->data[$i][0];
   $dcount = $result->data[$i][1];
   $dsize = $result->data[$i][2];
                                                                                                                  
   //Add new Domain element
   $domains[$dname] = array( 'count' => $dcount, 'size' => $dsize );
}

array_walk ($domains, 'domain_print');

dbx_close($web_db);

*/

$dates=array("Jan","Feb","March");
$users_hist=array(300,400,800);

sizegraph($dates, $users_hist, false, $title, $display, "SRB_User_Growth.png");

dbx_close($web_db);
?>
