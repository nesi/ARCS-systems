<?php

/*This file is meant to restart SRB server if it's not running. First, you need 
  to define the server in the file "server.txt". Then setup a cron job with 
  "crontab -e" with some string like:
  0 0-23 * * * php /home/vorb/SRB3_4_0roadnet/admin/checkAndRestart/SRBcheckAndRestart.php >> /tmp/cron_SRBs_restart_php.log  2>&1
*/
error_reporting(E_ALL);

$log_file_expire_time=120; /* how many days should log file be kept on the server */
                           /* comment out this line if you wish to keep all log files */

$mypath=__FILE__;
$mydir=dirname($mypath);
$servers_file_name="$mydir/servers.txt";
if (!is_readable($servers_file_name))
{
  trigger_error("Could not read servers file:$servers_file_name\n");
}

$mydate=date('Y.m.d H:i:s');

$servers=parseServersFile($servers_file_name);

for($i=0;$i< count($servers);$i++)
{
  if ($servers[$i]['parent']!=-1)
  {
    continue;
  }
  
  $num_servers=count($servers[$i]['children'])+1;
  $code=0;
  $cmd='ps -ef | grep "'.$servers[$i]['srbMasterName'].
    '" | grep -v grep | wc | awk \'{printf("%s\n", $1);}\'';
  $cmd_result=runExternal($cmd, $code);
  /*
  if ($code!=0)
  {
    trigger_error("Failed to execute command ($code): $cmd\nOutput:$cmd_result\n");
  }
  */
  $cmd_result=trim($cmd_result);
  if (!is_numeric($cmd_result))
  {
    trigger_error("Unexpected Output:$cmd_result\n");
  }
  $num_servers_running=trim($cmd_result)+0;
  if ($num_servers!=$num_servers_running)
  {
    echo "$mydate ".$servers[$i]['srbMasterName'].
         " ($num_servers_running/$num_servers) is NOT running. ".
         "I'll try to restart it now!\n";
    restartServer($servers, $i);
  }
  else
  {
    echo "$mydate ".$servers[$i]['srbMasterName']." ($num_servers_running) is running ok\n";
  }
}

function restartServer($servers, $index)
{
  $path=$servers[$index]['srbMasterBinDir'];
  if (!chdir($path))
  {
    trigger_error("Can't change dir to $path\n");
    die();
  }
  
  $cmd="yes | ./killsrb";
  $code=0;
  $cmd_result=runExternal($cmd, $code);
  /*
  if ($code!=0)
  {
    trigger_error("Failed to execute command: $cmd\nOutput:$cmd_result\n");
  }
  */
  
  if (isset($log_file_expire_time))
  {
    removeOldLogFiles($servers[$index]['srbMasterBinDir'],$log_file_expire_time);
    foreach($servers[$index]['children'] as $child_server_index)
    {
      removeOldLogFiles($servers[$child_server_index]['srbMasterBinDir'],
        $log_file_expire_time);
    }
  }
  
  startServer($servers[$index]['srbMasterBinDir']);
  foreach($servers[$index]['children'] as $child_server_index)
  {
    startServer($servers[$child_server_index]['srbMasterBinDir']);
  }
}
  

function startServer($srbMasterBinDir)
{
  if (!chdir($srbMasterBinDir))
  {
    trigger_error("Can't change dir to $path\n");
    die();
  }
  
  /*
  $cmd="./runsrb";
  $cmd_result=runExternal($cmd, $code);
  if ($code!=0)
  {
    trigger_error("Failed to execute command: $cmd\nOutput:$cmd_result\n");
    die();
  }
  */
  `./runsrb`; /* it's sh shell script, works only by itself some how...*/
}

function removeOldLogFiles($srbMasterBinDir, $log_file_expire_time)
{
  $path=realpath("$srbMasterBinDir/../data/log");
    
  /* remove log file if they are too old */
  if (chdir($path))
  {
    if ($handle = opendir('.')) {
       while (false !== ($file = readdir($handle))) {
           if (  $file != "." && $file != ".." && 
                 0==strncmp($file,"srbLog.",strlen("srbLog.")) &&
                 (!is_dir($file)) &&
                 filemtime($file)-time()>30*24*3600  ) 
           {
               unlink($file);
           }
       }
       closedir($handle);
    }
  
  }
  else
  {
    trigger_error("Failed to Change Path to: $path\n");
  }
}
  

function parseServersFile($filename)
{
  $servers=array();
  $str=file_get_contents($filename);
  $lines=explode("\n",$str);
  foreach ($lines as $line)
  {
    $line=trim($line);
    if ( (empty($line))||($line[0]=='#') )
    {
      continue;
    }
    $row=array();
    list($row['enable'],$row['srbMasterName'],$row['srbMasterBinDir'],
      $row['logicalName'])=explode(",",$line);
    array_push($servers,$row);
  }
  
  for($i=0;$i< count($servers);$i++)
  {
    $servers[$i]['parent']=-1;
    $servers[$i]['children']=array();
    /* find previous occurence of srbMasterName */
    for($j=0;$j< $i;$j++)
    {
      if ($servers[$i]['srbMasterName']==$servers[$j]['srbMasterName'])
      {
        $servers[$i]['parent']=$j;
        array_push($servers[$j]['children'],$i);
        break;
      }
    }
  }
  return $servers;
}

function runExternal($cmd,&$code) {
    $descriptorspec = array(
        0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
        1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
        2 => array("pipe", "w") // stderr is a file to write to
    );
   
    $pipes= array();
    $process = proc_open($cmd, $descriptorspec, $pipes);
   
    $output= "";
   
    if (!is_resource($process)) return false;
   
    #close child's input imidiately
    fclose($pipes[0]);
   
    stream_set_blocking($pipes[1],false);
    stream_set_blocking($pipes[2],false);
   
    $todo= array($pipes[1],$pipes[2]);
   
    while( true ) {
        $read= array();
        if( !feof($pipes[1]) ) $read[]= $pipes[1];
        if( !feof($pipes[2]) ) $read[]= $pipes[2];
       
        if (!$read) break;
       
        $ready= stream_select($read, $write=NULL, $ex= NULL, 2);
       
        if ($ready === false) {
            break; #should never happen - something trigger_errord
        }
       
        foreach ($read as $r) {
            $s= fread($r,1024);
            $output.= $s;
        }
    }
   
    fclose($pipes[1]);
    fclose($pipes[2]);
   
    $code= proc_close($process);
   
    return $output;
}  
  
?>