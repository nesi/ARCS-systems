// WorkerThread.cpp : implementation file
//

#include "stdafx.h"
#include "Inquisitor.h"
#include "WorkerThread.h"
#include "soSession.h"
#include "soNode.h"
#include "LeftView.h"
#include <Shlwapi.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



//extern CMutex gMutex;
//extern CCriticalSection gCS;
//extern CMutex gCS;
extern int gCount;
extern CEvent killWorker;

//function takes as a parameter a pointer to a sessionimpl pointer.
//when function returns the pointer points to the newly-created session
UINT CloneSRBConnection(LPVOID pParam)
{
	SRB::SessionImpl** connection = (SRB::SessionImpl**)pParam;

	SRB::SessionImpl* blah = new SRB::SessionImpl;

	SRB::StatusCode status = (*connection)->Clone(blah);

	if(status.isOk())
	{
		*connection = blah;
		return 0;
	}

	*connection = NULL;
	return 1;
}

//
class CMainWindow : public CFrameWnd
{
public:
	CMainWindow();
protected:
	afx_msg void OnLButtonDown(UINT, CPoint);
	DECLARE_MESSAGE_MAP()
};
BEGIN_MESSAGE_MAP(CMainWindow, CFrameWnd)
	ON_WM_LBUTTONDOWN()
	END_MESSAGE_MAP()

	CMainWindow::CMainWindow()
	{
		Create(NULL, _T("TEST"));
	}

	void CMainWindow::OnLButtonDown(UINT nFlags, CPoint point)
	{
		//PostMessage(WM_CLOSE, 0,0);
	}

/////////////////////////////////////////////////////////////////////////////
// CWorkerThread


IMPLEMENT_DYNCREATE(CWorkerThread, CWinThread)

CWorkerThread::CWorkerThread()
{
	m_pPThread = NULL;
	m_session = NULL;
}

BOOL CWorkerThread::SetThread(HWND main_thread, SRB::SessionImpl* session)
{
	//m_pView = pView;
	m_idMainThread = main_thread;
	m_session = session;
	return TRUE;
}

void CWorkerThread::SetThread2(HWND main_thread, SRB::SessionImpl* session)
{
	if(NULL == session)
		return;

	m_idMainThread = main_thread;

	m_session = session;

	//just have the worker thread use the same thread as the gui thread
//	CWinThread* MyThread = AfxBeginThread(CloneSRBConnection, &m_session, THREAD_PRIORITY_NORMAL, 0,0, NULL);
}

CWorkerThread::~CWorkerThread()
{
//	As long as both threads use the same struct we do not delete datastruct in worker thread
//	This code was to be used in case a terminate without an exit instance was called.
//	if(m_session)
//		delete m_session;
}

BOOL CWorkerThread::InitInstance()
{
	// TODO:  perform and per-thread initialization here
//	m_pMainWnd = new CMainWindow;
//	m_pMainWnd->ShowWindow(SW_SHOW);
//	m_pMainWnd->UpdateWindow();

	return TRUE;
}

int CWorkerThread::ExitInstance()
{
	//As long as both threads use the same struct we do not delete datastruct in worker thread
	//if(m_session)
	//{
	//	delete m_session;
	//	m_session = NULL;
	//}

	//VERIFY(::WaitForSingleObject (killWorker.m_hObject, 0) == WAIT_OBJECT_0);

	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CWorkerThread, CWinThread)
	//{{AFX_MSG_MAP(CWorkerThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
	ON_REGISTERED_THREAD_MESSAGE(msgDownload, OnDownload)
	ON_REGISTERED_THREAD_MESSAGE(msgUpload, OnUpload)
	ON_REGISTERED_THREAD_MESSAGE(msgDelete, OnDelete)
	ON_REGISTERED_THREAD_MESSAGE(msgNewNode, OnNewNode)
	ON_REGISTERED_THREAD_MESSAGE(msgReplicate, OnReplicate)
	ON_REGISTERED_THREAD_MESSAGE(msgCopy, OnCopy)
	ON_REGISTERED_THREAD_MESSAGE(msgSynchronize, OnSynchronize)
	ON_REGISTERED_THREAD_MESSAGE(msgRename, OnRename)
	ON_REGISTERED_THREAD_MESSAGE(msgSetComment, OnSetComment)
END_MESSAGE_MAP()


UINT ProgressThreadFunc(LPVOID pParam)
{
	ProgThreadParams* param = (ProgThreadParams*)pParam;
	CEvent* pFinished = param->finished;
	SRB::ITransferOperator* pOp = param->op;
	HWND handle = param->handle;
	char* pszName = param->name;
	UINT msg = param->msg;

	int value, old_value;

	value = old_value = 0;

	int op_type = pOp->GetType();

	while(true)
	{
		if(SOB_OP_COLLECTION == op_type)
			//value = pOp->GetProgress(&pszName);
			value = pOp->GetProgress(NULL);
		else
			value = pOp->GetProgress(NULL);

		if(value >= 0)
		{
			if(value != old_value)
			{
				::SendMessage(handle, msg, (WPARAM)pszName, value);
				old_value = value;
			}
		}

		//have some code here to raise this flag when somebody's exiting the program
		//in the middle of a download.
		if(::WaitForSingleObject (pFinished->m_hObject, 0) == WAIT_OBJECT_0)
		{
			free(param->name);
			delete param;
			return 0;
		}

		::Sleep(1000);
	}

	free(param->name);

	return -1;
}

/////////////////////////////////////////////////////////////////////////////
// CWorkerThread message handlers

//Download datasets/collections to your local machine
LRESULT CWorkerThread::OnDownload(WPARAM wParam, LPARAM lParam)
{
	dl* mydl = (dl*)lParam;
#if 0
	if(!gCS.Lock(5))
	{
		::MessageBox(m_idMainThread, "Thread could not obtain Lock", "Error", MB_OK);
		free((void*)mydl->local_path);
		delete mydl;
		return SRB_ERROR;
	}
#endif
	::SendMessage(m_idMainThread, msgGoAnimation, NULL, NULL);

	CEvent finished;
	CEvent* gfinished = &finished;

	SRB::ITransferOperator* dOp = (SRB::ITransferOperator*)m_session->GetOperator(mydl->node->GetType());

	//char bufbuf[1024];
	//sprintf(bufbuf, "%d", dOp);
	//AfxMessageBox(bufbuf);

	struct ProgThreadParams* params = new ProgThreadParams;

	params->op = dOp;
	params->finished = &finished;
	params->name = strdup(mydl->node->GetName());
	params->handle = m_idMainThread;
	params->msg = msgDLProgress;

	//thread is created suspended so that we may grab a copy of the thread's handle.
	//by copying the handle, we increase the thread's handle count, so it will not free.

	HANDLE progthread;
	m_pPThread = AfxBeginThread (ProgressThreadFunc, params, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::DuplicateHandle (GetCurrentProcess (), m_pPThread->m_hThread, GetCurrentProcess (), &progthread, 0, FALSE, DUPLICATE_SAME_ACCESS);
	m_pPThread->ResumeThread();

	SRB::StatusCode status = dOp->Download(mydl->node, mydl->local_path);
	

	//after we signal the progress thread to end, we _must_ make sure the thread completes
	//before this thread completes. Otherwise, we can run into problems where memory is not
	//freed and/or the progress thread is sending messages with values from previous downloads.
	VERIFY(finished.SetEvent());
	::WaitForSingleObject(progthread, INFINITE);
	m_pPThread = NULL;
	VERIFY(::CloseHandle(progthread));

	gCount--;

	char buf[1024];

	if(status.isOk())
	{
		if(wParam)
		{
			status = Execute(mydl->node, mydl->local_path);	//download and execute

			if(status.isOk())
				sprintf(buf, "executing %s succeeded", mydl->node->GetName());
			else
				sprintf(buf, "failed to execute %s : %s", mydl->node->GetName(), status.GetError());
		}else
		{
			sprintf(buf, "downloading %s succeeded", mydl->node->GetName());
		}
	}else
	{
		sprintf(buf, "failed to download %s : %s", mydl->node->GetName(), status.GetError());
	}

	char *message = strdup(buf);

	::SendMessage(m_idMainThread, msgDLProgress, NULL, 0);
	::SendMessage(m_idMainThread, msgStatusLine, (WPARAM)message, 1);	//1 toggles free after use


	free((void*)mydl->local_path);
	delete mydl;

	if(0 == gCount)
	{
		::SendMessage(m_idMainThread, msgStopAnimation, NULL, NULL);
	}
#if 0
	if(!gCS.Unlock())
	{
		MessageBox(m_idMainThread, "Couldn't unlock thread", "ERROR", MB_OK);
	}
#endif
	return 0;
}

//Upload files from your local machine into SRB
LRESULT CWorkerThread::OnUpload(WPARAM wParam, LPARAM lParam)
{
	dl* mydl = (dl*)lParam;
#if 0
	if(!gCS.Lock(5))
	{
		::MessageBox(m_idMainThread, "Thread could not obtain Lock", "Error", MB_OK);
		free((void*)mydl->local_path);
		delete mydl;
		return SRB_ERROR;
	}
#endif
	::SendMessage(m_idMainThread, msgGoAnimation, NULL, NULL);

	CEvent finished;

	SRB::ITransferOperator* pOp;

	if(PathIsDirectory(mydl->local_path))
		pOp = (SRB::ITransferOperator*)m_session->GetOperator(SOB_COLLECTION);
	else
		pOp = (SRB::ITransferOperator*)m_session->GetOperator(SOB_DATASET);

	pOp->Bind(mydl->binding);

	struct ProgThreadParams* params = new ProgThreadParams;

	params->op = pOp;
	params->finished = &finished;
	params->name = strdup(mydl->local_path);
	params->handle = m_idMainThread;
	params->msg = msgULProgress;

	HANDLE progthread;
	m_pPThread = AfxBeginThread (ProgressThreadFunc, params, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::DuplicateHandle (GetCurrentProcess (), m_pPThread->m_hThread, GetCurrentProcess (), &progthread, 0, FALSE, DUPLICATE_SAME_ACCESS);
	m_pPThread->ResumeThread();

	SRB::StatusCode status = pOp->Upload(mydl->node, mydl->local_path, SOB_NO_OVERWRITE);

	static char buf[MAX_PATH];

	if(DATA_NOT_UNIQUE_IN_COLLECTION == status)
	{
		if(mydl->node->GetType() == SOB_COLLECTION)
		{
			int len = strlen(mydl->local_path);
			const char* name = NULL;
			for(i = len - 1; i != 0; i--)
			{
				if('\\' == (mydl->local_path)[i])
				{
					name = &(mydl->local_path[i+1]);	//found the beginning of our name
					break;
				}
			}
			if(NULL == name)
				name = mydl->local_path;

			int match = 0;
			for(int i = 0; i < mydl->node->CountChildren(); i++)
			{
				if(0 == strcmp(name, mydl->node->GetChild(i)->GetName()))
					if(++match > 1)
						break;
			}

			ASSERT(0 != match);
			//overwrites are allowed in 118p for singles, but not replicas (overwriting replicas not handled correctly in 118p)
			if(1 == match)
				if(IDYES == AfxMessageBox("Overwrite existing data?", MB_YESNO))
					status = pOp->Upload(mydl->node, mydl->local_path, SOB_OVERWRITE);

			//if(IDYES == AfxMessageBox("Overwrite existing data?", MB_YESNO))
			//	if(IDYES == AfxMessageBox("Overwrite all replicas?", MB_YESNO))
			//		status = pOp->Upload(mydl->node, mydl->local_path, SOB_OVERWRITE_ALL);
			//	else
			//		status = pOp->Upload(mydl->node, mydl->local_path, SOB_OVERWRITE);
		}
	}
	
	VERIFY(finished.SetEvent());
	::WaitForSingleObject(progthread, INFINITE);
	m_pPThread = NULL;
	VERIFY(::CloseHandle(progthread));

	gCount--;

	if(status.isOk())
	{
		sprintf(buf, "%s was uploaded successfully.", mydl->local_path);
	}else
	{
		sprintf(buf, "could not upload %s : %s", mydl->local_path, status.GetError());
	}

	char* message = strdup(buf);

	::SendMessage(m_idMainThread, msgULProgress, NULL, 0);
	::SendMessage(m_idMainThread, msgStatusLine, (WPARAM)message, 1);

	free((void*)mydl->local_path);
	delete mydl;

	::SendMessage(m_idMainThread, msgRefresh, NULL, 2);

	if(0 == gCount)
	{
		::SendMessage(m_idMainThread, msgStopAnimation, NULL, NULL);
	}

#if 0
	if(!gCS.Unlock())
	{
		MessageBox(m_idMainThread, "Couldn't unlock thread", "ERROR", MB_OK);
	}
#endif

	return 0;
}


LRESULT CWorkerThread::OnRename(WPARAM wParam, LPARAM lParam)
{
#if 0
	if(!gCS.Lock(5))
	{
		::MessageBox(m_idMainThread, "Thread could not obtain Lock", "Error", MB_OK);
		return SRB_ERROR;
	}
#endif

	::SendMessage(m_idMainThread, msgGoAnimation, NULL, NULL);

	SRB::INode* node = (SRB::INode*)lParam;

	char* new_name = (char*)wParam;

	ASSERT(NULL != new_name);

	int type = node->GetType();

	SRB::IOperator* dOp = m_session->GetOperator(type);

	SRB::StatusCode status;

	char* name = strdup(node->GetName());

	switch(node->GetType())
	{
	case SOB_DATASET:
		status = ((SRB::IDatasetOperator*)dOp)->Rename((SRB::IDatasetNode*)node, new_name);
		break;
	case SOB_COLLECTION:
		status = ((SRB::ICollectionOperator*)dOp)->Rename((SRB::ICollectionNode*)node, new_name);
		break;
	default:
		status = SRB_ERROR_INVALID_PARAMETER;
		break;
	}

	static char buf[256];

	gCount--;

	if(status.isOk())
	{
		sprintf(buf, "renamed %s", name);
	}else
	{
		sprintf(buf, "could not rename %s : %s", name, status.GetError());
	}

	free(name);
	free(new_name);

	char* message = strdup(buf);

	::PostMessage(m_idMainThread, msgStatusLine, (WPARAM)message, 1);	//1 toggles free after use

	if(0 == gCount)
		::SendMessage(m_idMainThread, msgStopAnimation, NULL, NULL);

	::PostMessage(m_idMainThread, msgRefresh, NULL, 2);
#if 0
	if(!gCS.Unlock())
	{
		MessageBox(m_idMainThread, "Couldn't unlock thread", "ERROR", MB_OK);
	}
#endif
	return 0;
}

LRESULT CWorkerThread::OnDelete(WPARAM wParam, LPARAM lParam)
{
#if 0
	if(!gCS.Lock(5))
	{
		::MessageBox(m_idMainThread, "Thread could not obtain Lock", "Error", MB_OK);
		return SRB_ERROR;
	}
#endif
	::SendMessage(m_idMainThread, msgGoAnimation, NULL, NULL);

	SRB::INode* node = (SRB::INode*)lParam;

	int type = node->GetType();

	SRB::IOperator* dOp = m_session->GetOperator(type);

	SRB::StatusCode status;

	char* name = strdup(node->GetName());

	SRB::INode* parent;
	SRB::INode* blahblah;

	switch(type)
	{
	case SOB_DATASET:
		status = ((SRB::IDatasetOperator*)dOp)->Delete((SRB::IDatasetNode*)node);
		break;
	case SOB_COLLECTION:
		status = ((SRB::ICollectionOperator*)dOp)->Delete((SRB::ICollectionNode*)node);
		break;
	case SOB_CONTAINER:
		blahblah = node->GetParent();
		status = ((SRB::IContainerOperator*)dOp)->Delete((SRB::IContainerNode*)node);
		break;
	case SOB_METADATA:
		parent = node->GetParent();
		dOp = m_session->GetOperator(parent->GetType());
		switch(parent->GetType())
		{
		case SOB_DATASET:
			status = ((SRB::IDatasetOperator*)dOp)->DeleteMeta((SRB::IMetadataNode*)node);
			break;
		case SOB_COLLECTION:
			status = ((SRB::ICollectionOperator*)dOp)->DeleteMeta((SRB::IMetadataNode*)node);
			break;
		case SOB_QUERY:
			status = SRB_ERROR_QUERY_DELETE_FORBIDDEN;
			break;
		default:
			status = SRB_ERROR_INVALID_PARAMETER;
			break;
		}
		break;
	default:
		status = SRB_ERROR_INVALID_PARAMETER;
		break;
	}

	static char buf[256];

	gCount--;

	if(status.isOk())
	{
		sprintf(buf, "deleted %s", name);
	}else
	{
		sprintf(buf, "could not delete %s : %s", name, status.GetError());
	}

	free(name);

	char* message = strdup(buf);

	::PostMessage(m_idMainThread, msgStatusLine, (WPARAM)message, 1);	//1 toggles free after use

	if(0 == gCount)
	{
		::PostMessage(m_idMainThread, msgStopAnimation, NULL, NULL);
	}

	::PostMessage(m_idMainThread, msgRefresh, NULL, 2);

	if(SOB_CONTAINER == type)
		::PostMessage(m_idMainThread, msgRefillResourceList, (WPARAM)blahblah, (LPARAM)node);	//for containers
		//::PostMessage(m_idMainThread, msgRefillResourceList, (WPARAM)m_session->GetResource(), NULL);	//for containers
#if 0
	if(!gCS.Unlock())
	{
		MessageBox(m_idMainThread, "Couldn't unlock thread", "ERROR", MB_OK);
	}
#endif
	return 0;
}

LRESULT CWorkerThread::OnCopy(WPARAM wParam, LPARAM lParam)
{
#if 0
	if(!gCS.Lock(5))
	{
		::MessageBox(m_idMainThread, "Thread could not obtain Lock", "Error", MB_OK);
		return SRB_ERROR;
	}
#endif
	::SendMessage(m_idMainThread, msgGoAnimation, NULL, NULL);

	copy_op* params = (copy_op*)lParam;

	SRB::ICollectionOperator* cOp = (SRB::ICollectionOperator*)m_session->GetOperator(SOB_COLLECTION);

	SRB::StatusCode status = cOp->Bind(params->resource);

	char* name = strdup((char*)params->node->GetName());

	switch(params->node->GetType())
	{
	case SOB_DATASET:
		if(status.isOk())
			if(params->delete_original)
				status = cOp->Move((SRB::ICollectionNode*)params->target, (SRB::IDatasetNode*)params->node);
			else
				status = cOp->Copy((SRB::ICollectionNode*)params->target, (SRB::IDatasetNode*)params->node);
		break;
	case SOB_COLLECTION:
		if(status.isOk())
			if(params->delete_original)
				status = cOp->Move((SRB::ICollectionNode*)params->target, (SRB::ICollectionNode*)params->node);
			else
				status = cOp->Copy((SRB::ICollectionNode*)params->target, (SRB::ICollectionNode*)params->node);
		break;
	default:
		status = SRB_ERROR_INVALID_PARAMETER;
		break;
	}

	static char buf[256];

	gCount--;

	if(status.isOk())
	{
		if(params->delete_original)
			sprintf(buf, "moved %s", name);
		else
			sprintf(buf, "copied %s", name);
	}else
	{
		if(params->delete_original)
			sprintf(buf, "could not complete move %s : %s", name, status.GetError());
		else
			sprintf(buf, "could not copy %s : %s", name, status.GetError());
	}

	free(name);

	char* message = strdup(buf);

	::PostMessage(m_idMainThread, msgStatusLine, (WPARAM)message, 1);	//1 toggles free after use

	::PostMessage(m_idMainThread, msgRefresh, NULL, 4);

	if(0 == gCount)
	{
		::PostMessage(m_idMainThread, msgStopAnimation, NULL, NULL);
	}
#if 0
	if(!gCS.Unlock())
	{
		MessageBox(m_idMainThread, "Couldn't unlock thread", "ERROR", MB_OK);
	}
#endif
	delete params;

	return 0;
}

LRESULT CWorkerThread::OnReplicate(WPARAM wParam, LPARAM lParam)
{
#if 0
	if(!gCS.Lock(5))
	{
		::MessageBox(m_idMainThread, "Thread could not obtain Lock", "Error", MB_OK);
		return SRB_ERROR;
	}
#endif

	::SendMessage(m_idMainThread, msgGoAnimation, NULL, NULL);

	new_replicant* blah = (new_replicant*)lParam;

	int type = blah->node->GetType();

	SRB::IOperator* dOp;

	SRB::StatusCode status;

	switch(type)
	{
	case SOB_COLLECTION:
		dOp = m_session->GetOperator(SOB_COLLECTION);
		((SRB::ICollectionOperator*)dOp)->Bind(blah->binding);
		status = ((SRB::ICollectionOperator*)dOp)->Replicate((SRB::ICollectionNode*)blah->node);
		break;
	case SOB_DATASET:
		dOp = m_session->GetOperator(SOB_DATASET);
		((SRB::IDatasetOperator*)dOp)->Bind(blah->binding);
		status = ((SRB::IDatasetOperator*)dOp)->Replicate((SRB::IDatasetNode*)blah->node);
		break;
	default:
		status = SRB_ERROR_INVALID_PARAMETER;
	}

	static char buf[256];

	gCount--;

	if(status.isOk())
	{
		sprintf(buf, "replicated %s", blah->node->GetName());
	}else
	{
		sprintf(buf, "could not replicate %s : %s", blah->node->GetName(), status.GetError());
	}

	char* message = strdup(buf);

	::PostMessage(m_idMainThread, msgStatusLine, (WPARAM)message, 1);	//1 toggles free after use

	delete blah;

	if(0 == gCount)
	{
		::SendMessage(m_idMainThread, msgStopAnimation, NULL, NULL);
	}

	::PostMessage(m_idMainThread, msgRefresh, NULL, 5);
#if 0
	if(!gCS.Unlock())
	{
		MessageBox(m_idMainThread, "Couldn't unlock thread", "ERROR", MB_OK);
	}
#endif
	return 0;

}

LRESULT CWorkerThread::OnNewNode(WPARAM wParam, LPARAM lParam)
{
#if 0
	if(!gCS.Lock(5))
	{
		::MessageBox(m_idMainThread, "Thread could not obtain Lock", "Error", MB_OK);
		return SRB_ERROR;
	}
#endif
	::SendMessage(m_idMainThread, msgGoAnimation, NULL, NULL);

	new_node* blah = (new_node*)lParam;

	int type = blah->parent->GetType();

	SRB::IOperator* dOp;

	SRB::StatusCode status;

	if(!blah->parent->isOpen())
		m_session->OpenTree(blah->parent, 1, true);

	switch(type)
	{
	case SOB_COLLECTION:
		dOp = m_session->GetOperator(SOB_COLLECTION);
		status = ((SRB::ICollectionOperator*)dOp)->Create((SRB::ICollectionNode*)blah->parent, blah->name);
		break;
	case SOB_RESOURCE:
		dOp = m_session->GetOperator(SOB_RESOURCE);
		status = ((SRB::IResourceOperator*)dOp)->Create((SRB::IResourceNode*)blah->parent, blah->name);
		break;
	default:
		status = SRB_ERROR_INVALID_PARAMETER;
	}

	static char buf[256];

	gCount--;

	if(status.isOk())
	{
		sprintf(buf, "created %s", blah->name);
	}else
	{
		sprintf(buf, "could not create %s : %s", blah->name, status.GetError());
	}

	char* message = strdup(buf);

	::PostMessage(m_idMainThread, msgStatusLine, (WPARAM)message, 1);	//1 toggles free after use

	free(blah->name);
	delete blah;

	if(0 == gCount)
	{
		::SendMessage(m_idMainThread, msgStopAnimation, NULL, NULL);
	}

	if(SOB_COLLECTION == type)
		::PostMessage(m_idMainThread, msgRefresh, NULL, 2);
	else
	{
		::PostMessage(m_idMainThread, msgRefresh, NULL, 2);	//for containers
		//::PostMessage(m_idMainThread, msgRefillResourceList, (WPARAM)m_session->GetResource(), NULL);	//for containers
		::PostMessage(m_idMainThread, msgRefillResourceList, NULL, NULL);	//for containers
	}
#if 0
	if(!gCS.Unlock())
	{
		MessageBox(m_idMainThread, "Couldn't unlock thread", "ERROR", MB_OK);
	}
#endif
	
	return 0;
}

BOOL CWorkerThread::OnIdle(LONG lCount) 
{
	if(lCount > 2000)
	{
		this->SuspendThread();
		return 0;
	}

	return CWinThread::OnIdle(lCount);
}

LRESULT CWorkerThread::Execute(SRB::INode* node, const char* local_path)
{
	if(NULL == local_path)
		return SRB_ERROR_INVALID_PARAMETER;

	static char buf[MAX_PATH];

	sprintf(buf, "%s\\%s", local_path, node->GetName());

	SHELLEXECUTEINFO myinfo;

    myinfo.cbSize = sizeof(SHELLEXECUTEINFO);
    myinfo.fMask = SEE_MASK_NOCLOSEPROCESS;

    myinfo.hwnd = NULL;
    myinfo.lpVerb = "open";
    myinfo.lpFile = buf;
    myinfo.lpParameters = NULL;
    myinfo.lpDirectory = NULL;
    myinfo.nShow = SW_SHOW;
    myinfo.hInstApp;

	int status = SRB_ERROR;

	if(ShellExecuteEx(&myinfo))
	{
		status = SRB_OK;
	}

	return status;
}

LRESULT CWorkerThread::OnSynchronize(WPARAM wParam, LPARAM lParam)
{
#if 0
	if(!gCS.Lock(5))
	{
		::MessageBox(m_idMainThread, "Thread could not obtain Lock", "Error", MB_OK);
		return SRB_ERROR;
	}
#endif

	::SendMessage(m_idMainThread, msgGoAnimation, NULL, NULL);

	SRB::IContainerNode* blah = (SRB::IContainerNode*)lParam;

	if(SOB_CONTAINER != blah->GetType())
	{
#if 0
		if(!gCS.Unlock())
		{
			MessageBox(m_idMainThread, "Couldn't unlock thread", "ERROR", MB_OK);
		}
#endif
		return SRB_ERROR_INVALID_PARAMETER;
	}

	SRB::IContainerOperator* Op = (SRB::IContainerOperator*)m_session->GetOperator(SOB_CONTAINER);

	SRB::StatusCode status = ((SRB::IContainerOperator*)Op)->Sync(blah, (unsigned int)wParam);

	static char buf[256];

	gCount--;

	if(status.isOk())
	{
		sprintf(buf, "synchronized %s", blah->GetName());
	}else
	{
		sprintf(buf, "could not synchronize %s : %s", blah->GetName(), status.GetError());
	}

	char* message = strdup(buf);

	::PostMessage(m_idMainThread, msgStatusLine, (WPARAM)message, 1);	//1 toggles free after use

	if(0 == gCount)
	{
		::SendMessage(m_idMainThread, msgStopAnimation, NULL, NULL);
	}

	::PostMessage(m_idMainThread, msgRefresh, NULL, NULL);
#if 0
	if(!gCS.Unlock())
	{
		MessageBox(m_idMainThread, "Couldn't unlock thread", "ERROR", MB_OK);
	}
#endif
	
	return 0;
}

LRESULT CWorkerThread::OnSetComment(WPARAM wParam, LPARAM lParam)
{
#if 0
	if(!gCS.Lock(5))
	{
		::MessageBox(m_idMainThread, "Thread could not obtain Lock", "Error", MB_OK);
		return SRB_ERROR;
	}
#endif

	::SendMessage(m_idMainThread, msgGoAnimation, NULL, NULL);


	char* comment = (char*)wParam;
	SRB::IDatasetNode* node = (SRB::IDatasetNode*)lParam;
	SRB::IDatasetOperator* dOp = (SRB::IDatasetOperator*)m_session->GetOperator(SOB_DATASET);
	SRB::StatusCode status = dOp->SetComment(node, comment);

	gCount--;

	char buf[1024];

	if(status.isOk())
		sprintf(buf, "setting %s's system comment successful", node->GetName());
	else
		sprintf(buf, "failed to set %s's comment: %s", node->GetName(), status.GetError());

	char *message = strdup(buf);

	::SendMessage(m_idMainThread, msgStatusLine, (WPARAM)message, 1);	//1 toggles free after use

	free(comment);

	::SendMessage(m_idMainThread, msgRefresh, NULL, 2);

	if(0 == gCount)
	{
		::SendMessage(m_idMainThread, msgStopAnimation, NULL, NULL);
	}
#if 0
	if(!gCS.Unlock())
	{
		MessageBox(m_idMainThread, "Couldn't unlock thread", "ERROR", MB_OK);
	}
#endif

	return 0;
}
