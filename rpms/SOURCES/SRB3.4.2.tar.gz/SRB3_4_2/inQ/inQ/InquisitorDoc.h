// InquisitorDoc.h : interface of the CInquisitorDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_INQUISITORDOC_H__736A9F8C_911C_46B5_BBF2_446BF4CA7230__INCLUDED_)
#define AFX_INQUISITORDOC_H__736A9F8C_911C_46B5_BBF2_446BF4CA7230__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "soSession.h"
#include "soNode.h"
#include "WorkerThread.h"
#include "Login.h"
#include <stack>

class CInquisitorDoc : public COleDocument
{
protected: // create from serialization only
	CInquisitorDoc();
	DECLARE_DYNCREATE(CInquisitorDoc)

public:
	void OnFailedConnection();
	SRB::SessionImpl MyImpl;
	SRB::StatusCode NukeDir(const char* szpath);
	void Copy(SRB::INode* node, int type, bool cut, char* name, char* path, int replication_index);
	void Copy(SRB::INode* target, SRB::INode* source, bool cut);
	char* GetTempPath();
	void SetSynchronizationFlags(bool purge, bool primary_only);
	void Replicate(SRB::INode* node);
	SRB::StatusCode ChangePassword(const char* password);
	bool isConnected();
	SRB::StatusCode DragOutDownload(LPSTGMEDIUM lpStgMedium);
	void SetAccess(SRB::INode* node);
	bool Disconnect();
	SRB::IStringNode* GetAccessConstraint();
	SRB::StatusCode SetAccess(SRB::INode* target, SRB::IUserNode* owner, const char* permission, bool recursive = false);
	SRB::StatusCode ModifyAccess(SRB::IAccessNode* target, const char* permission, bool recursive = false);
	BOOL OnCompletedConnection();
	SRB::INode* CInquisitorDoc::GetDomains();
	SRB::StatusCode SetMetadataValue(const char* attribute, const char* value);
	SRB::StatusCode SetMetadataValue(SRB::IMetadataNode* node, const char* value);
	SRB::INode* GetRoot();
		SRB::INode* GetLocalRoot();
	SRB::INode* GetHome();
	SRB::INode* GetHomeZone();
	SRB::INode* GetMCAT();
	void SetComment(SRB::INode* node, char* comment);
	SRB::StatusCode OpenTree(SRB::INode* node, int levels, bool clear, unsigned int mask = SOB_ALL);
	SRB::ISetNode* GetResources(SRB::IZoneNode* node);
	SRB::StatusCode AddNewMetadata(const char* attribute, const char* value);
	SRB::StatusCode SetDefaultResource(SRB::INode* resource);
	SRB::INode* GetDefaultResource() { return m_defaultResource;};
	void OnReturn();
	void Synchronize(SRB::INode* node);
	void Rename(SRB::INode* node, char* name);
	void Delete(SRB::INode* node);
	bool SuspendWorkThread();
	bool ResumeWorkThread();
	void Download(SRB::INode* node, const char* local_path, bool Execute);
	void Download(SRB::INode* node, bool Execute);
	void Upload(SRB::INode* node, const char* local_path);
	void Execute(const char* local_path);
	void SetCurrentNode(SRB::INode* node);
	SRB::INode* GetCurrentNode();

	void CreateNode(SRB::INode* parent, const char* name);

	void OnBack();
	void OnForward();



//SRB::IZoneNode* GetCurrentZone();

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInquisitorDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void OnCloseDocument();
	//}}AFX_VIRTUAL

public:
	virtual ~CInquisitorDoc();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CInquisitorDoc)
	afx_msg void OnQuery();
	afx_msg void OnUpdateBack(CCmdUI* pCmdUI);
	afx_msg void OnUpdateForward(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileNew(CCmdUI* pCmdUI);
	afx_msg void OnRefresh();
	afx_msg void OnUpdateRefresh(CCmdUI* pCmdUI);
	afx_msg void OnGetpath();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:

	CWinThread* m_pCThread;
	HANDLE m_hCThread;

	//SRB::SessionImpl* MyImpl2;
	CLogin m_Login;
	SRB::INode* m_current_node;
	SRB::INode* m_defaultResource;
	CWorkerThread* m_worker_thread;
	bool m_bIsDemo;
	SRB::INode* m_History[10];
	int m_HistoryLast, m_HistoryFirst, m_HistoryCurrent;
	unsigned int m_synchFlag;

	SRB::IZoneNode* m_zone;

	bool m_eventConnecting;

};

class CharlieSource : public COleDataSource
{
public:
	~CharlieSource();
	BOOL OnRenderData(LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium);
	CInquisitorDoc* m_doc;
private:
	BOOL RenderFileData(LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium);
	BOOL RenderInqData(LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium);
	SRB::StatusCode DownloadForCopy(LPSTGMEDIUM lpStgMedium);
	std::vector<SRB::INode*> m_NodeDragList;
	int mysentinel;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INQUISITORDOC_H__736A9F8C_911C_46B5_BBF2_446BF4CA7230__INCLUDED_)
