#if !defined(AFX_WORKERTHREAD_H__59D88CE2_5762_422B_81D8_D35C1CCF68E9__INCLUDED_)
#define AFX_WORKERTHREAD_H__59D88CE2_5762_422B_81D8_D35C1CCF68E9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WorkerThread.h : header file
//

#include "soSession.h"
#include "soNode.h"
#include "LeftView.h"

/////////////////////////////////////////////////////////////////////////////
// CWorkerThread thread

class CWorkerThread : public CWinThread
{
	DECLARE_DYNCREATE(CWorkerThread)
protected:
	CWorkerThread();           // protected constructor used by dynamic creation
public:
	BOOL SetThread(HWND main_thread, SRB::SessionImpl* session);
	void SetThread2(HWND main_thread, SRB::SessionImpl* session);

	//SRB::StatusCode Copy();
	void Delete(HWND window, SRB::INode* node);
	LRESULT OnCopy(WPARAM wParam, LPARAM lParam);
	LRESULT OnDownload(WPARAM wParam, LPARAM lParam);
	LRESULT OnSetComment(WPARAM wParam, LPARAM lParam);
	LRESULT OnUpload(WPARAM wParam, LPARAM lParam);
	LRESULT OnRename(WPARAM wParam, LPARAM lParam);
	LRESULT OnDelete(WPARAM wParam, LPARAM lParam);
	LRESULT OnReplicate(WPARAM wParam, LPARAM lParam);
	LRESULT OnNewNode(WPARAM wParam, LPARAM lParam);
	LRESULT OnSynchronize(WPARAM wParam, LPARAM lParam);
	LRESULT Execute(SRB::INode* node, const char* local_path);
	virtual ~CWorkerThread();
// Attributes
public:
	SRB::SessionImpl* m_session;
// Operations
public:
CWinThread* m_pPThread;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWorkerThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	virtual BOOL OnIdle(LONG lCount);
	//}}AFX_VIRTUAL

// Implementation
protected:
//	virtual ~CWorkerThread();

	// Generated message map functions
	//{{AFX_MSG(CWorkerThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

private:
	HWND m_idMainThread;
	//CLeftView* m_pView;
	
	


	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WORKERTHREAD_H__59D88CE2_5762_422B_81D8_D35C1CCF68E9__INCLUDED_)
