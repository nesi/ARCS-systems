#ifndef __SRB_OBJECT_DOMAIN_OPERATOR_H__
#define __SRB_OBJECT_DOMAIN_OPERATOR_H__
#include "soGlobals.h"
#include "clConnectExtern.h"

#include "soNode.h"
#include "soDomain.h"
#include "scommands.h"

namespace SRB
{

class DomainOperatorImpl : public IDomainOperator
{
public:

	//interface
	StatusCode Download(INode* target, const char* local_path) { return -1;};
	StatusCode Upload(INode* target, const char* local_path, unsigned int overwrite, INode** result) { return -1;};

	//impl
	StatusCode GetChildren(DomainNodeImpl* target, unsigned int mask = SOB_ALL);
	DomainOperatorImpl(ISession* session);
	 ~DomainOperatorImpl();
	StatusCode GetDomainUsers(IDomainNode* domain);
	int GetProgress(char** name) { return -1;};
	StatusCode Bind(INode* node) { return SRB_ERROR_TYPE_NOT_SUPPORTED;};
	int GetType() { return SOB_OP_DOMAIN; };
private:
	DomainOperatorImpl();
	DomainOperatorImpl(const DomainOperatorImpl& source);
	DomainOperatorImpl& operator =(const DomainOperatorImpl& source);

	void ClearMCATScratch();
	mdasC_sql_result_struct m_result;
	char m_qval[MAX_DCS_NUM][MAX_TOKEN];
	int m_selval[MAX_DCS_NUM];
	srbConn* m_conn;
	ISession* m_session;
	IDomainNode* m_domain;
};
}//end namespace
#endif __SRB_OBJECT_DOMAIN_OPERATOR_H__

