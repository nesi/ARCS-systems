#ifndef __SRB_OBJECT_CONTAINER_OPERATOR_H__
#define __SRB_OBJECT_CONTAINER_OPERATOR_H__
#include "soGlobals.h"
#include "clConnectExtern.h"

#include "soNode.h"

namespace SRB
{

class ContainerOperatorImpl : public IContainerOperator
{
public:

	//Impl
	ContainerOperatorImpl(ISession* session);
	~ContainerOperatorImpl();

	//IOperator
	StatusCode Download(INode* target, const char* local_path) { return -1;};
	StatusCode Upload(INode* target, const char* local_path, unsigned int overwrite, INode** result) { return -1;};
	int GetProgress(char** name) { return 0;};
	StatusCode Bind(INode* node) { return SRB_ERROR_TYPE_NOT_SUPPORTED;};
	//IContainerOperator
	StatusCode Rename(IContainerNode* target, const char* name);
	StatusCode Delete(IContainerNode* target);
	int GetType() { return SOB_OP_CONTAINER; };
	//PURGE_FLAG - purge the cache copies after sync is done.
	//PRIMARY_FLAG - Synchronize to the primary archival resource instead of all archival resources.
	StatusCode Sync(IContainerNode* target, unsigned int flag = 0);

private:
	ContainerOperatorImpl();
	ContainerOperatorImpl(const ContainerOperatorImpl& source);
	ContainerOperatorImpl& operator =(const ContainerOperatorImpl& source);

	void ClearMCATScratch();
	mdasC_sql_result_struct m_result;
	char m_qval[MAX_DCS_NUM][MAX_TOKEN];
	int m_selval[MAX_DCS_NUM];
	ISession* m_session;
};

}//end namespace
#endif __SRB_OBJECT_CONTAINER_OPERATOR_H__

