#include "soDataset.h"
#include "soQuery.h"

extern "C"
{
extern char dcs_tname[MAX_DCS_STRUCTS][MAX_TOKEN];
extern char dcs_aname[MAX_DCS_STRUCTS][MAX_TOKEN]; 
}

namespace SRB
{

#define DATASET_VERIFY_AND_COPY(mcat_struct, mcat_value, pointer, index, variable) \
	pointer = getFromResultStruct(mcat_struct,dcs_tname[mcat_value], dcs_aname[mcat_value]); \
	if(pointer) \
	{ \
		pointer += index; \
		variable = strdup(pointer); \
	}else \
	{ \
		variable = strdup(""); \
	} \

DatasetNodeImpl::DatasetNodeImpl(INode* parent, mdasC_sql_result_struct* result, int index)
{
	m_parent = parent;
	m_path = NULL;
	m_children = NULL;
	m_uncle = NULL;
	m_isOpen = SOB_NONE;

	char* szptr;

	int step = index * MAX_DATA_SIZE;
      
	DATASET_VERIFY_AND_COPY(result,DATA_NAME, szptr, step, m_name);
	DATASET_VERIFY_AND_COPY(result,SIZE, szptr, step,m_size);
	DATASET_VERIFY_AND_COPY(result,DATA_OWNER, szptr, step,m_owner);
	DATASET_VERIFY_AND_COPY(result,REPL_TIMESTAMP, szptr, step,m_timeStamp);
	DATASET_VERIFY_AND_COPY(result,DATA_REPL_ENUM, szptr, step,m_replicationIndex);
//	DATASET_VERIFY_AND_COPY(result,RSRC_NAME, szptr, step,m_logi_resc);
	DATASET_VERIFY_AND_COPY(result,PHY_RSRC_NAME, szptr, step, m_phys_resc);
	DATASET_VERIFY_AND_COPY(result,CONTAINER_NAME, szptr, step,m_container);
	DATASET_VERIFY_AND_COPY(result,DATA_TYP_NAME, szptr, step,m_dataType);
	DATASET_VERIFY_AND_COPY(result,DATA_COMMENTS, szptr, step,m_comment);
}

DatasetNodeImpl::DatasetNodeImpl(INode* parent, char* name,char* size,char* owner,char* time,char* repl,char* logi_resc, char* phys_resc,char* container,char* type,char* comment)
{
	m_parent = parent;
	m_path = NULL;
	m_children = NULL;
	m_uncle = NULL;
	m_isOpen = SOB_NONE;

	m_name = strdup(name);
	m_size = strdup(size);
	m_owner = strdup(owner);
	m_timeStamp = strdup(time);
	m_replicationIndex = strdup(repl);
	m_logi_resc = strdup(logi_resc);
	m_phys_resc = strdup(phys_resc);
	m_container = strdup(container);
	m_dataType = strdup(type);
	m_comment = strdup(comment);
}

DatasetNodeImpl::~DatasetNodeImpl()
{
	//safe method. later we can optimize for strings we know must always be allocated
	if(m_name != NULL)
		free(m_name);
	if(m_path != NULL)
		free(m_path);
	if(m_size != NULL)
		free(m_size);
	if(m_owner != NULL)
		free(m_owner);
	if(m_timeStamp != NULL)
		free(m_timeStamp);
	SMART_FREE(m_replicationIndex);
	SMART_FREE(m_phys_resc);
//	SMART_FREE (m_logi_resc);
	if(m_container != NULL)
		free(m_container);
	if(m_dataType != NULL)
		free(m_dataType);
	if(m_comment != NULL)
		free(m_comment);

	INode* child;

	if(m_uncle)
		delete m_uncle;

	if(m_children)
	{
		int count = m_children->size();
		for(int i = count - 1; i >= 0; i--)
		{
			child = m_children->at(i);
			delete child;
		}
		delete m_children;
	}
}

void DatasetNodeImpl::Wash(char* size, char* owner, char* time, char* repl, char* logi_resc, char* phys_resc, char* container, char* type, char* comment)
{
	//1. Delete
	free(m_size);
	free(m_owner);
	free(m_timeStamp);
	free(m_replicationIndex);
	free(m_phys_resc);
	free(m_container);
	free(m_dataType);
	free(m_comment);

	//children, including metadata and access rights, stay the same

	//2. ReCreate
	//Note some variables like the parent and any uncles are and should stay untouched
	m_size = strdup(size);
	m_owner = strdup(owner);
	m_timeStamp = strdup(time);
	m_replicationIndex = strdup(repl);
	m_logi_resc = strdup(logi_resc);
	m_phys_resc = strdup(phys_resc);
	m_container = strdup(container);
	m_dataType = strdup(type);
	m_comment = strdup(comment);
}


const char* DatasetNodeImpl::GetPath()
{
	int size;
	
	if(NULL == m_path)
	{
		size = strlen(m_parent->GetPath());

		size += strlen(m_name);

		m_path = new char[size + 2];	//one for '/' and one for null

		sprintf(m_path, "%s/%s", m_parent->GetPath(), m_name);
	}

	return m_path;
}

//inline
INode* DatasetNodeImpl::GetChild(int pos)
{
	if(m_children && pos < m_children->size() && pos >= 0)
			return m_children->at(pos);
	
	return NULL;
}

INode* DatasetNodeImpl::GetUncle(int pos)
{
	if(m_uncle && pos < m_uncle->size() && pos >= 0)
			return m_uncle->at(pos);
	
	return NULL;
}

//it's inefficient, but since we don't add new nodes in any set order and the data
//structure's a vector, we have to search through all possibilites.
IDatasetNode* DatasetNodeImpl::GetReplicant(int replication_index)
{
	if(replication_index < 0)
		return NULL;

	if(replication_index == atoi(m_replicationIndex))
		return this;

	int count = m_parent->CountChildren();

	INode* node;

	for(int i = 0; i < count; i++)
	{
		node = m_parent->GetChild(i);

		if(SOB_DATASET == node->GetType())
		{
			if(0 == strcmp(node->GetName(), m_name))
			{
				if(replication_index == atoi(((IDatasetNode*)node)->GetReplicationIndex()))
					return (IDatasetNode*)node;
			}
		}
	}

	return NULL;
}

//inline
int DatasetNodeImpl::CountChildren()
{
	if(m_children)
		return m_children->size();

	return 0;
}

int DatasetNodeImpl::CountUncles()
{
	if(m_uncle)
		return m_uncle->size();

	return 0;
}


int DatasetNodeImpl::CountHeightFromRoot()
{
	if(NULL == m_parent)
	{
		return 0;
	}

	return m_parent->CountHeightFromRoot() + 1;
}


StatusCode DatasetNodeImpl::DeleteChild(INode* child)
{
	if(NULL == m_children)
		return SRB_ERROR_INVALID_PARAMETER;

	std::vector<INode*>::iterator i = m_children->begin();

	for(i; i != m_children->end(); i++)
	{
		if(*i == child)
		{
			m_children->erase(i);

			int ucount = child->CountUncles();
			if(ucount)
			{
				QueryNodeImpl* query;
				for(int i = 0; i < ucount; i++)
				{
					query = (QueryNodeImpl*)child->GetUncle(i);
					query->RemoveChild(child);
				}
			}

			delete child;

			return SRB_OK;
		}
	}

	return SRB_ERROR;
}



/*
this function takes a char string. if the string begins
with a / it will perceive it as a relative path otherwise it will
take take the entire path as a name. trailing / may be
present or omitted.
*/
INode* DatasetNodeImpl::GetChild(const char* name)
{
	if((NULL == name)||(NULL == m_children))
		return NULL;

	INode* child;
	char *szname;
	if('/' == name[0])
	{
		szname = strdup(name);

		int len = strlen(name);

		for(int j = 1; j < len; j++)
		{
			if('/' == szname[j])
			{
				szname[j] = 0;
				break;
			}
		}

		child = GetChild(szname);

		if(NULL == child)
		{
			free(szname);
			return NULL;
		}

		if(j < len)
		{
			child = child->GetChild(&szname[j+1]);
		}

		free(szname);

		return child;
	}else
	{
		for(int i = 0; i < m_children->size(); i++)
		{
			child = m_children->at(i);
			if(0 == strcmp(name, child->GetName()))
			{
				return child;
			}
		}
		
		return NULL;
	}

	//should never reach here
	return NULL;
}
StatusCode DatasetNodeImpl::GetChild(const char* name, INode** result)
{
	if(NULL == name)
		return NULL;

	if(NULL == result)
		return NULL;

	INode* child;
	char *szname;

	StatusCode status;

	if('/' == name[0])
	{
		szname = strdup(name);

		int len = strlen(name);

		for(int j = 1; j < len; j++)
		{
			if('/' == szname[j])
			{
				szname[j] = 0;
				break;
			}
		}

		status = GetChild(&szname[1], &child);

		if(!status.isOk())
		{
			free(szname);
			*result = child;
			return status;
		}

		if(j < len)
		{
			status = child->GetChild(&szname[j+1], &child);
		}

		free(szname);
		*result = child;
		return status;

	}else
	{
		if(m_children)
		{
			for(int i = 0; i < m_children->size(); i++)
			{
				child = m_children->at(i);
				if(0 == strcmp(name, child->GetName()))
				{
					*result = child;
					return SRB_OK;
				}
			}
		}else
		{
			*result = this;
			return SRB_ERROR_NOT_FILLED;
		}
	}

	//should never reach here
	*result = NULL;
	return SRB_ERROR;
}


void DatasetNodeImpl::Clear()
{
	if(NULL == m_children)
		return;

	std::vector<INode*>::iterator begin, end;

	if(m_children)
	{
		begin = m_children->begin();
		end = m_children->end();

		for(begin; begin != end; begin++)
		{
			delete *begin;
		}

		delete m_children;
		m_children = NULL;
	}

	m_isOpen = SOB_NONE;
}

void DatasetNodeImpl::AddChild(INode* child)
{
	if(NULL == m_children)
	{
		m_children = new std::vector<INode*>;
	}
	
	m_children->push_back(child);
}

void DatasetNodeImpl::AddUncle(INode* uncle)
{
	if(NULL == m_uncle)
	{
		m_uncle = new std::vector<INode*>;
	}
	
	m_uncle->push_back(uncle);
}

StatusCode DatasetNodeImpl::SetName(const char* name)
{
	if(NULL == name)
		return SRB_ERROR_INVALID_PARAMETER;

	if(m_path)
		free(m_path);

	if(m_name)
		free(m_name);

	m_name = strdup(name);

	return SRB_OK;
}

void DatasetNodeImpl::SetComment(const char* comment)
{
	if(m_comment)
	{
		free(m_comment);
		m_comment = NULL;
	}

	if(NULL != comment && '\0' != comment[0])
		m_comment = strdup(comment);
}

}//end namespace