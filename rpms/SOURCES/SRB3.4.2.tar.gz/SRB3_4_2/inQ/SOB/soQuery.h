#ifndef __SRB_OBJECT_QUERY_NODE_H__
#define __SRB_OBJECT_QUERY_NODE_H__
#include "soGlobals.h"
#include "soNode.h"
#include "mdasC_db2_externs.h"
#include <vector>

namespace SRB
{
class QueryNodeImpl: public IQueryNode
{
public:
	QueryNodeImpl();
	QueryNodeImpl(INode* parent, IMetadataNode* query);
	 ~QueryNodeImpl();

	const char* GetName();
	const char* GetPath();
	INode* GetParent() {return m_parent;};
	INode* GetChild(int pos);
	unsigned int GetType() { return SOB_QUERY;};

	int CountChildren();
	int CountHeightFromRoot();

	INode* GetChild(const char* name);
	StatusCode GetChild(const char* name, INode** result);

	bool isOpen(unsigned int mask = SOB_ALL) { return ((m_isOpen & mask) == mask); };
	unsigned int GetOpen() { return m_isOpen;};

	INode* GetUncle(int pos) { return NULL;};
	int CountUncles() { return 0;};


	//impl
	void AddChild(INode* Child);
	StatusCode RemoveChild(INode* target);
	void Clear(bool deleteMeta);
	void Close();
	void SetOpen(unsigned int mask) { m_isOpen = mask;};
	void AddChildFront(INode* child);
	void SetParent(INode* parent) { m_parent = parent; };

private:

	QueryNodeImpl(const QueryNodeImpl& source);
	QueryNodeImpl& operator =(const QueryNodeImpl& source);

	char* m_name;
	char* m_path;
	std::vector<INode*> *m_children;
	INode* m_parent;
	unsigned int m_isOpen;

};

}//end namespace
#endif

#if 0

class IQueryOperator : public IOperator
{
	//query operator keeps pointer to its own Node, deletes upon destruction.
	//Node must contain pointers to objects from ISession::GetRoot() tree so that path info will be
	//correct. Modifications to tree will also therefore reflect in root tree.

	//clears query and results. Allows one to add/change to query after a query operation. Calling
	//Query() again keeps pointer to root node, but erases all of its children, runs query again
	//with modified parameters.
	virtual void Clear();

	virtual const char* GetQueryString();	//returns a printable string version of the query.

	virtual IMetaDataNode* Add(const char* parameter) = 0;

	//the below two fail if the parameter node already has children.
	virtual void SetValue(IMetaDataNode* parameter, const char* value) = 0;
	virtual void SetOperation(IMetaDataNode* parameter, int) = 0;
	virtual void Delete(IMetaDataNode* parameter) = 0;

	//for these, one cannot be a child of the other, etc. the results of these two operations is
	//one new MetaDataNode with only the operation AND/OR (attribute/values are NULL) and 0 is
	//left and 1 is right.
	virtual IMetaDataNode* And(IMetaDataNode* left, IMetaDataNode* right) = 0;
	virtual IMetaDataNode* Or(IMetaDataNode* left, IMetaDataNode* right) = 0;

	virtual StatusCode Query(ICollectionNode* target, IQueryNode** result) = 0;
};

QueryNodes should have pointers to nests of collections and datasets. the collections and datasets
that match the query are open by default (because we are acting on their metadata, they need to be
open of course! =) but child datasets and collections of a collection are not open by default.
QueryNodes do not try to map to the root node tree. Therefore the trees do not have to be the same.

part of the reason for this is that an n-height tree may only be open n-m levels. you need results
on the whole tree and you need them fast. hence it's proper simply to make new nodes for each query.

memory conservation may become an issue. if so implement a simple way to garbage collect. also might
implement a static variable telling when something's changed across the whole space so two different
trees know what's going on...

query might implement their own code to query for collections and datasets, but they should use
the impl constructors to populate the objects themselves...


as far as nested queries go...

the querynode should have as its first child the metadata node which represents the query.
if the query has ands and/or ors then the metadata node will represent a nested query.

A query node is just a display item, just like every other node. QueryOperators act on and create
the display items (nodes). when you want to query, you must supply a node in the hierarchy as a
starting point. this can be a collection, resource, container node, dataset, etc. If you supply
a query node then the query becomes nested. this means that the new query becomes ANDed to the old query.
then, the new query becomes a child of the older query. All the children of the new query by logic must
come from the set of children above in the parent node. Hence, the children of the new query will all be
children of the old query as well. But there may be some children of the old query that aren't in the new
one. There is some talk about removing duplicate entries since by definition if it's in the new query and
the new query itself is a child of the old query then by implication it must be a child of the old query
as well. In this case the operator would complete the tree and then build a table to remove duplicate
entries.


QueryOperator

2 nodes:

querynode: node is the result of queries. contains metadata nodes (the query itself), collections,
datasets, etc.

metadatanode: node which contains either an attribute/value pair or an operation, with two operands as
children. the node contains the following:

attribute operation value
metadata nodes which are children of a collection contain the attribute value pair. hence attribute=value.
= is the op.

when querying you can use = as an op or you can use other ops in your query.

when the op is AND or OR then it is a join node and it has NULL attribute and values.

#endif
