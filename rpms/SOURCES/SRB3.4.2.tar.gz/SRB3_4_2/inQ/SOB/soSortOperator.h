#if ENABLE_SORTING
#ifndef __SRB_OBJECT_SORT_OPERATOR_H__
#define __SRB_OBJECT_SORT_OPERATOR_H__

#include "soGlobals.h"
#include "soNode.h"
#include "clConnectExtern.h"
#include "soMetadata.h"
#include "soSort.h"

namespace SRB
{
class SortOperatorImpl : public ISortOperator
{
public:
	SortOperatorImpl(const srbConn& session, ICollectionNode* root);
	 ~SortOperatorImpl();
	INode* GetBinding() { return NULL;};
	StatusCode Download(INode* target, const char* local_path) { return -1;};
	StatusCode Upload(INode* target, const char* local_path) { return -1;};
	ISortNode* GetSort() { return m_sort_result;};
	ICollectionNode* GetRootCollection() {return m_root;};
	IMetadataNode* Add(const char* attribute);
	StatusCode Remove(IMetadataNode* attribute);
	StatusCode Move(IMetadataNode* inFrontOf, IMetadataNode* attribute);

private:
	StatusCode GetAttributes();
	void ClearMCATScratch();

	mdasC_sql_result_struct m_result;
	char m_qval[MAX_DCS_NUM][MAX_TOKEN];
	int m_selval[MAX_DCS_NUM];

	srbConn* m_conn;

	ICollectionNode* m_root;
	SortNodeImpl* m_sort_result;


};
}//end namespace

#endif __SRB_OBJECT_SORT_OPERATOR_H__
#endif

