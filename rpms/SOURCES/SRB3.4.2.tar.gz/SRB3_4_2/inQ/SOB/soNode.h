#ifndef __SRB_OBJECT_NODE_H__
#define __SRB_OBJECT_NODE_H__

#include "soStatusCode.h"

namespace SRB
{
class INode
{
public:
	virtual ~INode() {};
	virtual const char* GetName() = 0;
	virtual const char* GetPath() = 0;
	virtual INode* GetParent() = 0;
	virtual INode* GetChild(int pos) = 0;
	virtual unsigned int GetType() = 0;

	virtual int CountChildren() = 0;
	virtual int CountHeightFromRoot() = 0;

	//if initial character is '/' then traverse path
	virtual INode* GetChild(const char* name) = 0;
	virtual StatusCode GetChild(const char* name, INode** result) = 0;

	virtual bool isOpen(unsigned int mask = SOB_ALL) = 0;
	virtual unsigned int GetOpen() = 0;

	virtual INode* GetUncle(int pos) = 0;
	virtual int CountUncles() = 0;
};

class IMetadataNode: public INode
{
public:
	virtual ~IMetadataNode() {};
	virtual const char* GetAttribute() = 0;
	virtual const char* GetValue() = 0;
	virtual int GetOperation() = 0;
	virtual const char* GetOperationString() = 0;
};

class IStringNode: public INode
{
public:
	virtual ~IStringNode() {};
	virtual const char* GetString(int pos) = 0;
	virtual int CountStrings() = 0;
};

class IDatasetNode : public INode
{
public:
	virtual ~IDatasetNode() {};
	virtual const char* GetSize() = 0;
	virtual const char* GetOwner() = 0;
	virtual const char* GetTimeStamp() = 0;
	virtual const char* GetReplicationIndex() = 0;
	virtual const char* GetLogicalResource() = 0;
	virtual const char* GetPhysicalResource() = 0;
	virtual const char* GetContainer() = 0;
	virtual const char* GetDataType() = 0;
	virtual	const char* GetComment() = 0;
	virtual IDatasetNode* GetReplicant(int replication_index) = 0;
};

class ISoftLinkNode : public INode
{
public:
	virtual ~ISoftLinkNode() {};
	virtual const char* GetSize() = 0;
	virtual const char* GetOwner() = 0;
	virtual const char* GetTimeStamp() = 0;
	virtual const char* GetReplicationIndex() = 0;
	virtual const char* GetLogicalResource() = 0;
	virtual const char* GetPhysicalResource() = 0;
	virtual const char* GetContainer() = 0;
	virtual const char* GetDataType() = 0;
	virtual	const char* GetComment() = 0;
	virtual ISoftLinkNode* GetReplicant(int replication_index) = 0;
};

class IAccessNode : public INode
{
public:
	virtual ~IAccessNode() {};
	virtual const char* GetGroup() = 0;
	virtual const char* GetDomain() = 0;
	virtual const char* GetUser() = 0;
	virtual const char* GetConstraint() = 0;
};

class ICollectionNode : public INode
{
public:
	virtual ~ICollectionNode() {};
};

class IResourceNode : public INode
{
public:
	virtual ~IResourceNode() {};
	virtual const char* GetResourceType() = 0;
};

class IContainerNode : public INode
{
public:
	virtual ~IContainerNode() {};
	virtual const char* GetContainerPath() = 0;
};

class IDomainNode : public INode
{
public:
	virtual ~IDomainNode() {};
};

class ISetNode : public INode
{
public:
	virtual ~ISetNode() {};
	virtual unsigned int GetSetType() = 0;
};

/*
ZoneNode will be a node which contains as children the root collection node
for that zone's tree, as well as that zone's domain and resource nodes. Currently,
the domain and resource nodes are nested in a null domain or resource node, which
we will dispense with.

Zone nodes won't contain session info, or have functionality specific to the user.
We will leave that for the MCAT Node, or the Session.

Note that creating a zone node takes lot of the messier stuff out of session.
*/
class IZoneNode : public INode
{
public:
	virtual ~IZoneNode() {};
};

class IMCATNode : public INode
{
public:
	virtual ~IMCATNode() {};
};

class IUserNode : public IDomainNode
{
public:
	virtual ~IUserNode() {};
};

#if ENABLE_SORTING
class ISortNode : public INode
{
public:
};
#endif

class IQueryNode : public INode
{
public:
	virtual ~IQueryNode() {};
};

class IOperator
{
public:
	virtual ~IOperator() {};
	virtual StatusCode Bind(INode* node) = 0;
	virtual int GetType() = 0;
};

class ITransferOperator : public IOperator
{
public:
	virtual ~ITransferOperator() {};
	virtual StatusCode Download(INode* target, const char* local_path) = 0;
	virtual StatusCode Upload(INode* target, const char* local_path, unsigned int overwrite, INode** result = 0) = 0;
	virtual int GetProgress(char** name) = 0;
};

class ISession
{
public:
	virtual ~ISession() {};
	virtual IStringNode* GetAccessConstraints() = 0;
	virtual StatusCode Clone(ISession* target) = 0;
	virtual IOperator* GetOperator(int type) = 0;
	virtual StatusCode Connect()  = 0;
	virtual StatusCode Disconnect()  = 0;
	virtual bool isConnected() = 0;
	virtual StatusCode ChangePassword(const char* new_password)  = 0;
	virtual StatusCode OpenTree(INode* parent, int levels, bool clear, unsigned int mask = SOB_ALL)  = 0;
	virtual StatusCode CloseTree(INode* parent) = 0;
	virtual ICollectionNode* GetUserRootCol() = 0;
	virtual ICollectionNode* GetUserHomeCol() = 0;
	virtual IMCATNode* GetMCAT() = 0;
	virtual IZoneNode* GetUserZone() = 0;
	virtual const char* GetUserDomain() = 0;
	virtual ICollectionNode* GetUserHome() = 0;


	virtual ISetNode* GetDomain(IZoneNode* zone) = 0;
	virtual ISetNode* GetResource(IZoneNode* zone) = 0;
	virtual ICollectionNode* GetRoot(IZoneNode* zone) = 0;
	virtual ICollectionNode* GetLocalRoot() = 0;
	virtual ICollectionNode* GetHome(IZoneNode* zone) = 0;

	virtual IZoneNode* GetCurrentZone(INode* target) = 0;


	virtual const char* GetName() = 0;
	virtual const char* GetUserHost() = 0;
	virtual const char* GetUserAuthScheme() = 0;
	virtual const char* GetUserPortValue() = 0;
	virtual void* GetConn() = 0;
	virtual void* CloneConn() = 0;
};


class IDatasetOperator : public ITransferOperator
{
public:
	virtual ~IDatasetOperator() {};
	virtual StatusCode Delete(IDatasetNode* target) = 0;
	virtual StatusCode Replicate(IDatasetNode* target) = 0;
	virtual StatusCode Rename(IDatasetNode* target, const char* name) = 0;
	virtual StatusCode SetComment(IDatasetNode* target, const char* comment) = 0;
	virtual StatusCode AddMeta(IDatasetNode* target, const char* attribute, IMetadataNode** result = 0) = 0;
	virtual StatusCode ModifyMeta(IMetadataNode* target, const char* value) = 0;
	virtual StatusCode DeleteMeta(IMetadataNode* target) = 0;
	virtual StatusCode ModifyAccess(IAccessNode* target, const char* permission) = 0;
	virtual StatusCode SetAccess(IDatasetNode* target, IUserNode* owner, const char* permission) = 0;

};

class ICollectionOperator : public ITransferOperator
{
public:
	virtual ~ICollectionOperator() {};
	virtual StatusCode Copy(ICollectionNode* target, IDatasetNode* data, IDatasetNode** result = 0) = 0;
	virtual StatusCode Copy(ICollectionNode* target, ICollectionNode* data, ICollectionNode** result = 0) = 0;
	virtual StatusCode Move(ICollectionNode* target, IDatasetNode* data, IDatasetNode** result = 0) = 0;
	virtual StatusCode Move(ICollectionNode* target, ICollectionNode* data, ICollectionNode** result = 0) = 0;
	virtual StatusCode Delete(ICollectionNode* target) = 0;
	virtual StatusCode Replicate(ICollectionNode* target) = 0;
	virtual StatusCode Rename(ICollectionNode* target, const char* name) = 0;
	virtual StatusCode SetComment(ICollectionNode* target, const char* comment) = 0;
	virtual StatusCode Create(ICollectionNode* target, const char* name, ICollectionNode** result = 0) = 0;	//optional param sets result to the Node of the new collection

	virtual StatusCode AddMeta(ICollectionNode* target, const char* attribute, IMetadataNode** result = 0) = 0;
	virtual StatusCode ModifyMeta(IMetadataNode* target, const char* value) = 0;
	virtual StatusCode DeleteMeta(IMetadataNode* target) = 0;

	virtual StatusCode ModifyAccess(IAccessNode* target, const char* permission, bool recursive) = 0;
	virtual StatusCode SetAccess(ICollectionNode* target, IUserNode* owner, const char* permission, bool recursive) = 0;

};

class IResourceOperator : public IOperator
{
public:
	virtual ~IResourceOperator() {};
	virtual StatusCode Create(IResourceNode* target, const char* name, IContainerNode** result = 0) = 0;
};

class IDomainOperator : public IOperator
{
public:
	virtual ~IDomainOperator() {};
};

class IZoneOperator : public IOperator
{
public:
	virtual ~IZoneOperator() {};
	virtual IZoneNode* GetZones() {return NULL;};
};

class IMCATOperator : public IOperator
{
public:
	virtual ~IMCATOperator() {};
	virtual IMCATNode* GetZones() {return NULL;};
	virtual StatusCode FindZone4User(const char* domain, const char* user, char* zone_buf) = 0;
};

class IQueryOperator : public IOperator
{
public:
	virtual ~IQueryOperator() {};

	virtual IMetadataNode* GetQuery() = 0;

	virtual const char* GetQueryString() = 0;

	virtual IMetadataNode* Add(const char* attribute) = 0;

	virtual void SetValue(IMetadataNode* parameter, const char* value) = 0;
	virtual void SetOperation(IMetadataNode* parameter, int) = 0;
	virtual void Delete(IMetadataNode* parameter) = 0;

	virtual IMetadataNode* And(IMetadataNode* left, IMetadataNode* right) = 0;
	virtual IMetadataNode* Or(IMetadataNode* left, IMetadataNode* right) = 0;

	virtual StatusCode Query(ICollectionNode* target, IQueryNode** result) = 0;
};

class IContainerOperator : public IOperator
{
public:

	virtual ~IContainerOperator() {};
	virtual StatusCode Rename(IContainerNode* target, const char* name) = 0;
	virtual StatusCode Delete(IContainerNode* target) = 0;
	virtual StatusCode Sync(IContainerNode* target, unsigned int flag = 0) = 0;
};

class IQueryOperator2 : public IOperator
{
public:
	virtual ~IQueryOperator2() {};
	//query operations
	virtual StatusCode Create(IQueryNode** query) = 0;
	virtual StatusCode Delete(IQueryNode* query) = 0;
	virtual StatusCode Nest(IQueryNode* parent, IQueryNode* child) = 0;
	virtual StatusCode Attach(IQueryNode* query, IMetadataNode* expression) = 0;
	virtual StatusCode Bind(IQueryNode* query, INode* node) = 0;

	//expression operations
	virtual StatusCode Add(IMetadataNode** expression) = 0;
	virtual StatusCode Remove(IMetadataNode* expression) = 0;
	virtual StatusCode SetValue(IMetadataNode* expression, const char* value) = 0;
	virtual StatusCode SetAttribute(IMetadataNode* expression, const char* attribute) = 0;
	virtual StatusCode SetOperation(IMetadataNode* expression, int operation) = 0;
	virtual StatusCode And(IMetadataNode* left, IMetadataNode* right, IMetadataNode** result) = 0;
	virtual StatusCode Or(IMetadataNode* left, IMetadataNode* right, IMetadataNode** result) = 0;
};

#if ENABLE_SORTING
class ISortOperator : public IOperator
{
public:
	virtual ~ISortOperator() {};
	virtual ISortNode* GetSort() = 0;
	virtual ICollectionNode* GetRootCollection() = 0;
	virtual IMetadataNode* Add(const char* attribute) = 0;
	virtual StatusCode Remove(IMetadataNode* attribute) = 0;
	virtual StatusCode Move(IMetadataNode* inFrontOf, IMetadataNode* attribute) = 0;
};
#endif

}	//end namespace
#endif __SRB_OBJECT_NODE_H__
