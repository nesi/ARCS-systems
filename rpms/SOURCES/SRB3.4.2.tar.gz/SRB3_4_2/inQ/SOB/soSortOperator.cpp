#if ENABLE_SORTING
#include "soSortOperator.h"
#include "clStubExtern.h"
#include "scommands.h"
#include "clAuthExtern.h"



/*
	queries are inherantly flat. sorts are inherantly hierarchical.
	a query can thus have as its metadata node the query (perhaps nested itself) in one
	central location, but if the query were nested, the derived portion of the query would
	be stored in the metadata node of the nested query node itself.

	hence, since a sort is hierarchical, it can likewise store the sort parameters throughout
	its tree-structure without breaking our model.


	Result passed to user by operator: root sort-tree node.
		sortnode has as its metadata node the primary attribute, value field is blank.
			sortnode's childnodes are sortnodes with names = to one of the values of the parent
			and the metadata stores the attribute it's children are values of.


  sort nodes should be like metadata nodes in that they have an attribute and a value
  and the name reflects the combination of the two.


  we have to be able to fill them one at a time, just like a collection. We can't just open
  all the non-leaf nodes in advance. which means the sort has to have a master sort list after
  all. but the list can be in the operator for right now, just a list of strings.

  actually, the list of strings can be stored in the operator just like the query operator has a
  member variable. but I think ultimately there must be a pointer to this variable in the root
  sort node just as there is a pointer to the query in the root query node.

  */



namespace SRB
{

	//to use a tree (with hierarchy) as a list is kind of retarded.

SortOperatorImpl::SortOperatorImpl(const srbConn& session, ICollectionNode* root)
{
	m_conn = (srbConn*)&session;
	m_root = root;
	m_sort_result = new SortNodeImpl();
	m_sort_order = new SortNodeImpl();
}

SortOperatorImpl::~SortOperatorImpl()
{
}

IMetadataNode* SortOperatorImpl::Add(const char* attribute)
{
	//no checking yet for dupes
	if(attribute == NULL)
		return NULL;

	MetadataNodeImpl* new_meta = new MetadataNodeImpl(m_sort_order, attribute);
	new_meta->SetOperation(SOB_MD_SORT);
	
	
	MetadataNodeImpl* blah = (MetadataNodeImpl*)m_sort_order->GetChild(0);
	
	new_meta->SetValue("meta");

	m_sort_order->AddNodeFront(new_meta);	//this way, newest (and lowest valued meta) is always at front

	return new_meta;
}

StatusCode SortOperatorImpl::Remove(IMetadataNode* attribute)
{
	if(attribute == NULL)
	{
		return -1;
	}

	const char* name = attribute->GetName();

	IMetadataNode* result = (IMetadataNode*)m_sort_order->GetChild(name);

	StatusCode retval;

	while(true)
	{
		if(NULL == result)
		{
			retval = -1;
			break;
		}

		if(result == attribute)	//ptr compare
		{
			m_sort_order->RemoveNode(result);
			delete result;
			retval = SRB_OK;
			break;
		}

		result = (IMetadataNode*)m_sort_order->GetNext(result, false);

	}

	return retval;
}

StatusCode SortOperatorImpl::Move(IMetadataNode* inFrontOf, IMetadataNode* attribute)
{
	if((NULL == inFrontOf)||(NULL == attribute))
	{
		return -1;
	}

	m_sort_order->MoveNode(attribute, inFrontOf);
	return SRB_OK;
}

/////New stuff

void SortOperatorImpl::ClearMCATScratch()
{
    clearSqlResult(&m_result);

    for(int i = 0; i < MAX_DCS_NUM; i++)
	{
        sprintf(m_qval[i],"");
        m_selval[i] = 0;
    }
}

StatusCode SortOperatorImpl::GetAttributeList()
{
	ClearMCATScratch();
	m_selval[UDSMD_COLL0] = 1;

	sprintf(m_qval[DATA_GRP_NAME]," = '%s'", m_directory);

	StatusCode status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
	{
		return status;
	}

	filterDeleted(&m_result);

	char* attribute;
	IMetadataNode* child;

	for(int i = 0; i < m_result.row_count; i++)
	{
		attribute = getFromResultStruct(&m_result,dcs_tname[UDSMD_COLL0], dcs_aname[UDSMD_COLL0]);
		attribute += i * MAX_DATA_SIZE;
		child = new MetadataNodeImpl(m_sort_order, attribute);
		m_sort_order->AddNode(child);
	}

	clearSqlResult(&m_result);
	sprintf(m_qval[DATA_GRP_NAME]," like '%s/%%'", directory);

	status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
	{
		return status;
	}

	filterDeleted(&m_result);
	
	for(int i = 0; i < m_result.row_count; i++)
	{
		attribute = getFromResultStruct(&m_result,dcs_tname[UDSMD_COLL0], dcs_aname[UDSMD_COLL0]);
		attribute += i * MAX_DATA_SIZE;
		child = new MetadataNodeImpl(m_sort_order, attribute);
		m_sort_order->AddNode(child);
	}

	return SRB_OK;
}

void SortOperatorImpl::GetValueList(IMetadataNode* node)
{
	if((value == NULL)||(node == NULL))
	{
		return;
	}

	ClearMCATScratch();
	m_selval[UDSMD_COLL1] = 1;

	sprintf(m_qval[DATA_GRP_NAME]," = '%s'", m_directory);
	sprintf(m_qval[UDSMD_COLL0]," = '%s'", node->GetAttribute());

	StatusCode status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if((-3005 != status)||(0 != status))
	{
		return;
	}

	filterDeleted(&m_result);

	SortNodeImpl* child;
	const char* value;

	for(int i = 0; i < m_result.row_count; i++)
	{
		//get name
		value = getFromResultStruct(&m_result,dcs_tname[UDSMD_COLL0], dcs_aname[UDSMD_COLL0]);
		value += i * MAX_DATA_SIZE;

		//creating new node
		child = new MetadataNodeImpl(node, value);	//putting it in attribute section
		node->AddNode(child);
	}

	clearSqlResult(&m_result);
	sprintf(m_qval[DATA_GRP_NAME]," like '%s/%%'", directory);

	status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	//status good on -3005 or 0

	filterDeleted(&m_result);
	
	for(int i = 0; i < m_result.row_count; i++)
	{
		//get name
		value = getFromResultStruct(&m_result,dcs_tname[UDSMD_COLL0], dcs_aname[UDSMD_COLL0]);
		value += i * MAX_DATA_SIZE;

		//creating new node
		child = new MetadataNodeImpl(node, value);	//putting it in attribute section
		node->AddNode(child);
	}

	//check for continuation index later

}


StatusCode SortOperatorImpl::GetChildren()
{
	if(NULL == m_sort_order)
		return -1;

	GetAttributeList();	//just take the default order for now & go straight to getting the values!

	int count = m_sort_order->CountChildren();
	IMetadataNode* ptr;

	for(int i = 0; i < count; i++)
	{
		ptr = m_sort_order->GetChild(i);

		GetValueList(ptr);
	}

	//now m_sort_order is a sort node with metadata children. each child is named by an attribute
	//and has as its children the set of all possible values for it.

	SortNodeImpl *blah, *newbie, *parent = m_sort_result;

	IMetadataNode* h;

	count = m_sort_order->CountChildren();

	for(i = count - 1; i >= 0; i--)
	{
		ptr = m_sort_order->GetChild(i);	//ptr is one of the attributes, with all possible values as children
		newbie = new SortNodeImpl(parent, ptr->GetAttribute());

		for(int j = 0; j < ptr->CountChildren(); j++)
		{
			h = ptr->GetChild(j);
			blah = new SortNodeImpl(newbie, h->GetAttribute());
			if(0 == i)	//0 is the least important attribute
			{
				blah->SetOpen(false);	//leaf nodes have not been filled yet
			}else
			{
				blah->SetOpen(true);	//non-leaf nodes have been filled.
			}
			newbie->AddNode(blah);
		}
		m_sort_result->AddNode(newbie);
	}
}

StatusCode SortOperatorImpl::FillNode(SortNodeImpl* blah)
{
	if(blah->isOpen())	//(not really good. Actually fill node should check level and based on 0th level or not fill)
	{
		return SRB_OK;
	}

	//construct a query. hike up the parents one by one to obtain their attribute and value pairs.
	//use the data to set up a query on all the (5) attribute value pairs.

}



//the node is the node that we create the children under.
//the attribute is the attribute we're querying for
void SortOperatorImpl::CreateValueFolders(SortNodeImpl* node, const char* attribute)
{
	if(attribute == NULL)
	{
		return;
	}

	ClearMCATScratch();
	m_selval[UDSMD_COLL1] = 1;

	sprintf(m_qval[DATA_GRP_NAME]," = '%s'", m_directory);
	sprintf(m_qval[UDSMD_COLL0]," = '%s'", attribute);

	StatusCode status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if((-3005 != status)||(0 != status))
	{
		return;
	}

	filterDeleted(&m_result);

	char *child_value, *child_attribute, *child_collection;
	SortNodeImpl* child;

	for(int i = 0; i < m_result.row_count; i++)
	{
		//get name
		child_value = getFromResultStruct(&m_result,dcs_tname[UDSMD_COLL0], dcs_aname[UDSMD_COLL0]);
		child_value += i * MAX_DATA_SIZE;

		//creating new node
		child = new SortNodeImpl(node, child_value);
		node->AddNode(child);
	}

	clearSqlResult(&m_result);
	sprintf(m_qval[DATA_GRP_NAME]," like '%s/%%'", directory);

	status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	//status good on -3005 or 0

	filterDeleted(&m_result);
	
	for(int i = 0; i < m_result.row_count; i++)
	{
		//get name
		child_value = getFromResultStruct(&m_result,dcs_tname[UDSMD_COLL0], dcs_aname[UDSMD_COLL0]);
		child_value += i * MAX_DATA_SIZE;

		//creating new node
		child = new SortNodeImpl(node, child_value);
		node->AddNode(child);
	}

	//check for continuation index later

}

} //end namespace
#endif
