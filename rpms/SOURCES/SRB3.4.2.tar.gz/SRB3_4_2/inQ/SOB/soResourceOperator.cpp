#include "soResourceOperator.h"
#include "soResource.h"
#include "soContainer.h"
#include "scommands.h"
#include "clAuthExtern.h"
#include "clStubExtern.h"

namespace SRB
{

ResourceOperatorImpl::ResourceOperatorImpl(ISession* session)
{
	m_session = session;
	m_conn = (srbConn*)session->GetConn();


	m_result.result_count = 0;
	m_result.row_count = 0;
	m_resources = NULL;
}

ResourceOperatorImpl::~ResourceOperatorImpl()
{
	delete m_resources;
}

void ResourceOperatorImpl::ClearMCATScratch()
{
    clearSqlResult(&m_result);

    for(int i = 0; i < MAX_DCS_NUM; i++)
	{
        sprintf(m_qval[i],"");
        m_selval[i] = 0;
    }
}

StatusCode ResourceOperatorImpl::Create(IResourceNode* target, const char* name, IContainerNode** result)
{
	if(NULL == target || NULL == name)
		return SRB_ERROR_INVALID_PARAMETER;

	StatusCode status = srbContainerCreate(m_conn, 0, (char*)name, "", (char*)target->GetName(), 0);

	IContainerNode* child;

	char buf[1024];

	sprintf(buf, "/container/%s.%s/%s", m_session->GetName(), m_session->GetUserDomain(), name);

	if(status.isOk())
	{
		child = new ContainerNodeImpl(target, buf);	
		((ResourceNodeImpl*)target)->AddNode(child);
	}

	return status;
}

StatusCode ResourceOperatorImpl::GetAllContainers()
{
/*	if(NULL == m_resources)
		if(NULL == GetResources())
			return SRB_ERROR;
*/
	ClearMCATScratch();

	m_selval[CONTAINER_NAME] = 1;
	m_selval[CONTAINER_LOG_RSRC_NAME] = 1;

    sprintf(m_qval[CONTAINER_NAME], " like '/container/%s.%s/%%'",m_session->GetName(), m_session->GetUserDomain());

	StatusCode status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
		return status;

	if(0 == m_result.row_count)	//should mark all resources as open
	{
		for(int j = 0; j < m_resources->CountChildren(); j++)
			((ResourceNodeImpl*)(m_resources->GetChild(j)))->SetOpen(SOB_ALL);
		return SRB_OK;
	}

	filterDeleted(&m_result);

	char* szName = (char*)getFromResultStruct(&m_result, dcs_tname[CONTAINER_NAME], dcs_aname[CONTAINER_NAME]);
	char* szResource = (char*)getFromResultStruct(&m_result, dcs_tname[CONTAINER_LOG_RSRC_NAME], dcs_aname[CONTAINER_LOG_RSRC_NAME]);

	if(NULL == szName || NULL == szResource)
		return SRB_ERROR;

	ResourceNodeImpl* target = (ResourceNodeImpl*)m_resources->GetChild(szResource);

	if(NULL == target)
		return SRB_ERROR;

	char* szPrevResource = szResource;

	ContainerNodeImpl* child = new ContainerNodeImpl(target, szName);

	target->AddNode(child);

	for(i = 1; i < m_result.row_count; i++)
	{
		szName += MAX_DATA_SIZE;
		szResource += MAX_DATA_SIZE;

		if(0 != strcmp(szResource, szPrevResource))
		{
			target = (ResourceNodeImpl*)m_resources->GetChild(szResource);

			if(NULL == target)
				return SRB_ERROR;

			szPrevResource = szResource;
		}

		child = new ContainerNodeImpl(target, szName);
		target->AddNode(child);
	}

	for(int j = 0; j < m_resources->CountChildren(); j++)
		((ResourceNodeImpl*)(m_resources->GetChild(j)))->SetOpen(SOB_ALL);

	return SRB_OK;
}

StatusCode ResourceOperatorImpl::GetContainer(ResourceNodeImpl* target)
{
	char* zone = (char*)m_session->GetCurrentZone(target)->GetName();

	ClearMCATScratch();

	m_selval[CONTAINER_NAME] = 1;

    sprintf(m_qval[CONTAINER_NAME], " like '/%s/container/%s.%s/%%'", zone, m_session->GetName(), m_session->GetUserDomain());
	//sprintf(m_qval[CONTAINER_RSRC_NAME], " = '%s'", target->GetName());
	sprintf(m_qval[CONTAINER_LOG_RSRC_NAME], " = '%s'", target->GetName());

	StatusCode status = srbGetDataDirInfoWithZone(m_conn, 0, zone, m_qval, m_selval, &m_result, MAX_ROWS);


	if(!status.isOk())
		return status;

	if(0 == m_result.row_count)	//should mark resource as open
		return SRB_OK;

	filterDeleted(&m_result);

	char* ptr = (char*)getFromResultStruct(&m_result, dcs_tname[CONTAINER_NAME], dcs_aname[CONTAINER_NAME]);

	if(ptr == NULL)
		return SRB_ERROR;

	ContainerNodeImpl* child;
	child = new ContainerNodeImpl(target, ptr);
	target->AddNode(child);

	for(i = 1; i < m_result.row_count; i++)
	{
		ptr += MAX_DATA_SIZE;
		child = new ContainerNodeImpl(target, ptr);
		target->AddNode(child);
	}

	return SRB_OK;
}
#if 0
StatusCode CollectionOperatorImpl::GetChildCollections(CollectionNodeImpl* target)
{
	ClearMCATScratch();

    m_selval[DATA_GRP_NAME] = 1;
    sprintf(m_qval[PARENT_COLLECTION_NAME]," = '%s'", target->GetPath());

    //StatusCode status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);
	StatusCode status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)m_session->GetCurrentZone(target)->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
		if(-3005 == status)
			return SRB_OK;
		else
			return status;

	filterDeleted(&m_result);

	char *original, *szptr;

	int len;

	while(true)
	{
		original = getFromResultStruct(&m_result,dcs_tname[DATA_GRP_NAME], dcs_aname[DATA_GRP_NAME]);

		for(int i = 0; i < m_result.row_count; i++)
		{
			szptr = original;

			len = strlen(szptr);

			for(int j = len - 1; j >= 0; j--)
				if('/' == szptr[j])
				{
					szptr = &szptr[j+1];
					break;
				}

			target->AddChild(new CollectionNodeImpl(target, szptr));

			original += MAX_DATA_SIZE;
		}

		if(m_result.continuation_index < 0)
			break;

		status = srbGetMoreRows(m_conn, 0, m_result.continuation_index, &m_result, MAX_ROWS);

		if(-3005 == status)
			return SRB_OK;

		if(0 != status)
			return SRB_ERROR;
	}

	return SRB_OK;
}
#endif
StatusCode ResourceOperatorImpl::GetChildren(ResourceNodeImpl* target, unsigned int mask)
{
	if(NULL == target)
		return SRB_ERROR_INVALID_PARAMETER;

	target->Clear();

	StatusCode status;
	
	unsigned int success = SOB_ALL ^ SOB_CONTAINER;

	if(SOB_CONTAINER & mask)
	{
		status = GetContainer(target);
		if(status.isOk())
		{
			success |= SOB_CONTAINER;
		}
		else
		{
			target->SetOpen(success);
			return status;
		}
	}

	target->SetOpen(success);
	return status;
}


} //end namespace


