
#include "mdasC_db2_externs.h"

char ResourceName[MAX_TOKEN];
char datatype[MAX_TOKEN];
char newpathname[MAX_TOKEN];
