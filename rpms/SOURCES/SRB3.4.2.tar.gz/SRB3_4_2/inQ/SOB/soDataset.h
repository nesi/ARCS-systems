#ifndef __SRB_OBJECT_DATASET_NODE_H__
#define __SRB_OBJECT_DATASET_NODE_H__
#include "soGlobals.h"
#include "soNode.h"
#include "mdasC_db2_externs.h"
#include <vector>

namespace SRB
{
class DatasetNodeImpl : public IDatasetNode
{
public:
	DatasetNodeImpl(INode* parent, mdasC_sql_result_struct* result, int index);
	DatasetNodeImpl(INode* parent, char* name, char* size, char* owner, char* time,
		char* repl, char* logi_resc, char* phys_resc, char* container, char* type, char* comment);
	~DatasetNodeImpl();

	const char* GetName() {return m_name;};
	const char* GetPath();
	INode* GetParent() {return m_parent;};
	INode* GetChild(int pos);
	StatusCode GetChild(const char* name, INode** result);
	unsigned int GetType() { return SOB_DATASET;};

	int CountChildren();
	int CountHeightFromRoot();

	INode* GetChild(const char* name);
	IDatasetNode* GetReplicant(int replication_index);

	bool isOpen(unsigned int mask = SOB_ALL) { return ((m_isOpen & mask) == mask); };
	unsigned int GetOpen() { return m_isOpen;};

	const char* GetSize() { return m_size; };
	const char* GetOwner() { return m_owner; };
	const char* GetTimeStamp() { return m_timeStamp; };
	const char* GetReplicationIndex() { return m_replicationIndex; };
	const char* GetLogicalResource() { return m_logi_resc; };
	const char* GetPhysicalResource() { return m_phys_resc; };
	const char* GetComment() { return m_comment; };
	const char* GetContainer() { return m_container; };
	const char* GetDataType() { return m_dataType; };

	INode* GetUncle(int pos);
	int CountUncles();

	//impl
	void AddUncle(INode* uncle);

	//impl
	StatusCode DeleteChild(INode* child);
	void Clear();
	void SetOpen(unsigned int mask) { m_isOpen = mask;};
	void AddChild(INode* child);
	StatusCode SetName(const char* name);
	void SetComment(const char* comment);
	void Wash(char* size, char* owner, char* time, char* repl, char* logi_resc, char* phys_resc, char* container, char* type, char* comment);

private:
	DatasetNodeImpl();
	DatasetNodeImpl(const DatasetNodeImpl& source);
	DatasetNodeImpl& operator =(const DatasetNodeImpl& source);

	char* m_name;
	char* m_path;
	INode* m_parent;
	std::vector<INode*>* m_children;
	std::vector<INode*>* m_uncle;
	unsigned int m_isOpen;
	char* m_size;
	char* m_owner;
	char* m_timeStamp;
	char* m_replicationIndex;
	char* m_phys_resc;
	char* m_logi_resc;
	char* m_container;
	char* m_dataType;
	char* m_comment;
};


}//end namespace
#endif