#include "soContainerOperator.h"
#include "soContainer.h"
#include "soResource.h"
#include "clStubExtern.h"
#include "scommands.h"


namespace SRB
{
ContainerOperatorImpl::ContainerOperatorImpl(ISession* session)
{
		m_result.result_count = 0;
	m_result.row_count = 0;
	m_session = session;
}

ContainerOperatorImpl::~ContainerOperatorImpl()
{
}

StatusCode ContainerOperatorImpl::Rename(IContainerNode* target, const char* name)
{
	return SRB_ERROR;
}

StatusCode ContainerOperatorImpl::Delete(IContainerNode* target)
{
	StatusCode status = srbRmContainer((srbConn*)m_session->GetConn(), 0, (char*)target->GetContainerPath(), D_SU_DELETE_TRASH_ONE);

	ResourceNodeImpl* parent;

	if(status.isOk())
	{
		parent = (ResourceNodeImpl*)target->GetParent();
		parent->DeleteChild(target);
	}

	return status;
}

StatusCode ContainerOperatorImpl::Sync(IContainerNode* target, unsigned int flag)
{
	return srbSyncContainer((srbConn*)m_session->GetConn(), 0, (char*)target->GetContainerPath(), flag);
}

void ContainerOperatorImpl::ClearMCATScratch()
{
    clearSqlResult (&m_result);

    for(int i = 0; i < MAX_DCS_NUM; i++)
	{
        sprintf(m_qval[i],"");
        m_selval[i] = 0;
    }
}


}//end namespace
