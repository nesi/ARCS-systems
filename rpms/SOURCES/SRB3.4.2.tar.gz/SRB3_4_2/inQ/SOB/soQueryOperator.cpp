#include "soQueryOperator.h"
#include "soCollectionOperator.h"
#include "clStubExtern.h"
#include "scommands.h"
#include "clAuthExtern.h"


namespace SRB
{

QueryOperatorImpl::QueryOperatorImpl(ISession* session, ICollectionNode* root)
{
	m_session = session;
	m_conn = (srbConn*)session->GetConn();
	m_root = root;
	m_result.result_count = 0;
	m_result.row_count = 0;
	m_result.result_count = 0;	//hack to bypass clearsqlstruct on 1st pass

	m_query = NULL;
	m_queryResult = NULL;
}

QueryOperatorImpl::~QueryOperatorImpl()
{
	if(m_result.result_count != 0)
		clearSqlResult(&m_result);

	delete m_query;
	delete m_queryResult;
}


StatusCode QueryOperatorImpl::Query(ICollectionNode* target, IQueryNode** result)
{
	if(NULL == result)
		return -1;

	*result = NULL;

	if(NULL == m_query)
		return -1;

	delete m_queryResult;

	//create new result node with metadata node (m_query) as child 0.
	m_queryResult = new QueryNodeImpl(NULL, m_query);
	m_collection = target;

	StatusCode status = GetChildren();	//populate

	if(status.isOk())
	{
		*result = m_queryResult;
	}

	return status;
}

//Gets all children matching query. First collections, and then datasets
StatusCode QueryOperatorImpl::GetChildren()
{
	LoadCollectionQuery();

	StatusCode status = Fetch();

	//if(status.isOk())
	//{
	//	LoadDatasetQuery();
	//	status = FetchDatasets();
	//}

	return status;
}

void QueryOperatorImpl::ClearMCATScratch()
{
    clearSqlResult(&m_result);

    for(int i = 0; i < MAX_DCS_NUM; i++)
	{
        sprintf(m_qval[i],"");
        m_selval[i] = 0;
    }
}

void QueryOperatorImpl::LoadCollectionQuery()
{
	ClearMCATScratch();
	m_selval[DATA_GRP_NAME] = 1;

	LoadCollectionQuery2(m_query);
}

void QueryOperatorImpl::LoadCollectionQuery2(IMetadataNode* ptr, int count)
{
	if(NULL == ptr)
		return;

	INode* parent = ptr->GetParent(); //get query that is parent of metadata;

	if(NULL == parent)	//should always be non-NULL
		return;

	parent = parent->GetParent();

	if(parent != NULL)
	{
		//then this is a nested query
		//get metadata child that must be child to query node
		parent = parent->GetChild(0);
		LoadCollectionQuery2((IMetadataNode*)parent, count);	//just assume it's mdn without checking
	}

	MetadataNodeImpl* child;

	switch(ptr->GetOperation())
	{
	case SOB_MD_AND:
		child = (MetadataNodeImpl*)ptr->GetChild(0);	//left hand child
		LoadCollectionQuery2(child, count);
		child = (MetadataNodeImpl*)ptr->GetChild(1);	//right hand child
		LoadCollectionQuery2(child, count);
		break;
	case SOB_MD_EQUAL:
		switch(++count)
		{
		case 1:
			sprintf(m_qval[UDSMD_COLL0]," = '%s'", ptr->GetAttribute());
			sprintf(m_qval[UDSMD_COLL1]," = '%s'", ptr->GetValue());
			break;
		case 2:
			sprintf(m_qval[UDSMD_COLL0_1]," = '%s'", ptr->GetAttribute());
			sprintf(m_qval[UDSMD_COLL1_1]," = '%s'", ptr->GetValue());
			break;
		case 3:
			sprintf(m_qval[UDSMD_COLL0_2]," = '%s'", ptr->GetAttribute());
			sprintf(m_qval[UDSMD_COLL1_2]," = '%s'", ptr->GetValue());
			break;
		case 4:
			sprintf(m_qval[UDSMD_COLL0_3]," = '%s'", ptr->GetAttribute());
			sprintf(m_qval[UDSMD_COLL1_3]," = '%s'", ptr->GetValue());
			break;
		case 5:
			sprintf(m_qval[UDSMD_COLL0_4]," = '%s'", ptr->GetAttribute());
			sprintf(m_qval[UDSMD_COLL1_4]," = '%s'", ptr->GetValue());
			//could also put a value here to reset a static int
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
}

void QueryOperatorImpl::LoadDatasetQuery()
{
	ClearMCATScratch();

	m_selval[DATA_GRP_NAME] = 1;
	m_selval[DATA_NAME] = 1;

	LoadDatasetQuery2(m_query);
}


void QueryOperatorImpl::LoadDatasetQuery2(IMetadataNode* ptr, int count)
{
	if(NULL == ptr)
		return;

	MetadataNodeImpl* child;

	switch(ptr->GetOperation())
	{
	case SOB_MD_AND:
		child = (MetadataNodeImpl*)ptr->GetChild(0);	//left hand child
		LoadDatasetQuery2(child, count);
		child = (MetadataNodeImpl*)ptr->GetChild(1);	//right hand child
		LoadDatasetQuery2(child, count);
		break;
	case SOB_MD_EQUAL:
		switch(++count)
		{
		case 1: 
			sprintf(m_qval[UDSMD0]," = '%s'", ptr->GetAttribute());
			sprintf(m_qval[UDSMD1]," = '%s'", ptr->GetValue());
			break;
		case 2:
			sprintf(m_qval[UDSMD0_1]," = '%s'", ptr->GetAttribute());
			sprintf(m_qval[UDSMD1_1]," = '%s'", ptr->GetValue());
			break;
		case 3:
			sprintf(m_qval[UDSMD0_2]," = '%s'", ptr->GetAttribute());
			sprintf(m_qval[UDSMD1_2]," = '%s'", ptr->GetValue());
			break;
		case 4:
			sprintf(m_qval[UDSMD0_3]," = '%s'", ptr->GetAttribute());
			sprintf(m_qval[UDSMD1_3]," = '%s'", ptr->GetValue());
			break;
		case 5:
			sprintf(m_qval[UDSMD0_4]," = '%s'", ptr->GetAttribute());
			sprintf(m_qval[UDSMD1_4]," = '%s'", ptr->GetValue());
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
}

StatusCode QueryOperatorImpl::Fetch()
{
	//the equal thing will only ever return either 1 or 0 so it should have special instance
	//also because when you subtract the collection name from itself it's null
	sprintf(m_qval[DATA_GRP_NAME]," = '%s'", m_collection->GetPath());

	StatusCode status = GetFirstChildResults();

	if(status.isOk())
	{
		clearSqlResult(&m_result);
		sprintf(m_qval[DATA_GRP_NAME]," like '%s/%%'", m_collection->GetPath());
		status = GetChildResults();
	}

	return status;
}

StatusCode QueryOperatorImpl::FetchDatasets()
{
	sprintf(m_qval[DATA_GRP_NAME]," = '%s'", m_collection->GetPath());

	StatusCode status = GetChildDatasets();

	if(status.isOk())
	{
		clearSqlResult(&m_result);
		sprintf(m_qval[DATA_GRP_NAME]," like '%s/%%'", m_collection->GetPath());
		status = GetChildDatasets();
	}

	return status;
}

StatusCode QueryOperatorImpl::GetChildDatasets()
{
	StatusCode status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if(0 != status)
	{
		if(-3005 == status)
			status = 0;

		return status;
	}

	filterDeleted(&m_result);

	INode* baby;

	CollectionOperatorImpl* cOp;

	char* o_c = getFromResultStruct(&m_result,dcs_tname[DATA_GRP_NAME], dcs_aname[DATA_GRP_NAME]);
	char* o_d = getFromResultStruct(&m_result,dcs_tname[DATA_NAME], dcs_aname[DATA_NAME]);

	char *path, *name;

	for(int i = 0; i < m_result.row_count; i++)
	{
		path = o_c + (i*MAX_DATA_SIZE);
		path = path + strlen(m_collection->GetPath());

		name = o_d + (i*MAX_DATA_SIZE);

		//highly inefficient but for right now it works...
blah:

		if(0 != strcmp("", path))
		{
			status = ((CollectionNodeImpl*)m_collection)->GetChild(path, &baby);
		}else
		{
			status = SRB_OK;
			baby = m_collection;
		}
				
		switch(status.GetCode())
		{
		case SRB_OK:
			baby = baby->GetChild(name);
			if(baby == NULL)
				return SRB_GENERAL_ERROR;
			m_queryResult->AddChild(baby);
			break;
		case SRB_ERROR_NOT_FILLED:
			cOp = new CollectionOperatorImpl(m_session);	//does this have to be a new op each time?
			cOp->GetChildren((CollectionNodeImpl*)baby);
			goto blah;
				break;
		default:
			return SRB_GENERAL_ERROR;
		}
	}

	//while(m_result.continuation_index >= 0)
	//{
		//add code for this later	
	//}

	return SRB_OK;
}

StatusCode QueryOperatorImpl::GetFirstChildResults()
{
	StatusCode status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if(0 != status)
	{
		if(-3005 == status)
			status = 0;

		return status;
	}

	switch(m_result.row_count)
	{
	case 0:
		break;
	case 1:
		m_queryResult->AddChild(m_collection);
		break;
	default:
		return -1;
	}
	
	return SRB_OK;
	
}

StatusCode QueryOperatorImpl::GetChildResults()
{
	StatusCode status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if(0 != status)
	{
		if(-3005 == status)
			status = 0;

		return status;
	}

	filterDeleted(&m_result);

	INode* baby;

	CollectionOperatorImpl* cOp;

	char* original = getFromResultStruct(&m_result,dcs_tname[DATA_GRP_NAME], dcs_aname[DATA_GRP_NAME]);
	char* pathstring;

	for(int i = 0; i < m_result.row_count; i++)
	{
		pathstring = original + (i*MAX_DATA_SIZE);
		pathstring = pathstring + strlen(m_collection->GetPath());
		
		//highly inefficient but for right now it works...
blah:
		if(pathstring)
		{
			status = ((CollectionNodeImpl*)m_collection)->GetChild(pathstring, &baby);
				
			switch(status.GetCode())
			{
			case SRB_OK:
				m_queryResult->AddChild(baby);
				break;
			case SRB_ERROR_NOT_FILLED:
				cOp = (SRB::CollectionOperatorImpl*)m_session->GetOperator(SOB_COLLECTION);
					//new CollectionOperatorImpl(*m_conn, NULL);
				cOp->GetChildren((CollectionNodeImpl*)baby);
				goto blah;
					break;
			default:
				return SRB_GENERAL_ERROR;
			}
		}else
		{
			m_queryResult->AddChild(m_collection);
		}
	}

	//while(m_result.continuation_index >= 0)
	//{
		//add code for this later	
	//}

	return SRB_OK;
}






const char* QueryOperatorImpl::GetQueryString()
{
	if(NULL == m_query)
		return NULL;

	return m_query->GetName();
}

//creates a new metadata node. if it is the first node to be added, it automatically becomes
//the root metadata node
IMetadataNode* QueryOperatorImpl::Add(const char* attribute)
{
	MetadataNodeImpl* ptr = new MetadataNodeImpl(NULL, attribute);
	if(NULL == m_query)
		m_query = ptr;

	return ptr;	//notice how this can leak memory if the user doesn't attach it to something
	//maybe we should put it in a list until it's anded or or'ed so it doesn't get lost
}

void QueryOperatorImpl::SetValue(IMetadataNode* parameter, const char* value)
{
	((MetadataNodeImpl*)parameter)->SetValue(value);
}

void QueryOperatorImpl::SetOperation(IMetadataNode* parameter, int operation)
{
	((MetadataNodeImpl*)parameter)->SetOperation(operation);
}

void QueryOperatorImpl::Delete(IMetadataNode* parameter)
{
	/*
		if node is equal or like, then it is a statement (leaf) and should be deleted.
		if it is the child of a join op like OR or AND then the other child should replace the and

	*/
}

IMetadataNode* QueryOperatorImpl::And(IMetadataNode* left, IMetadataNode* right)
{
	IMetadataNode* return_me = ((MetadataNodeImpl*)left)->And(right);

	if((left == m_query)||(right == m_query))
	{
		m_query = (MetadataNodeImpl*)return_me;
	}


	return return_me;
}

IMetadataNode* QueryOperatorImpl::Or(IMetadataNode* left, IMetadataNode* right)
{
	return NULL;
	//MetadataNodeImpl* parent = (MetadataNodeImpl*)left->GetParent();

	//return parent->Or(left, right);
}

} //end namespace



