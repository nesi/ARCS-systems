#ifndef #ifndef __SRB_OBJECT_BASIC_OPERATOR_H__
#define #ifndef __SRB_OBJECT_BASIC_OPERATOR_H__
#include "soGlobals.h"
#include "soNode.h"
#include "clConnectExtern.h"
#include "soCollection.h"
#include "soBasicOperator.h"

namespace SRB
{
class BasicOperatorImpl
{
public:
	CollectionOperatorImpl(const srbConn& session, const char* resource);
	~CollectionOperatorImpl();
	INode* GetBinding() { return NULL;};
	StatusCode Copy(ICollectionNode* target, IDatasetNode* data, IDatasetNode** result = NULL);
	StatusCode Copy(ICollectionNode* target, ICollectionNode* data, ICollectionNode** result = NULL);
	StatusCode Export(ICollectionNode* source, const char* local_path);
	StatusCode Import(ICollectionNode* target, const char* local_path, ICollectionNode** result = NULL);
	StatusCode Delete(ICollectionNode* target);
	StatusCode Replicate(ICollectionNode* target);
	StatusCode Rename(ICollectionNode* target, const char* name);
	StatusCode SetComment(ICollectionNode* target, const char* comment);
	StatusCode Create(ICollectionNode* target, const char* name, ICollectionNode** result = NULL);	//optional param sets result to the Node of the new collection
	StatusCode SetAccess(ICollectionNode* target, IUserNode* user, int level);

	StatusCode AddMeta(ICollectionNode* target, const char* attribute, IMetadataNode** result = NULL);
	StatusCode ModifyMeta(IMetadataNode* target, const char* value);
	StatusCode DeleteMeta(IMetadataNode* target);
	//impl specific functionality
	StatusCode GetChildren(CollectionNodeImpl* target);
	StatusCode OpenTree(ICollectionNode* parent, int levels );

private:

	StatusCode GetChildCollections(CollectionNodeImpl* target);
	void ClearMCATScratch();


	ISession* m_session;
	char* m_resource;
	mdasC_sql_result_struct m_result;
	char m_qval[MAX_DCS_NUM][MAX_TOKEN];
	int m_selval[MAX_DCS_NUM];
	srbConn* m_conn;
};
}//end namespace
#endif

