#include "soDomainOperator.h"
#include "soDomain.h"
#include "soUser.h"
#include "clStubExtern.h"
#include "scommands.h"

extern "C"
{
//extern char dcs_tname[MAX_DCS_STRUCTS][MAX_TOKEN];
//extern char dcs_aname[MAX_DCS_STRUCTS][MAX_TOKEN];
}

namespace SRB
{
DomainOperatorImpl::DomainOperatorImpl(ISession* session)
{
	m_result.result_count = 0;
	m_result.row_count = 0;
	m_session = session;
	m_conn = (srbConn*)m_session->GetConn();
	m_domain = NULL;
}

DomainOperatorImpl::~DomainOperatorImpl()
{
	if(m_domain)
		delete m_domain;
}

void DomainOperatorImpl::ClearMCATScratch()
{
    clearSqlResult (&m_result);

    for(int i = 0; i < MAX_DCS_NUM; i++)
	{
        sprintf(m_qval[i],"");
        m_selval[i] = 0;
    }
}

StatusCode DomainOperatorImpl::GetChildren(DomainNodeImpl* target, unsigned int mask)
{
	if(NULL == target)
		return SRB_ERROR_INVALID_PARAMETER;

	target->Clear();

	StatusCode status;
	
	unsigned int success = SOB_ALL ^ SOB_USER;

	if(SOB_USER & mask)
	{
		status = GetDomainUsers(target);
		if(status.isOk())
		{
			success |= SOB_USER;
		}
		else
		{
			target->SetOpen(success);
			return status;
		}
	}

	target->SetOpen(success);
	return status;
}



StatusCode DomainOperatorImpl::GetDomainUsers(IDomainNode* domain)
{
	ClearMCATScratch();

	m_selval[DOMAIN_DESC] = 1;
	m_selval[USER_NAME] = 1;
	m_selval[USER_TYP_NAME] = 1;
	//sprintf(m_qval[USER_TYP_NAME], " not 'deleted' ");
	sprintf(m_qval[DOMAIN_DESC], " = '%s'", domain->GetName());

	StatusCode status = srbGetDataDirInfo(m_conn,0, m_qval, m_selval, &m_result,MAX_ROWS);
						
	if(!status.isOk())
		return status;

	if(0 == m_result.row_count)
		return status;


	filterDeleted (&m_result);

	UserNodeImpl* child;

	char* szUser = getFromResultStruct(&m_result, dcs_tname[USER_NAME], dcs_aname[USER_NAME]);
	char* szUserType = getFromResultStruct(&m_result, dcs_tname[USER_TYP_NAME], dcs_aname[USER_TYP_NAME]);

	if(szUser && szUserType)
	{
		child = new UserNodeImpl(domain, szUser, szUserType);
		((DomainNodeImpl*)domain)->AddChild(child);
	}

	for (i=1; i < m_result.row_count; i++) 
	{
		szUser += MAX_DATA_SIZE;
		szUserType += MAX_DATA_SIZE;
		if(szUser && szUserType)
		{
			child = new UserNodeImpl(domain, szUser, szUserType);
			((DomainNodeImpl*)domain)->AddChild(child);
		}
	}

	return SRB_OK;
}
}//end namespace
