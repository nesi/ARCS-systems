#if ENABLE_SORTING
#ifndef __SRB_OBJECT_SORT_NODE_H__
#define __SRB_OBJECT_SORT_NODE_H__
#include "soGlobals.h"
#include "soNode.h"
#include "mdasC_db2_externs.h"
#include <vector>

namespace SRB
{
class SortNodeImpl: public ISortNode
{
public:
	SortNodeImpl(ISortNode* parent, const char* name);
	SortNodeImpl();
	 ~SortNodeImpl();

	const char* GetName();
	const char* GetPath();
	INode* GetParent() {return m_parent;};
	INode* GetChild(int pos);
	int GetType() { return SOB_SORT;};

	int CountChildren();
	int CountHeightFromRoot();

	INode* GetChild(const char* name);

	bool isOpen() { return m_isOpen; };
	unsigned int GetOpen() { return m_isOpen;};

	const char* GetAttribute() { return m_attribute;};
	const char* GetValue() { return m_value;};

	//impl
	void AddNode(INode* target);
	void AddNodeFront(INode* target);
	void RemoveNode(INode* target);
	void MoveNode(INode* ThisNodeComes, INode* BeforeThisOne);

private:
	char* m_name;
	char* m_path;
	std::vector<INode*> *m_children;
	INode* m_parent;
	bool m_isOpen;
	char* m_attribute;
	char* m_value;
};

}//end namespace
#endif
#endif