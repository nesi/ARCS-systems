#ifndef __SRB_OBJECT_GLOBALS_H__
#define __SRB_OBJECT_GLOBALS_H__

#define c_plus_plus	1

#define FED_MCAT 1

#include "scommands.h"

#define SOB_NONE		0
#define SOB_DATASET		1
#define SOB_COLLECTION	2
#define SOB_METADATA	4
#define SOB_ACCESS		8
#define SOB_RESOURCE	16
#define SOB_CONTAINER	32
#define SOB_QUERY		64
#define SOB_DOMAIN		128	
#define SOB_USER		256
#define SOB_QUERY2		512
#define SOB_ZONE		1024
#define SOB_MCAT		2048
#define SOB_SET			4096
#define SOB_LOCAL		8192
#define SOB_ALL			16383

#define SOB_OP_NONE				0
#define SOB_OP_IS_TRANSFER_OP	1
#define SOB_OP_COLLECTION		3	/*2 + 1*/
#define SOB_OP_CONTAINER		4
#define SOB_OP_DATASET			9	/*8 + 1*/
#define SOB_OP_DOMAIN			16
#define SOB_OP_QUERY			32
#define SOB_OP_RESOURCE			64
#define SOB_OP_ZONE				128
#define SOB_OP_MCAT				256
#define SOB_OP_ALL				2047

#define SOB_NO_OVERWRITE	0
#define SOB_OVERWRITE		1
#define SOB_OVERWRITE_ALL	3	//includes OVERWRITE

static char* op_map[] = {"AND", "OR", "=", "<>", ">","<", ">=", "<=", "between", "not between", "like", "not like", "sounds like", "sounds not like"};

//#define SOB_DATASET 1
//#define SOB_COLLECTION 2
//#define SOB_METADATA 3
//#define SOB_QUERY 4
//#define SOB_QUERY2 5
//#define SOB_SORT 6
//#define SOB_RESOURCE 7
//#define SOB_CONTAINER 8
//#define SOB_USER 9
//#define SOB_DOMAIN 10
//#define SOB_GROUP 11
//#define SOB_ACCESS 12







#define MAX_ROWS 400

//this block of error codes should be defined in mdas_errno.h
#define SRB_OK 0
#define SRB_ERROR_NOT_FILLED -7000
#define SRB_GENERAL_ERROR -7001
#define SRB_ERROR -7001
#define SRB_ERROR_INVALID_PARAMETER -7002
#define SRB_ERROR_INVALID_BINDING -7005
#define SRB_ERROR_NOT_CHILD -7003
#define SRB_ERROR_BUSY -7004
//-7005 used
#define SRB_ERROR_TYPE_NOT_SUPPORTED -7006
#define SRB_ERROR_LOGIN_FAILED -7007
#define SRB_ERROR_NOT_SUPPORTED -7008
#define SRB_ERROR_CHILD_NOT_FOUND -7009
#define SRB_ERROR_DOES_NOT_EXIST -7010
#define SRB_ERROR_NO_HOME_COLLECTION -7011
#define SRB_ERROR_SOURCE_EQUALS_TARGET -7012
#define SRB_ERROR_UNCLE_NOT_FOUND -7013
#define SRB_ERROR_QUERY_DELETE_FORBIDDEN -7014
#define SRB_ERROR_NOT_IMPLEMENTED -7015

#define SOB_MD_AND 0
#define SOB_MD_OR 1
#define SOB_MD_EQUAL 2
#define SOB_MD_NOT_EQUAL 3
#define SOB_MD_GREATER_THAN 4
#define SOB_MD_LESS_THAN 5
#define SOB_MD_GREATER_OR_EQUAL 6
#define SOB_MD_LESS_OR_EQUAL 7
#define SOB_MD_BETWEEN 8
#define SOB_MD_NOT_BETWEEN 9
#define SOB_MD_LIKE 10
#define SOB_MD_NOT_LIKE 11
#define SOB_MD_SOUNDS_LIKE 12
#define SOB_MD_SOUNDS_NOT_LIKE 13
#define SOB_MD_SORT 14

#define SMART_FREE(variable) \
	if(variable){ \
		free(variable); \
variable = NULL;} \

#define SMART_DELETE(variable) \
	if(variable){ \
		delete variable; \
		variable = NULL;} \

#define SMART_DELETE_ARRAY(variable) \
	if(variable){ \
		delete [] variable; \
		variable = NULL;} \

#define LOG(MESSAGE) \
	m_file.open("c:\\soblog.txt", ios::out); \
	m_file << MESSAGE; \
	m_file.close(); \



#endif __SRB_OBJECT_GLOBALS_H__