#include "soDatasetOperator.h"
#include "soDataset.h"
#include "soMetadata.h"
#include "soUser.h"
#include "soAccess.h"
#include "soCollection.h"

namespace SRB
{

DatasetOperatorImpl::DatasetOperatorImpl(ISession* session)
{
	m_result.result_count = 0;
	m_result.row_count = 0;
	m_session = session;
	m_conn = (srbConn*)session->GetConn();
	m_bytes_received = 0;
	m_bytes_expected = 0;
	m_bIsDownloading = false;
}

DatasetOperatorImpl::~DatasetOperatorImpl()
{
	m_session = NULL;	//just do something
}

StatusCode DatasetOperatorImpl::ModifyAccess(IAccessNode* target, const char* permission)
{
	if(NULL == target || NULL == permission)
		return SRB_ERROR_INVALID_PARAMETER;

	IStringNode* constraints = m_session->GetAccessConstraints();

	int count = constraints->CountStrings();

	for(int i = 0; i < count; i++)
	{
		if(0 == strcmp(constraints->GetString(i), permission))
			break;
	}

	if(count == i)
		return SRB_ERROR_INVALID_PARAMETER;

	char* sz;

	char* dataset = (char*)target->GetParent()->GetName();
	char* collection = (char*)target->GetParent()->GetParent()->GetPath();
	char* user = (char*)target->GetUser();
	char* domain = (char*)target->GetDomain();
	char* buf;
	StatusCode status;

	int retraction_type;
	int len = 0;

	if(0 == strcmp("null", permission))
	{
		retraction_type = D_DELETE_ACCS;
		sz = "";
	}
	else
	{
		retraction_type = D_INSERT_ACCS;
		sz = (char*)permission;
	}
	//(char*)((IDatasetNode*)target->GetParent())->GetOwner()
	len += strlen(user);
	len += strlen(domain);
	len += 2;
	buf = (char*)calloc(len, sizeof(char));
	sprintf(buf, "%s@%s", user, domain);
	status = srbModifyDataset(m_conn, 0, dataset, collection, "", "", buf, sz, retraction_type);
	free(buf);
	
	SRB::INode* parent;

	if(status.isOk())
	{
		if(D_DELETE_ACCS == retraction_type)
		{
			parent = target->GetParent();

			switch(parent->GetType())
			{
			case SOB_COLLECTION:
				status = ((CollectionNodeImpl*)parent)->DeleteChild(target);
				break;
			case SOB_DATASET:
				status = ((DatasetNodeImpl*)parent)->DeleteChild(target);
				break;
			default:
				((AccessNodeImpl*)target)->SetPermission(permission);
			}
		}else
		{
			((AccessNodeImpl*)target)->SetPermission(permission);
		}
	}

	return status;

}

StatusCode DatasetOperatorImpl::SetAccess(IDatasetNode* target, IUserNode* owner, const char* permission)
{
	if(NULL == target || NULL == owner || NULL == permission)
		return SRB_ERROR_INVALID_PARAMETER;

	//do operation
	int retraction_type;
	StatusCode status;
	char* sz;

	if(0 == strcmp("null", permission))
	{
		retraction_type = D_DELETE_ACCS;
		sz = "";
	}
	else
	{
		retraction_type = D_INSERT_ACCS;
		sz = (char*)permission;
	}

	status = srbModifyDataset(m_conn, 0, (char*)target->GetName(), (char*)target->GetParent()->GetPath(), "", "", (char*)owner->GetPath(), sz, retraction_type);

	INode* child;
	int count;
	
	if(status.isOk())
	{
		count = target->CountChildren();

		if(count)
		{
			for(i = 0; i < count; i++)
			{
				child = target->GetChild(i);
				if(SOB_ACCESS == child->GetType())
				{
					if(0 == strcmp(owner->GetName(), child->GetName()))
					{
						((AccessNodeImpl*)child)->SetPermission(permission);
						break;
					}
				}
			}

			if(i == count)
			{
				//a new user was added
				((DatasetNodeImpl*)target)->AddChild(new AccessNodeImpl(target, NULL, owner->GetParent()->GetName(), owner->GetName(), permission));
			}
		}else
		{
			if(D_INSERT_ACCS == retraction_type)
			{
				//insert new access - this handles case where user deletes all access permissions and is inserting a first child
				((DatasetNodeImpl*)target)->AddChild(new AccessNodeImpl(target, NULL, owner->GetParent()->GetName(), owner->GetName(), permission));
			}
		}
	}
	return status;
}

//handle the name parameter later
int DatasetOperatorImpl::GetProgress(char** name)
{
	if(0 == m_bytes_expected)
		return 0;

	if(!m_bIsDownloading)
		return -1;

	double retval = m_bytes_received;
	retval = (retval / m_bytes_expected) * 100;

	return retval;
}


StatusCode DatasetOperatorImpl::Download(INode* target, const char* local_path)
{
	//CHARLIECHARLIE

	if(NULL == local_path)
		return SRB_ERROR_INVALID_PARAMETER;

	if(SOB_DATASET != target->GetType())
		return SRB_ERROR_INVALID_PARAMETER;

	m_bIsDownloading = true;

	SRB::IDatasetNode* target_dataset = (SRB::IDatasetNode*)target;

    mdasC_sql_result_struct myresult;

	const char* collection = target_dataset->GetParent()->GetPath();
	const char* name = target_dataset->GetName();
	const char* type = target_dataset->GetDataType();
	int replNum = atoi(target_dataset->GetReplicationIndex());
	const char* size = target_dataset->GetSize();

    myresult.result_count = 4;
    myresult.row_count = 1;
    myresult.sqlresult[0].tab_name = dcs_tname[DATA_GRP_NAME];
    myresult.sqlresult[0].att_name = dcs_aname[DATA_GRP_NAME];
    myresult.sqlresult[0].values = (mdasC_handle)collection;
    myresult.sqlresult[1].tab_name = dcs_tname[DATA_NAME];
    myresult.sqlresult[1].att_name = dcs_aname[DATA_NAME];
    myresult.sqlresult[1].values = (mdasC_handle)name;
	myresult.sqlresult[2].tab_name = dcs_tname[DATA_TYP_NAME];
    myresult.sqlresult[2].att_name = dcs_aname[DATA_TYP_NAME];
    myresult.sqlresult[2].values = (mdasC_handle)type;
    myresult.sqlresult[3].tab_name = dcs_tname[SIZE];
    myresult.sqlresult[3].att_name = dcs_aname[SIZE];
    myresult.sqlresult[3].values = (mdasC_handle)size;

	m_bytes_expected = atoi(((IDatasetNode*)target)->GetSize());

	
	StatusCode status = dataToDirCopyBC(m_conn, 0, F_FLAG, &myresult, replNum, (char*)local_path, "", &m_bytes_received);

	m_bIsDownloading = false;

	m_bytes_received = 0;
	m_bytes_expected = 0;

    return status;

}

StatusCode DatasetOperatorImpl::Bind(INode* node) { m_binding = node; return SRB_OK;};

StatusCode DatasetOperatorImpl::Upload(INode* target, const char* local_path, unsigned int overwrite, INode** result)
{
		//CHARLIECHARLIE

	if(SOB_COLLECTION != target->GetType())
		return SRB_ERROR_INVALID_PARAMETER;

    srbPathName srbPathName;
    int flagval = 0;
	int target_type = -1;

    srbPathName.inpArgv = (char*)local_path;

    /* fill in size, etc */
	if(-1 == chkFileName(&srbPathName))
		return SRB_ERROR_DOES_NOT_EXIST;

	if(overwrite & SOB_OVERWRITE)
	{
		flagval = F_FLAG;
		target_type = DATANAME_T;
		if((overwrite & SOB_OVERWRITE_ALL) == SOB_OVERWRITE_ALL)
			flagval |= a_FLAG;
	}else
	{
		flagval = 0;
		target_type = -1;
	}

	char* resource;
	char* container;

	switch(m_binding->GetType())
	{
	case SOB_RESOURCE:
		resource = (char*)m_binding->GetName();
		container = NULL;
		break;
	case SOB_CONTAINER:
		resource = NULL;
		container = (char*)m_binding->GetName();
		flagval |= c_FLAG;
		break;
	default:
		return SRB_ERROR_INVALID_BINDING;
	}

	int len = strlen(local_path);

	const char* name = NULL;

	for(int i = len - 1; i != 0; i--)
	{
		if('\\' == local_path[i])
		{
			//found the beginning of our name
			name = &local_path[i+1];
			break;
		}
	}

	if(NULL == name)
		name = local_path;

	m_bytes_expected = srbPathName.size;

	m_bIsDownloading = true;


    StatusCode status = fileToDataCopyBC(m_conn, 0, flagval, target_type, &srbPathName, (char*)target->GetPath(), (char*)name, "", "", resource, container, 0, &m_bytes_received);

	m_bIsDownloading = false;

    /* clean up */
    free (srbPathName.outArgv);

	INode* blarg;

	

	if(status.isOk())
	{
		CollectionNodeImpl* collection = (CollectionNodeImpl*)target;

		if(overwrite)
		{
			//new datasets were not created, but the overwritten dataset(s)
			//contain some invalid data.
			//status = Wash(collection, name);

			//for 118p, only one dataset exists so then it's easier to wash
			status = Wash(collection, name);

		}else
		{
			//a new dataset must have been created
			status = Fill(collection, &blarg, name);
		}
	}

	m_bytes_received = 0;
	m_bytes_expected = 0;

    return status;

}

//faster wash reserved for 118p's single overwrite only
StatusCode DatasetOperatorImpl::Wash(CollectionNodeImpl* collection, const char* dataset_name)
{
	if(NULL == collection || NULL == dataset_name)
		return SRB_ERROR_INVALID_PARAMETER;

	//1st get query for all datasets matching that name
	ClearMCATScratch();

    m_selval[SIZE] = 1;
    m_selval[DATA_TYP_NAME] = 1;
	m_selval[DATA_OWNER] = 1;
	m_selval[REPL_TIMESTAMP] = 1;
	m_selval[DATA_REPL_ENUM] = 1;
	m_selval[PHY_RSRC_NAME] = 1;
	m_selval[CONTAINER_NAME] = 1;
	m_selval[DATA_COMMENTS] = 1;

	m_selval[DATA_GRP_NAME] = 1;
	m_selval[DATA_NAME] = 1;

    sprintf(m_qval[DATA_GRP_NAME]," = '%s'", collection->GetPath());
    sprintf(m_qval[DATA_NAME]," = '%s'", dataset_name);

	
    StatusCode status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)m_session->GetCurrentZone(collection)->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
	{
		if(-3005 == status)
			return SRB_OK;
		return status;
	}

	filterDeleted(&m_result);

	if(m_result.continuation_index >= 0)
		return SRB_ERROR;

	if(m_result.row_count != 1)
		return SRB_ERROR;

	INode* node;
	for(int i = 0; i < collection->CountChildren(); i++)
	{
		node = collection->GetChild(i);
			if(SOB_DATASET == node->GetType())
				if(0 == strcmp(dataset_name, node->GetName()))
					break;
	}

	if(i == collection->CountChildren())
		return SRB_ERROR;

	char *size, *owner, *resource, *time, *container, *type, *comment;
	char* szptr = getFromResultStruct(&m_result, dcs_tname[DATA_REPL_ENUM], dcs_aname[DATA_REPL_ENUM]);

	if(0 != strcmp(((IDatasetNode*)node)->GetReplicationIndex(), szptr))
		return SRB_ERROR;

	size = getFromResultStruct(&m_result, dcs_tname[SIZE], dcs_aname[SIZE]);
	owner = getFromResultStruct(&m_result, dcs_tname[DATA_OWNER], dcs_aname[DATA_OWNER]);
	time = getFromResultStruct(&m_result, dcs_tname[REPL_TIMESTAMP], dcs_aname[REPL_TIMESTAMP]);
	resource = getFromResultStruct(&m_result, dcs_tname[PHY_RSRC_NAME], dcs_aname[PHY_RSRC_NAME]);
	container = getFromResultStruct(&m_result, dcs_tname[CONTAINER_NAME], dcs_aname[CONTAINER_NAME]);
	comment = getFromResultStruct(&m_result, dcs_tname[DATA_COMMENTS], dcs_aname[DATA_COMMENTS]);
	type = getFromResultStruct(&m_result, dcs_tname[DATA_TYP_NAME], dcs_aname[DATA_TYP_NAME]);
	((DatasetNodeImpl*)node)->Wash(size, owner, time, szptr, "", resource, container, type, comment);

	return SRB_OK;
}


#if 0
{
	if(NULL == collection || NULL == dataset_name)
		return SRB_ERROR_INVALID_PARAMETER;

	//1st get query for all datasets matching that name
	ClearMCATScratch();

    m_selval[SIZE] = 1;
    m_selval[DATA_TYP_NAME] = 1;
	m_selval[DATA_OWNER] = 1;
	m_selval[REPL_TIMESTAMP] = 1;
	m_selval[DATA_REPL_ENUM] = 1;
	m_selval[PHY_RSRC_NAME] = 1;
	m_selval[CONTAINER_NAME] = 1;
	m_selval[DATA_COMMENTS] = 1;

	m_selval[DATA_GRP_NAME] = 1;
	m_selval[DATA_NAME] = 1;

    sprintf(m_qval[DATA_GRP_NAME]," = '%s'", collection->GetPath());
    sprintf(m_qval[DATA_NAME]," = '%s'", dataset_name);

     StatusCode status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)m_session->GetCurrentZone(target)->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
	{
		if(-3005 == status)
			return SRB_OK;
		return status;
	}

	filterDeleted(&m_result);

	if(m_result.continuation_index >= 0)
		return SRB_ERROR;

	//2nd make a stack of all children in the collection with that name
	std::vector<INode*> v;
	v.reserve(m_result.row_count);

	INode* node;
	for(int i = 0; i < collection->CountChildren(); i++)
	{
		node = collection->GetChild(i);
			if(SOB_DATASET == node->GetType())
				if(0 == strcmp(dataset_name, node->GetName()))
					v.push_back(node);
	}

	if(m_result.row_count != v.size())
		return SRB_ERROR;

	//3rd for each result
	//	a) match the result to a dataset in the stack by replication index
	//	b) DatasetNodeImpl::wash the dataset with the result data

	std::vector<INode*>::iterator iv;

	char* kkkk;
	char* jjjj;
	char *size, *owner, *resource, *time, *container, *type, *comment;
	char* szptr = getFromResultStruct(&m_result, dcs_tname[DATA_REPL_ENUM], dcs_aname[DATA_REPL_ENUM]);
	szptr -= MAX_DATA_SIZE;

	for(i = 0; i < m_result.row_count; i++)
	{
		szptr += MAX_DATA_SIZE;

		iv = v.begin();
		
		do
		{
			if(0 == strcmp(((IDatasetNode*)*iv)->GetReplicationIndex(), szptr))
			{
				jjjj = getFromResultStruct(&m_result, dcs_tname[DATA_NAME], dcs_aname[DATA_NAME]);
				kkkk = getFromResultStruct(&m_result, dcs_tname[DATA_GRP_NAME], dcs_aname[DATA_GRP_NAME]);
				size = getFromResultStruct(&m_result, dcs_tname[SIZE], dcs_aname[SIZE]);
				owner = getFromResultStruct(&m_result, dcs_tname[DATA_OWNER], dcs_aname[DATA_OWNER]);
				time = getFromResultStruct(&m_result, dcs_tname[REPL_TIMESTAMP], dcs_aname[REPL_TIMESTAMP]);
				resource = getFromResultStruct(&m_result, dcs_tname[PHY_RSRC_NAME], dcs_aname[PHY_RSRC_NAME]);
				container = getFromResultStruct(&m_result, dcs_tname[CONTAINER_NAME], dcs_aname[CONTAINER_NAME]);
				comment = getFromResultStruct(&m_result, dcs_tname[DATA_COMMENTS], dcs_aname[DATA_COMMENTS]);
				type = getFromResultStruct(&m_result, dcs_tname[DATA_TYP_NAME], dcs_aname[DATA_TYP_NAME]);
				size += i * MAX_DATA_SIZE;
				owner += i * MAX_DATA_SIZE;
				resource += i * MAX_DATA_SIZE;
				time += i * MAX_DATA_SIZE;
				container += i * MAX_DATA_SIZE;
				comment += i * MAX_DATA_SIZE;
				type += i * MAX_DATA_SIZE;

				((DatasetNodeImpl*)*iv)->Wash(size, owner, time, szptr, "", resource, container, type, comment);
				v.erase(iv);
				break;	//you need to break to optimize and because iv will become invalid
			}
		} while(iv != v.end());
	}

	return SRB_OK;
}
#endif

StatusCode DatasetOperatorImpl::Fill(CollectionNodeImpl* parent, INode** child, const char* name)
{
	if(NULL == parent || NULL == child)
		return SRB_ERROR_INVALID_PARAMETER;

	*child = NULL;
	
	ClearMCATScratch();

    m_selval[DATA_NAME] = 1;
    m_selval[DATA_GRP_NAME] = 1;
    m_selval[SIZE] = 1;
    m_selval[DATA_TYP_NAME] = 1;
	m_selval[DATA_OWNER] = 1;
	m_selval[REPL_TIMESTAMP] = 1;
	m_selval[DATA_REPL_ENUM] = 1;
	m_selval[PHY_RSRC_NAME] = 1;
	//m_selval[RSRC_NAME] = 1;
	m_selval[CONTAINER_NAME] = 1;
	m_selval[DATA_COMMENTS] = 1;

    sprintf(m_qval[DATA_GRP_NAME]," = '%s'", parent->GetPath());
    sprintf(m_qval[DATA_NAME]," = '%s'", name);

    StatusCode status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)m_session->GetCurrentZone(parent)->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
	{
		if(-3005 == status)
			return SRB_OK;
		return status;
	}

	filterDeleted(&m_result);

	if(m_result.row_count != 1)
		return SRB_ERROR;

	DatasetNodeImpl* baby;

	baby = new DatasetNodeImpl(parent, &m_result, 0);

	parent->AddChild(baby);

	//while(m_result.continuation_index >= 0)
	//{
		//add code for this later	
	//}

	*child = baby;

	return SRB_OK;
}

StatusCode DatasetOperatorImpl::Delete(IDatasetNode* target)
{
	char tmpPath[MAX_TOKEN];
    
	int replNum = atoi(target->GetReplicationIndex());

	const char* container = target->GetContainer();

	if(0 != strcmp("", container))
	{
		replNum = -1;
	}

    if (replNum >= 0)
	{
        sprintf (tmpPath, "%s&COPY=%s", target->GetName(), target->GetReplicationIndex()); 
    }else
	{
		sprintf (tmpPath, "%s", target->GetName());
    }

    StatusCode status = srbObjUnlink(m_conn, tmpPath, (char*)target->GetParent()->GetPath());

	SRB::CollectionNodeImpl* papa = (CollectionNodeImpl*)target->GetParent();

	if(status.isOk())
	{
		papa->DeleteChild(target);
	}

	return status;
}

StatusCode DatasetOperatorImpl::Replicate(IDatasetNode* target)
{
	if(NULL == target)
		return SRB_ERROR_INVALID_PARAMETER;

	int replIn;

	char* szContainer = (char*)target->GetContainer();
	if(0 == strcmp("",szContainer))
	{
		replIn = atoi(target->GetReplicationIndex());
	}else
	{
		replIn = -1;
	}

	char buf[MAX_TOKEN];

    sprintf(buf, "%s&COPY=%i", target->GetName(), replIn);

    StatusCode status = srbObjReplicate(m_conn, 0, (char*)target->GetName(), (char*) target->GetParent()->GetPath(), (char*)m_binding->GetName(), "");

	if(status.isOk())
	{

		status = GetReplicant((ICollectionNode*)target->GetParent(), target->GetName());
	}

	return status;
}

StatusCode DatasetOperatorImpl::GetReplicant(ICollectionNode* target, const char* name)
{
	ClearMCATScratch();

    m_selval[DATA_NAME] = 1;
    m_selval[DATA_GRP_NAME] = 1;
    m_selval[SIZE] = 1;
    m_selval[DATA_TYP_NAME] = 1;
	m_selval[DATA_OWNER] = 1;
	m_selval[REPL_TIMESTAMP] = 1;
	m_selval[DATA_REPL_ENUM] = 1;
	m_selval[PHY_RSRC_NAME] = 1;
	//m_selval[RSRC_NAME] = 1;
	m_selval[CONTAINER_NAME] = 1;
	m_selval[DATA_COMMENTS] = 1;

    sprintf(m_qval[DATA_GRP_NAME]," = '%s'", target->GetPath());
	sprintf(m_qval[DATA_NAME], " = '%s'", name);
	//sprintf(m_qval[DATA_REPL_ENUM], " = '%d'", repl);

    StatusCode status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)m_session->GetCurrentZone(target)->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
	{
		if(-3005 == status)
			return SRB_OK;
		return status;
	}

	filterDeleted(&m_result);

	DatasetNodeImpl* baby;

	INode* node;


	char* repl;

	bool found;
	for(int j = 0; j < m_result.row_count; j++)
	{
		found = false;

		repl = getFromResultStruct(&m_result,dcs_tname[DATA_REPL_ENUM], dcs_aname[DATA_REPL_ENUM]);
		repl += j * MAX_DATA_SIZE;

		for(int i = 0; i < target->CountChildren(); i++)
		{
			node = target->GetChild(i);
			if(SOB_DATASET == node->GetType())
			{
				if(0 == strcmp(name, node->GetName()))
				{
					if(0 == strcmp(repl, ((IDatasetNode*)node)->GetReplicationIndex()))
					{
						found = true;
						break;
					}
				}
			}
		}

		if(!found)
		{
			baby = new DatasetNodeImpl(target, &m_result, j);
			((CollectionNodeImpl*)target)->AddChild(baby);
		}
	}

	return SRB_OK;
}

StatusCode DatasetOperatorImpl::GetChildren(DatasetNodeImpl* target, unsigned int mask)
{
	if(NULL == target)
		return SRB_ERROR_INVALID_PARAMETER;

	target->Clear();

	unsigned int success = SOB_ALL ^ (SOB_ACCESS | SOB_METADATA);

	StatusCode status;

	if(SOB_ACCESS & mask)
	{
		status = GetAccess(target);
		if(status.isOk())
			success |= SOB_ACCESS;
		else
		{
			target->SetOpen(success);
			return status;
		}
	}

	if(SOB_METADATA & mask)
	{
		status = GetMetadata(target);
		if(status.isOk())
			success |= SOB_METADATA;
		else
		{
			target->SetOpen(success);
			return status;
		}
	}

	target->SetOpen(success);
	return status;
}

StatusCode DatasetOperatorImpl::GetAccess(DatasetNodeImpl* target)
{
	ClearMCATScratch();

	SRB::INode* blah = target->GetParent();

	sprintf(m_qval[DATA_GRP_NAME], " = '%s'", blah->GetPath());
	sprintf(m_qval[DATA_NAME], " = '%s'", target->GetName());

	m_selval[USER_NAME] = 1;
	m_selval[DOMAIN_DESC] = 1;
	m_selval[ACCESS_CONSTRAINT] = 1;

    StatusCode status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)m_session->GetCurrentZone(target)->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
	{
		if(-3005 == status)
			status = SRB_OK;

		return status;
	}

	if(0 == m_result.row_count)
		return SRB_OK;

	filterDeleted(&m_result);

	IAccessNode* access_node;
	

	char *user, *domain, *constraint;
	
	user = getFromResultStruct(&m_result, dcs_tname[USER_NAME], dcs_aname[USER_NAME]);
	domain = getFromResultStruct(&m_result, dcs_tname[DOMAIN_DESC], dcs_aname[DOMAIN_DESC]);
	constraint = getFromResultStruct(&m_result, dcs_tname[ACCESS_CONSTRAINT], dcs_aname[ACCESS_CONSTRAINT]);
	access_node = new AccessNodeImpl(target, NULL, domain, user, constraint);
	target->AddChild(access_node);

	for(int i = 1; i < m_result.row_count; i++)
	{
		user += MAX_DATA_SIZE;
		domain += MAX_DATA_SIZE;
		constraint += MAX_DATA_SIZE;
		access_node = new AccessNodeImpl(target, NULL, domain, user, constraint);
		target->AddChild(access_node);
	}

	//while(m_result.continuation_index >= 0)
	//{
		//implement later
	//}

	return SRB_OK;
}

StatusCode DatasetOperatorImpl::GetMetadata(DatasetNodeImpl* target)
{
	ClearMCATScratch();

	SRB::INode* blah = target->GetParent();

	sprintf(m_qval[DATA_GRP_NAME], " = '%s'", blah->GetPath());
	sprintf(m_qval[DATA_NAME], " = '%s'", target->GetName());
	sprintf(m_qval[METADATA_NUM], " >= 0");

	m_selval[UDSMD0] = 1;
	m_selval[UDSMD1] = 1;
	m_selval[METADATA_NUM] = 1;

    StatusCode status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)m_session->GetCurrentZone(target)->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
	{
		if(-3005 == status)
			status = SRB_OK;

		return status;
	}

	filterDeleted(&m_result);

	MetadataNodeImpl* meta;

	char *attribute, *value, *ID;
	
	for(int i = 0; i < m_result.row_count; i++)
	{
		attribute = getFromResultStruct(&m_result, dcs_tname[UDSMD0], dcs_aname[UDSMD0]);
		attribute += i * MAX_DATA_SIZE;
		value = getFromResultStruct(&m_result, dcs_tname[UDSMD1], dcs_aname[UDSMD1]);
		value += i * MAX_DATA_SIZE;
		ID = getFromResultStruct(&m_result, dcs_tname[METADATA_NUM], dcs_aname[METADATA_NUM]);
		ID += i * MAX_DATA_SIZE;

		meta = new MetadataNodeImpl(target, attribute, SOB_MD_EQUAL, value);
		meta->SetID(atoi(ID));

		target->AddChild(meta);
	}

	//while(m_result.continuation_index >= 0)
	//{
		//implement later
	//}

	return SRB_OK;
}

void DatasetOperatorImpl::ClearMCATScratch()
{
    clearSqlResult (&m_result);

    for(int i = 0; i < MAX_DCS_NUM; i++)
	{
        sprintf(m_qval[i],"");
        m_selval[i] = 0;
    }
}


StatusCode DatasetOperatorImpl::AddMeta(IDatasetNode* target, const char* attribute, IMetadataNode** result = 0)
{
	if(NULL == target || NULL == attribute)
		return SRB_ERROR_INVALID_PARAMETER;

	int id = srbModifyDataset(m_conn, 0, (char*)target->GetName(),(char*)target->GetParent()->GetPath(),"","","0",(char*)attribute, D_INSERT_USER_DEFINED_STRING_META_DATA);

	DatasetNodeImpl* dataset = (DatasetNodeImpl*)target;

	MetadataNodeImpl* baby = new MetadataNodeImpl(target, attribute, SOB_MD_EQUAL, NULL);
	baby->SetID(id);

	dataset->AddChild(baby);

	if(NULL != result)
		*result = baby;

	return SRB_OK;
}

StatusCode DatasetOperatorImpl::ModifyMeta(IMetadataNode* target, const char* value)
{
	if(NULL == target || NULL == value)
		return SRB_ERROR_INVALID_PARAMETER;

	IDatasetNode* dataset = (IDatasetNode*)target->GetParent();
	ICollectionNode* collection = (ICollectionNode*)dataset->GetParent();

	static char buf[256];

	sprintf(buf, "1@%d", ((MetadataNodeImpl*)target)->GetID());
	//StatusCode status = srbModifyDataset(m_conn, 0,(char*)dataset->GetName(),(char*)collection->GetPath(),buf,"", (char*)value, "", D_CHANGE_USER_DEFINED_STRING_META_DATA);
	StatusCode status = srbModifyDataset(m_conn, 0, (char*)dataset->GetName(), (char*)collection->GetPath(), "", "", buf, (char*)value, D_CHANGE_USER_DEFINED_STRING_META_DATA);

	if(status.isOk())
		((MetadataNodeImpl*)target)->SetValue(value);

	return status;
}

StatusCode DatasetOperatorImpl::DeleteMeta(IMetadataNode* target)
{
	if(NULL == target)
		return SRB_ERROR_INVALID_PARAMETER;

	DatasetNodeImpl* parent = (DatasetNodeImpl*)target->GetParent();

	static char buf[10];

	sprintf(buf, "%d", ((MetadataNodeImpl*)target)->GetID());

	StatusCode status = srbModifyDataset(m_conn, 0, (char*)parent->GetName(), (char*)parent->GetParent()->GetPath(),"","",buf,"",D_DELETE_USER_DEFINED_STRING_META_DATA);

	if(status.isOk())
		parent->DeleteChild(target);

	return status;
}
#if 0
void makesafeSRBstring(char* original, char* copy)
{
	len = strlen(original);
	
	while
}
#endif

StatusCode DatasetOperatorImpl::Rename(IDatasetNode* target, const char* name)
{
	char targetNameBuf[1024];
	char targetCollBuf[1024];
	char newNameBuf[1024];



	StatusCode status = srbModifyDataset(m_conn, 0, (char*)target->GetName(), (char*)target->GetParent()->GetPath(), "", "", (char*)name, "", D_CHANGE_DNAME);

	if(status.isOk())
		status = ((DatasetNodeImpl*)target)->SetName(name);

	return status;
};

StatusCode DatasetOperatorImpl::SetComment(IDatasetNode* target, const char* comment)
{
	if(NULL == target)
		return SRB_ERROR_INVALID_PARAMETER;

	int retractionType;

	if(0 == strcmp("", target->GetComment()))
		retractionType = D_INSERT_COMMENTS;
	else
		if(NULL == comment || '\0' == comment[0])
			retractionType = D_DELETE_COMMENTS;			//can we supply modifydataset with NULL? or does it have to be ""?
		else
			retractionType = D_UPDATE_COMMENTS;

	StatusCode status = srbModifyDataset(m_conn, 0, (char*)target->GetName(), (char*)target->GetParent()->GetPath(), "", "", (char*)comment,"", retractionType);

	if(status.isOk())
	{
		((DatasetNodeImpl*)target)->SetComment(comment);
	}

	return status;
};
}//end namespace
	
