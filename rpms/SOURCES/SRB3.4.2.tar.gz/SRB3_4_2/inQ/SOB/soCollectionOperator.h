#ifndef __SRB_OBJECT_COLLECTION_OPERATOR_H__
#define __SRB_OBJECT_COLLECTION_OPERATOR_H__
#include "soGlobals.h"
#include "soNode.h"
#include "clConnectExtern.h"
#include "soCollection.h"
#include "scommands.h"

namespace SRB
{
class CollectionOperatorImpl : public ICollectionOperator
{
public:
	CollectionOperatorImpl(ISession* session);
	~CollectionOperatorImpl();

	StatusCode Bind(INode* node);
	StatusCode Download(INode* target, const char* local_path);
	StatusCode Upload(INode* target, const char* local_path, unsigned int overwrite, INode** result);
	StatusCode Copy(ICollectionNode* target, IDatasetNode* data, IDatasetNode** result = NULL);
	StatusCode Copy(ICollectionNode* target, ICollectionNode* data, ICollectionNode** result = NULL);
	StatusCode Move(ICollectionNode* target, IDatasetNode* data, IDatasetNode** result = NULL);
	StatusCode Move(ICollectionNode* target, ICollectionNode* data, ICollectionNode** result = NULL);
	StatusCode Delete(ICollectionNode* target);
	StatusCode Replicate(ICollectionNode* target);
	StatusCode Replicate_Recursive_Impl(ICollectionNode* target);
	StatusCode Rename(ICollectionNode* target, const char* name);
	StatusCode SetComment(ICollectionNode* target, const char* comment);
	StatusCode Create(ICollectionNode* target, const char* name, ICollectionNode** result = NULL);
	StatusCode AddMeta(ICollectionNode* target, const char* attribute, IMetadataNode** result = NULL);
	StatusCode ModifyMeta(IMetadataNode* target, const char* value);
	StatusCode DeleteMeta(IMetadataNode* target);
	StatusCode ModifyAccess(IAccessNode* target, const char* permission, bool recursive);
	StatusCode SetAccess(ICollectionNode* target, IUserNode* owner, const char* permission, bool recursive);
	int GetType() { return SOB_OP_COLLECTION; };

	INode* GetBinding() { return m_binding;};
	int GetProgress(char** name);

	//impl
	StatusCode ModifyCollectionRecursively(ICollectionNode* target, IUserNode* owner, const char* permission);
	StatusCode GetChildren(CollectionNodeImpl* target, unsigned int mask = SOB_ALL);

private:

	int UploadImpl(srbConn* bloadconn, char* local, char* collection, char* resource, bool isContainer);
	int DownloadImpl(srbConn* bdown_conn, const char* local, const char* source, int copyNum, srb_long_t* bytes_received, srb_long_t* bytes_expected);
#if 0
	int getMain (srbConn *conn, int catType, int nArgv, srbPathName nameArray[], srbPathName targNameArray[], int flagval, int copyNum, char *ticketId, srb_long_t* bytes_received);
#endif
	void FooM(INode* node, const char* szDomain, const char* szUser, const char* new_permission);
	void FooD(INode* node, const char* szDomain, const char* szUser);
	void MyMod(const char* permission, IAccessNode* target, bool recursive);

	CollectionOperatorImpl();
	CollectionOperatorImpl(const CollectionOperatorImpl& source);
	CollectionOperatorImpl& operator =(const CollectionOperatorImpl& source);

	StatusCode GetAccess(CollectionNodeImpl* target);
	StatusCode GetChildCollections(CollectionNodeImpl* target);


	StatusCode GetChildDatasets(CollectionNodeImpl* target);
 	StatusCode GetMetadata(CollectionNodeImpl* target);

	void SetAccessNodes(INode* target, IUserNode* owner, const char* permission, bool recursive, int retraction_type);

	StatusCode FillDataset(CollectionNodeImpl* parent, IDatasetNode** child, const char* name);
	void ClearMCATScratch();

	srb_long_t m_bytes_received;
	srb_long_t m_bytes_expected;

	mdasC_sql_result_struct m_result;
	char m_qval[MAX_DCS_NUM][MAX_TOKEN];
	int m_selval[MAX_DCS_NUM];
	srbConn* m_conn;
	ISession* m_session;
	INode* m_binding;
	char m_downloading[1024];
	bool m_bIsDownloading;
};
}//end namespace
#endif

