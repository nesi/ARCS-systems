#include "soStatusCode.h"
#include "soGlobals.h"
//#include "srb_error.h"

extern "C"
{
//extern int Srb_errtbl_serialno;
//extern int Srb_numents;
//extern struct srb_errtbl srb_errent[1383];
}

namespace SRB
{
#if 0
StatusCode::StatusCode(const int& source)
{
	m_code = source;
}
StatusCode::StatusCode(const StatusCode& source)
{
	m_code = source.m_code;
}
StatusCode::StatusCode()
{
	m_code = SRB_OK;
}
#endif


StatusCode& StatusCode::operator=(const int& source)
{
	m_code = source;

	return *this;
}


bool StatusCode::isOk()
{
	if(m_code < 0)	//negative	//nonzero
		if(-3005 != m_code)
			return false;

	return true;
}

const char* StatusCode::GetError()
{
	int i;

	for(i=0;i<Srb_numents;i++)
		if(m_code == srb_errent[i].srb_err)
			break;

	return srb_errent[i].srb_err_short;
}

}

