#include "soZoneOperator.h"
#include "soZone.h"
#include "soUser.h"
#include "soContainer.h"
#include "clStubExtern.h"
#include "scommands.h"
#include "soSession.h"
#include "soCollectionOperator.h"
#include "soDatasetOperator.h"
#include "soQueryOperator.h"
#include "soQueryOperator2.h"
#include "soResourceOperator.h"
#include "soContainerOperator.h"
#include "soDomainOperator.h"
#include "soZoneOperator.h"
#include "soString.h"
#include "soSet.h"

namespace SRB
{

ZoneOperatorImpl::ZoneOperatorImpl(ISession* session)
{
	m_session = session;
	m_result.result_count = 0;
    m_result. row_count = 0;
}

ZoneOperatorImpl::~ZoneOperatorImpl()
{
}

void ZoneOperatorImpl::ClearMCATScratch()
{
    clearSqlResult(&m_result);

    for(int i = 0; i < MAX_DCS_NUM; i++)
	{
        sprintf(m_qval[i],"");
        m_selval[i] = 0;
    }
}

StatusCode ZoneOperatorImpl::GetChildren(ZoneNodeImpl* target, int clean, unsigned int mask)
{
	if(NULL == target)
		return SRB_ERROR_INVALID_PARAMETER;

	if(clean)
	{
		target->Clear();
	}

	StatusCode status;
	
	unsigned int success = SOB_ALL ^ SOB_COLLECTION ^ SOB_RESOURCE ^ SOB_DOMAIN ^ SOB_CONTAINER;

	if((SOB_COLLECTION & mask) && !(SOB_COLLECTION & target->GetOpen()))
	{
		status = GetZoneCollections(target);
		if(status.isOk())
		{
			//status = GetLocalCollection(target);
			if(status.isOk())
			{
				success |= SOB_COLLECTION;
			}	
		}
		
		if(!(success & SOB_COLLECTION))
		{
			target->SetOpen(success);
			return status;
		}

	}


	
	if((SOB_RESOURCE & mask) && !(SOB_RESOURCE & target->GetOpen()))
	{
		status = GetResources(target);
		if(status.isOk())
		{
			success |= SOB_RESOURCE;
		}
		else
		{
			target->SetOpen(success);
			return status;
		}

		if(SOB_CONTAINER & mask)
		{
			status = GetAllContainers(target);
			if(status.isOk())
			{
				success |= SOB_CONTAINER;
			}
			else
			{
				target->SetOpen(success);
				return status;
			}
		}
	}

	if((SOB_DOMAIN & mask) && !(SOB_DOMAIN & target->GetOpen()))
	{
		status = GetDomains(target);
		if(status.isOk())
		{
			success |= SOB_DOMAIN;
		}
		else
		{
			target->SetOpen(success);
			return status;
		}
	}

	target->SetOpen(success);
	return status;
}

StatusCode ZoneOperatorImpl::GetDomains(ZoneNodeImpl* target)
{
	ClearMCATScratch();

	//sprintf(m_qval[ZONE_NAME]," = '%s'", target->GetName());
	m_selval[DOMAIN_DESC] = 1;

	StatusCode status = srbGetDataDirInfoWithZone((srbConn*)m_session->GetConn(), 0, (char*)target->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);
						
	if(!status.isOk())
		return status;

	filterDeleted (&m_result);

	SetNodeImpl* domain_set = new SetNodeImpl(target, "domains", SOB_DOMAIN);
	target->AddChild(domain_set);

	DomainNodeImpl* child;

	char* szDomain = getFromResultStruct(&m_result, dcs_tname[DOMAIN_DESC], dcs_aname[DOMAIN_DESC]);

	if(szDomain == NULL)
		if(m_result.row_count != 0)
			return SRB_ERROR;
		else
			return SRB_OK;

	child = new DomainNodeImpl(target, szDomain);
	domain_set->AddChild(child);

	for (i=1; i < m_result.row_count; i++) 
	{
		szDomain += MAX_DATA_SIZE;
		child = new DomainNodeImpl(target, szDomain);
		domain_set->AddChild(child);
	}

	return SRB_OK;
}

StatusCode ZoneOperatorImpl::GetResources(ZoneNodeImpl* target)
{
	ClearMCATScratch();

	//sprintf(m_qval[ZONE_NAME]," = '%s'", target->GetName());
	//sprintf(m_qval[RSRC_NAME], " not like  '%%$deleted%%'" );
	m_selval[RSRC_NAME] = 1;
	m_selval[RSRC_TYP_NAME] = 1;

	//resources are a little different in that there is a set of resources, and no root
	//resource, unlike a collection. In the beginning we wanted to have each resource
	//be its own child of the zone, but in many instances that was not ideal - as we
	//had to iterate through the entire zone to find all the resources to display.
	SetNodeImpl* resource_set = new SetNodeImpl(target, "resources", SOB_RESOURCE);
	target->AddChild(resource_set);


	StatusCode status = srbGetDataDirInfoWithZone((srbConn*)m_session->GetConn(), 0, (char*)target->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
		if(-3005 == status)
		{
			target->SetOpen(SOB_ALL);
			return SRB_OK;
		}
		else
			return status;

	filterDeleted(&m_result);

	char* ptr = (char*)getFromResultStruct(&m_result, dcs_tname[RSRC_NAME], dcs_aname[RSRC_NAME]);
	char* type = (char*)getFromResultStruct(&m_result, dcs_tname[RSRC_TYP_NAME], dcs_aname[RSRC_TYP_NAME]);

	if(ptr == NULL)
		return SRB_ERROR;

	if(type == NULL)
		return SRB_ERROR;

	if(0 == m_result.row_count)
		return SRB_ERROR;


	IResourceNode* child;
	child = new ResourceNodeImpl(target, ptr, type);
	resource_set->AddChild(child);

	for(i = 1; i < m_result.row_count; i++)
	{
		ptr += MAX_DATA_SIZE;
		type += MAX_DATA_SIZE;
		child = new ResourceNodeImpl(target, ptr, type);
		resource_set->AddChild(child);
	}

	//note that currently we assume there is less than 200 different resources, as we
	//don't check for continuation.
	return SRB_OK;
}

//creates root collection '/home' and its children (home collections)
StatusCode ZoneOperatorImpl::GetZoneCollections(ZoneNodeImpl* target)
{

	ClearMCATScratch();


	CollectionNodeImpl* root = new CollectionNodeImpl(target, "home");
	target->AddChild(root);	


    m_selval[DATA_GRP_NAME] = 1;
    sprintf(m_qval[PARENT_COLLECTION_NAME]," = '%s'", root->GetPath());


    StatusCode status = srbGetDataDirInfoWithZone((srbConn*)m_session->GetConn(), 0, (char*)target->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);


	if(!status.isOk() || -3005 == status)
	{
		//even though root collection could have user permissions, datasets, etc.
		//we set the root to all because usually they aren't things we want to see.
		//root->SetOpen(SOB_ALL);
		target->DeleteChild(root);
		return SRB_OK;
	}



	filterDeleted(&m_result);

	char *original, *szptr;

	int len;

	while(true)
	{
		original = getFromResultStruct(&m_result,dcs_tname[DATA_GRP_NAME], dcs_aname[DATA_GRP_NAME]);

		for(int i = 0; i < m_result.row_count; i++)
		{
			szptr = original;

			len = strlen(szptr);

			for(int j = len - 1; j >= 0; j--)
				if('/' == szptr[j])
				{
					szptr = &szptr[j+1];
					break;
				}

			root->AddChild(new CollectionNodeImpl(root, szptr));

			original += MAX_DATA_SIZE;
		}

		if(m_result.continuation_index < 0)
		{
			//setting root to all keeps us from looking for its access permissions, etc.
			//note this used to take a long time, at least, and was ultimately not what
			//we wanted to show, hence the hack.
			root->SetOpen(SOB_ALL);
			break;
		}

		status = srbGetMoreRows((srbConn*)m_session->GetConn(), 0, m_result.continuation_index, &m_result, MAX_ROWS);

		if(-3005 == status)	
			return SRB_OK;

		if(0 != status)
			return SRB_ERROR;
	}

	return SRB_OK;
}

StatusCode ZoneOperatorImpl::GetLocalCollection(ZoneNodeImpl* target)
{

	ClearMCATScratch();


	CollectionNodeImpl* root = new CollectionNodeImpl("home");
	target->AddChild(root);	


    m_selval[DATA_GRP_NAME] = 1;
    sprintf(m_qval[PARENT_COLLECTION_NAME]," = '%s'", root->GetPath());


    StatusCode status = srbGetDataDirInfoWithZone((srbConn*)m_session->GetConn(), 0, (char*)target->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);


	if(!status.isOk() || -3005 == status)
	{
		//even though root collection could have user permissions, datasets, etc.
		//we set the root to all because usually they aren't things we want to see.
		//root->SetOpen(SOB_ALL);
		target->DeleteChild(root);
		return SRB_OK;
	}



	filterDeleted(&m_result);

	char *original, *szptr;

	int len;

	while(true)
	{
		original = getFromResultStruct(&m_result,dcs_tname[DATA_GRP_NAME], dcs_aname[DATA_GRP_NAME]);

		for(int i = 0; i < m_result.row_count; i++)
		{
			szptr = original;

			len = strlen(szptr);

			for(int j = len - 1; j >= 0; j--)
				if('/' == szptr[j])
				{
					szptr = &szptr[j+1];
					break;
				}

			root->AddChild(new CollectionNodeImpl(root, szptr));

			original += MAX_DATA_SIZE;
		}

		if(m_result.continuation_index < 0)
		{
			//setting root to all keeps us from looking for its access permissions, etc.
			//note this used to take a long time, at least, and was ultimately not what
			//we wanted to show, hence the hack.
			root->SetOpen(SOB_ALL);
			break;
		}

		status = srbGetMoreRows((srbConn*)m_session->GetConn(), 0, m_result.continuation_index, &m_result, MAX_ROWS);

		if(-3005 == status)	
			return SRB_OK;

		if(0 != status)
			return SRB_ERROR;
	}

	return SRB_OK;
}

StatusCode ZoneOperatorImpl::GetAllContainers(IZoneNode* target)
{
	char* zone = (char*)(target->GetName());

	ClearMCATScratch();

	m_selval[CONTAINER_NAME] = 1;
	m_selval[CONTAINER_LOG_RSRC_NAME] = 1;

	sprintf(m_qval[CONTAINER_NAME], " like '/%s/container/%s.%s/%%'",zone, m_session->GetName(), m_session->GetUserDomain());

	StatusCode status = srbGetDataDirInfoWithZone((srbConn*)m_session->GetConn(), 0, zone, m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
		return status;

	INode* resources = target->GetChild("resources");

	if(0 == m_result.row_count)	//should mark all resources as open
	{
		for(int j = 0; j < resources->CountChildren(); j++)
			((ResourceNodeImpl*)(resources->GetChild(j)))->SetOpen(SOB_ALL);
		return SRB_OK;
	}

	filterDeleted(&m_result);

	char* szName = (char*)getFromResultStruct(&m_result, dcs_tname[CONTAINER_NAME], dcs_aname[CONTAINER_NAME]);
	char* szResource = (char*)getFromResultStruct(&m_result, dcs_tname[CONTAINER_LOG_RSRC_NAME], dcs_aname[CONTAINER_LOG_RSRC_NAME]);

	if(NULL == szName || NULL == szResource)
		return SRB_ERROR;

	ResourceNodeImpl* blah = (ResourceNodeImpl*)resources->GetChild(szResource);

	if(NULL == blah)
		return SRB_ERROR;

	char* szPrevResource = szResource;

	ContainerNodeImpl* child = new ContainerNodeImpl(blah, szName);

	blah->AddNode(child);

	for(i = 1; i < m_result.row_count; i++)
	{
		szName += MAX_DATA_SIZE;
		szResource += MAX_DATA_SIZE;

		if(0 != strcmp(szResource, szPrevResource))
		{
			blah = (ResourceNodeImpl*)resources->GetChild(szResource);

			if(NULL == blah)
				return SRB_ERROR;

			szPrevResource = szResource;
		}

		child = new ContainerNodeImpl(blah, szName);
		blah->AddNode(child);
	}

	for(int j = 0; j < resources->CountChildren(); j++)
		((ResourceNodeImpl*)(resources->GetChild(j)))->SetOpen(SOB_ALL);

	return SRB_OK;
}

};
