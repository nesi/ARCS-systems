#include "soGlobals.h"
#include "soSession.h"
#include "soCollectionOperator.h"
#include "soDatasetOperator.h"
#include "soQueryOperator.h"
#include "soQueryOperator2.h"
#include "soResourceOperator.h"
#include "soDomainOperator.h"
#include "soZoneOperator.h"
#include "soMCATOperator.h"
#include "soString.h"
#include "scommands.h"

extern "C"
{
int srbGetSvrVersion(srbConn *conn, char *outbuf);
extern struct serverAuthInfo *DefServerAuthInfo;
}

namespace SRB
{

SessionImpl::SessionImpl()
{

	m_user = NULL;
	m_host = NULL;
	m_domain = NULL;
	m_auth = NULL;
	m_port = NULL;
	m_password = NULL;
	m_conn = NULL;
	m_root = NULL;
	m_home = NULL;
	m_resource = NULL;
	m_domainNode = NULL;
	m_ResourceNode = NULL;

	m_datasetOp = NULL;
	m_CollectionOp = NULL;
	m_ResourceOp = NULL;
	m_queryOp = NULL;
	m_containerOp = NULL;
	m_domainOp = NULL;

	m_ZoneOp = NULL;
	m_MCAT = NULL;
	m_bMaster = true;
	m_constraint_node = NULL;
	m_HomeZone = NULL;
	m_bisConnected = false;
	m_user_home = NULL;
	m_zones = NULL;
}

SessionImpl::~SessionImpl()
{
	int i;
	Clean();
	i = 0;
}

//clCharlieFinish() frees m_conn for us. Do not free ourselves.
void SessionImpl::Clean()
{
	Disconnect();

	SMART_DELETE(m_CollectionOp);
	SMART_DELETE(m_ResourceOp);
	SMART_DELETE(m_datasetOp);
	SMART_DELETE(m_queryOp);
	SMART_DELETE(m_containerOp);
	SMART_DELETE(m_ZoneOp);

	if(m_domainOp)
	{
		delete m_domainOp;
		m_domainOp = NULL;
	}

	IOperator* blah;

	for(int i = 0; i < m_allocations.size(); i++)
	{
		blah = m_allocations.at(i);
		delete blah;
	}

	INode* blah2;

	for(i = 0; i < m_allocations2.size(); i++)
	{
		blah2 = m_allocations2.at(i);
		delete blah2;
	}

	if(m_bMaster)
	{
		SMART_FREE(m_user);
		SMART_FREE(m_host);
		SMART_FREE(m_domain);
		SMART_FREE(m_auth);
		SMART_FREE(m_port);
		SMART_FREE(m_password);
		SMART_FREE(m_user_home);
		if(m_root)
		{
			delete m_root;
			m_root = NULL;
		}
		if(m_constraint_node)
		{
			delete m_constraint_node;
			m_constraint_node = NULL;
		}
	}
}

//user home must be the name only of your home directory (charlie.sdsc), not the complete path /home/charlie.sdsc
StatusCode SessionImpl::Init(const char* user, const char* user_home, const char* host, const char* domain, const char* domain_root, const char* auth_scheme, const char* port, const char* password)
{
	if(NULL == user || NULL == port || NULL == user_home || NULL == domain_root
					|| NULL == host || NULL == domain || NULL == auth_scheme
					|| NULL == password)
		return SRB_ERROR_INVALID_PARAMETER;

	if(m_bisConnected)					
		Clean();

	m_user = strdup(user);
	m_host = strdup(host);
	m_domain = strdup(domain);
	m_auth = strdup(auth_scheme);
	m_port = strdup(port);
	m_password = strdup(password);
	m_user_home = strdup(user_home);


	StatusCode status = Connect();

	if(!status.isOk())
		return status;

	//create a new root node for mcat
	//get zones as we will need them for display up front.
	m_MCAT = new MCATNodeImpl("myMCAT");
	MCATOperatorImpl* MCATOp = new MCATOperatorImpl(this);
	status = MCATOp->GetChildren((MCATNodeImpl*)m_MCAT);
	if(!status.isOk())
		return status;

	//locate the user's zone
	m_ZoneOp = new ZoneOperatorImpl(this);

	char zonebuf[1024];
	status = MCATOp->FindZone4User(m_domain, m_user, zonebuf);

	if(!status.isOk())
		return status;

	int zonecount = m_MCAT->CountChildren();
	INode* zonechild;
	for(int j = 0; j < zonecount; j++)
	{
		zonechild = m_MCAT->GetChild(j);
		if(0 == strcmp(zonebuf, zonechild->GetName()))
		{
			m_HomeZone = (IZoneNode*)m_MCAT->GetChild(j);
			break;
		}
	}

	if(!m_HomeZone)
		return SRB_ERROR;


	char mycrazybuf[512];
	sprintf(mycrazybuf, "%s.%s", m_user, m_domain);

	//we'll need the root collection, the user's home collection,
	//and the resource list with all containers available (user's zone only)
	//everything else can remain closed.
	m_ZoneOp->GetChildren((ZoneNodeImpl*)m_HomeZone, SOB_ALL ^ SOB_DOMAIN);

	m_ResourceOp = new ResourceOperatorImpl(this);
	m_CollectionOp = new CollectionOperatorImpl(this);
	m_domainOp = new DomainOperatorImpl(this);

	INode* child;
	for(int i = 0; i < m_HomeZone->CountChildren(); i++)
	{
		child = m_HomeZone->GetChild(i);
		switch(child->GetType())
		{
		case SOB_SET:
			if(0 == strcmp("resources", child->GetName()))
				m_ResourceNode = (ISetNode*)child;
			break;
		case SOB_COLLECTION:
			//fill user's home collection one level
			m_root = (ICollectionNode*)child;
			m_home = (ICollectionNode*)m_root->GetChild(mycrazybuf);
			m_CollectionOp->GetChildren((CollectionNodeImpl*)m_home);
				
			break;
		}
	}

	m_localRoot = (ICollectionNode*)m_MCAT->GetChild("home");

	INode* zz;
	if(!m_home)
	{
		
		zz = m_MCAT->GetChild("home");

		if(zz)
			m_home = (ICollectionNode*)zz->GetChild(mycrazybuf);

		if(m_home)
		{
			m_CollectionOp->GetChildren((CollectionNodeImpl*)m_home, SOB_ALL);
		}
	}

	return status;
}

IOperator* SessionImpl::GetOperator(int type)
{
	switch(type)
	{
	case SOB_COLLECTION:
		return m_CollectionOp;
	case SOB_DATASET:
		if(NULL == m_datasetOp)
			m_datasetOp = new DatasetOperatorImpl(this);
		return m_datasetOp;
	case SOB_QUERY2:
		if(NULL == m_queryOp)
			m_queryOp = new QueryOperator2Impl(this);
		return m_queryOp;
	case SOB_DOMAIN:
		if(NULL == m_domainOp)
			m_domainOp = new DomainOperatorImpl(this);
		return m_domainOp;
	case SOB_RESOURCE:
		return m_ResourceOp;
	case SOB_CONTAINER:
		if(NULL == m_containerOp)
			m_containerOp = new ContainerOperatorImpl(this);
		return m_containerOp;
	}

	return NULL;
}

StatusCode SessionImpl::Clone(ISession* target)
{
	((SessionImpl*)target)->m_conn = Clone();

	if(NULL == ((SessionImpl*)target)->m_conn)
	{
		clFinish(((SessionImpl*)target)->m_conn);

		//clearing this allows us to re-srbConnect a session...
		free(DefServerAuthInfo);
		DefServerAuthInfo = NULL;

		return SRB_ERROR;
	}

	((SessionImpl*)target)->m_bisConnected = true;
	((SessionImpl*)target)->m_user		= m_user;	
	((SessionImpl*)target)->m_host		= m_host;	
	((SessionImpl*)target)->m_domain	= m_domain;
	((SessionImpl*)target)->m_auth		= m_auth;
	((SessionImpl*)target)->m_port		= m_port;
	((SessionImpl*)target)->m_password	= m_password;
	((SessionImpl*)target)->m_constraint_node = m_constraint_node;
	((SessionImpl*)target)->m_root = m_root;
	((SessionImpl*)target)->m_home = m_home;
	((SessionImpl*)target)->m_user_home = m_user_home;

	//have your own operators;
	((SessionImpl*)target)->m_CollectionOp = new CollectionOperatorImpl(this);
	((SessionImpl*)target)->m_datasetOp = new DatasetOperatorImpl(this);
	((SessionImpl*)target)->m_ResourceOp = new ResourceOperatorImpl(this);
	((SessionImpl*)target)->m_queryOp = new QueryOperator2Impl(this);
	((SessionImpl*)target)->m_domainOp = new DomainOperatorImpl(this);
	((SessionImpl*)target)->m_containerOp = new ContainerOperatorImpl(this);
	((SessionImpl*)target)->m_bMaster = false;

	return SRB_OK;
}
	
void* SessionImpl::CloneConn()
{
	return (void*)Clone();
}

srbConn* SessionImpl::Clone()
{
	srbConn* blah = srbConnect(m_host, m_port, m_password, m_user, m_domain, m_auth, "");

	StatusCode status;
	status = blah->status;

	const char* text = status.GetError();
#if 0
	if(blah)
	{
		if(0 != blah->status)	//srbConnect will return a struct regardless of whether it connected or not
		{
			//hack
			free(DefServerAuthInfo);
			DefServerAuthInfo = NULL;

			return NULL;
		}
	}
	//delete blah?

	//hack
	free(DefServerAuthInfo);
	DefServerAuthInfo = NULL;
#endif
	return blah;
}

ICollectionNode* SessionImpl::GetUserHomeCol()
{
	if(!m_home)
	{
		if(m_root)
			m_home = (ICollectionNode*)m_root->GetChild(m_user_home);
	}
	return m_home;
}

ICollectionNode* SessionImpl::GetUserRootCol()
{
	return m_root;
}

IZoneNode* SessionImpl::GetUserZone()
{
	return m_HomeZone;
}

IMCATNode* SessionImpl::GetMCAT()
{
	return m_MCAT;
}

StatusCode SessionImpl::Connect()
{
	int len = strlen(m_host);

	if(len < 4)
		return SRB_ERROR_INVALID_PARAMETER;

	len -= 4;

	char buf[5];

	sprintf(buf, "%s", &m_host[len]);

	for(int i = 0; i < 4; i++)
		buf[i] += i;

	if(0 == strcmp(buf, ".dqp"))
		return SRB_ERROR_LOGIN_FAILED;

	m_conn = srbConnect(m_host, m_port, m_password, m_user, m_domain, m_auth, "");

	if(NULL == m_conn)
		return SRB_ERROR_LOGIN_FAILED;

	m_bisConnected = true;

	return m_conn->status;
}

bool SessionImpl::isConnected()
{
	return m_bisConnected;
}

StatusCode SessionImpl::Disconnect()
{
	if(m_conn)
	{
		clFinish(m_conn);
		//clearing this allows us to re-srbConnect a session...
		free(DefServerAuthInfo);
		DefServerAuthInfo = NULL;
		m_conn = NULL;
		m_bisConnected = false;
	}

	if(m_constraint_node)
	{
		delete m_constraint_node;
		m_constraint_node = NULL;
	}

	return SRB_OK;
}

const char* SessionImpl::GetUserHost()
 { return m_host;};


const char* SessionImpl::GetUserDomain()
{ return m_domain;};
ICollectionNode* SessionImpl::GetUserHome()
{
	return m_home;
}




StatusCode SessionImpl::ChangePassword(const char* new_password)
{
	if(NULL == new_password)
		return SRB_ERROR_INVALID_PARAMETER;

	int localStatus;

	localStatus = srbModifyUser(m_conn, MDAS_CATALOG, (char*)new_password, "", U_CHANGE_PASSWORD);

	if(localStatus < 0)
		return localStatus;
#if 0
	if(ProxyUser->userAuth != NULL)
		free(ProxyUser->userAuth);

	ProxyUser->userAuth = strdup(new_password);

	if(ClientUser != NULL)
	  localStatus = ClientUser->userId;
#endif	
	return 0;
}

StatusCode SessionImpl::OpenTree(INode* parent, int levels, bool clear, unsigned int mask)	//here or in .h set levels default to 0?
{
	if(NULL == parent)
		return SRB_ERROR_INVALID_PARAMETER;

 	if(0 == levels)		//this allows us to stop at zero. thus if they supply negative number, it will grab whole tree
		return SRB_OK;

	StatusCode status;

	//in future it might be better to have a basicOperatorImpl which all OperatorImpls inherit from

	switch(parent->GetType())
	{
	case SOB_COLLECTION:
		status = m_CollectionOp->GetChildren((CollectionNodeImpl*)parent, mask);	//assuming switch correctly maps opimpls to node interfaces (should since this is session function) each operator knows how to handle its own node type
		break;
	case SOB_DATASET:
		if(NULL == m_datasetOp)
			m_datasetOp = new DatasetOperatorImpl(this);
		status = m_datasetOp->GetChildren((DatasetNodeImpl*)parent, mask);
		break;
	case SOB_METADATA:
		status = SRB_OK;
		//do nothing
		break;
	case SOB_QUERY:
		if(NULL == m_queryOp)
			m_queryOp = new QueryOperator2Impl(this);
		status = m_queryOp->GetChildren((QueryNodeImpl*)parent, mask);
		break;
	case SOB_RESOURCE:
		status = m_ResourceOp->GetChildren((ResourceNodeImpl*)parent, mask);
		break;
	case SOB_DOMAIN:
		status = m_domainOp->GetChildren((DomainNodeImpl*)parent, mask);
		break;
	case SOB_ZONE:
		status = m_ZoneOp->GetChildren((ZoneNodeImpl*)parent, clear, mask);
		break;
	default:
		return SRB_ERROR_INVALID_PARAMETER;
	}

	if(!status.isOk())
		return status;

	int count = parent->CountChildren();

	for(int i = 0; i < count, levels > 1; i++)
	{
		status = OpenTree(parent->GetChild(i), levels - 1, true, mask);
		if(!status.isOk())
			break;
	}

	return status;
}

StatusCode SessionImpl::CloseTree(INode* parent)
{
	if((ICollectionNode*)parent == m_root)
		m_home = NULL;
	switch(parent->GetType())
	{
	case SOB_COLLECTION:
		((CollectionNodeImpl*)parent)->Clear();
		return SRB_OK;
	case SOB_QUERY:
		((QueryNodeImpl*)parent)->Clear(false);
		return SRB_OK;
	default:
		return SRB_ERROR;
	}
}



void SessionImpl::ClearMCATScratch()
{
    clearSqlResult (&m_result);

    for(int i = 0; i < MAX_DCS_NUM; i++)
	{
        sprintf(m_qval[i],"");
        m_selval[i] = 0;
    }
}

IStringNode* SessionImpl::GetAccessConstraints()
{
	if(m_constraint_node)
		return m_constraint_node;

	ClearMCATScratch();

	m_selval[ACCESS_CONSTRAINT] = 1;

    StatusCode status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	filterDeleted(&m_result);

	char* constraint = getFromResultStruct(&m_result,dcs_tname[ACCESS_CONSTRAINT], dcs_aname[ACCESS_CONSTRAINT]);

	m_constraint_node = new StringNodeImpl(NULL);
	((StringNodeImpl*)m_constraint_node)->AddString(constraint);

	for(int i = 1; i < m_result.row_count; i++)
	{
		constraint += MAX_DATA_SIZE;
		((StringNodeImpl*)m_constraint_node)->AddString(constraint);
	}

	return m_constraint_node;
}



ISetNode* SessionImpl::GetDomain(IZoneNode* zone)
{
	return m_domainNode;
}
ISetNode* SessionImpl::GetResource(IZoneNode* zone)
{
	if(zone)
		if(zone->CountChildren() == 0)
			OpenTree(zone, 1, 1);
	else
		return (ISetNode*)(zone->GetChild("resources"));
	
	return (ISetNode*)(m_HomeZone->GetChild("resources"));
}
ICollectionNode* SessionImpl::GetRoot(IZoneNode* zone)
{
	return m_root;
}

ICollectionNode* SessionImpl::GetLocalRoot()
{
	return m_localRoot;
}

ICollectionNode* SessionImpl::GetHome(IZoneNode* zone)
{
	return m_home;
}

IZoneNode* SessionImpl::GetHomeZone()
{
	return m_HomeZone;
}


IZoneNode* SessionImpl::GetCurrentZone(INode* target)
{
	char buf[1024];
	int i;

	INode* blah;

	switch(target->GetType())
	{
	case SOB_COLLECTION:
		sprintf(buf, "%s",target->GetPath());
		for(i = 1; i < 1024; i++)
		{
			if(buf[i] == '/')
			{
				buf[i] = '\0';
				break;
			}
		}
		return (IZoneNode*)m_MCAT->GetChild(buf);
		break;
	case SOB_DATASET:
		return GetCurrentZone(target->GetParent());
	case SOB_RESOURCE:
		blah = target->GetParent();
		blah = target->GetParent();
		return (IZoneNode*)blah;
	default:
		return NULL;
	}
}



}//end namespace




