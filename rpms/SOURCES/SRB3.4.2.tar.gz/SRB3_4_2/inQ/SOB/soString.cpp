#include "soString.h"

namespace SRB
{

StringNodeImpl::StringNodeImpl(INode* parent)
{
	m_parent = parent;
	m_children = NULL;
	m_strings = NULL;
}

StringNodeImpl::~StringNodeImpl()
{

	if(m_children)
	{
		std::vector<INode*>::iterator i = m_children->begin();

		for(i; i != m_children->end(); i++)
		{
			delete *i;	//calls destructor on all children
		}

		m_children->clear();
	}
	if(m_strings)
	{
		std::vector<char*>::iterator j = m_strings->begin();

		for(j; j != m_strings->end(); j++)
		{
			free(*j);	//calls destructor on all children
		}

		m_strings->clear();
	}
}


const char* StringNodeImpl::GetPath()
{
	int size;
	
	if(NULL == m_path)
	{
		size = strlen(m_parent->GetPath());

		size += strlen(m_name);

		m_path = new char[++size];

		sprintf(m_path, "%s/%s", m_parent->GetPath(), m_name);
	}

	return m_path;
}

//inline
INode* StringNodeImpl::GetChild(int pos)
{
	if(m_children && pos < m_children->size() && pos >= 0)
			return m_children->at(pos);
	
	return NULL;
}

//inline
const char* StringNodeImpl::GetString(int pos)
{
	if(m_strings)
	{
		//does this return NULL for pos outside of bounds?
		return m_strings->at(pos);
	};
	
	return NULL;
}

//inline
int StringNodeImpl::CountChildren()
{
	if(m_children)
	{
		//does this return int?
		return m_children->size();
	}

	return 0;
}

//inline
int StringNodeImpl::CountStrings()
{
	if(m_strings)
	{
		//does this return int?
		return m_strings->size();
	}

	return 0;
}

int StringNodeImpl::CountHeightFromRoot()
{
	if(NULL == m_parent)
	{
		return 0;
	}

	return m_parent->CountHeightFromRoot() + 1;
}

/*
this function takes a char string. if the string begins
with a / it will perceive it as a relative path otherwise it will
take take the entire path as a name. trailing / may be
present or omitted.
*/
INode* StringNodeImpl::GetChild(const char* name)
{
	if((NULL == name)||(NULL == m_children))
		return NULL;

	INode* child;
	char *szname;
	if('/' == name[0])
	{
		szname = strdup(name);

		int len = strlen(name);

		for(int j = 1; j < len; j++)
		{
			if('/' == szname[j])
			{
				szname[j] = 0;
				break;
			}
		}

		child = GetChild(szname);

		if(NULL == child)
		{
			free(szname);
			return NULL;
		}

		if(j < len)
		{
			child = child->GetChild(&szname[j+1]);
		}

		free(szname);

		return child;
	}else
	{
		for(int i = 0; i < m_children->size(); i++)
		{
			child = m_children->at(i);
			if(0 == strcmp(name, child->GetName()))
			{
				return child;
			}
		}
		
		return NULL;
	}

	//should never reach here
	return NULL;
}
StatusCode StringNodeImpl::GetChild(const char* name, INode** result)
{
	if(NULL == name)
		return NULL;

	if(NULL == result)
		return NULL;

	INode* child;
	char *szname;

	StatusCode status;

	if('/' == name[0])
	{
		szname = strdup(name);

		int len = strlen(name);

		for(int j = 1; j < len; j++)
		{
			if('/' == szname[j])
			{
				szname[j] = 0;
				break;
			}
		}

		status = GetChild(&szname[1], &child);

		if(!status.isOk())
		{
			free(szname);
			*result = child;
			return status;
		}

		if(j < len)
		{
			status = child->GetChild(&szname[j+1], &child);
		}

		free(szname);
		*result = child;
		return status;

	}else
	{
		if(m_children)
		{
			for(int i = 0; i < m_children->size(); i++)
			{
				child = m_children->at(i);
				if(0 == strcmp(name, child->GetName()))
				{
					*result = child;
					return SRB_OK;
				}
			}
		}else
		{
			*result = this;
			return SRB_ERROR_NOT_FILLED;
		}
	}

	//should never reach here
	*result = NULL;
	return SRB_ERROR;
}

StatusCode StringNodeImpl::AddString(const char* string)
{
	if(NULL == string)
		return SRB_ERROR_INVALID_PARAMETER;

	if(NULL == m_strings)
	{
		m_strings = new std::vector<char*>;
	}
	
	m_strings->push_back(strdup(string));
	return SRB_OK;
}

}//end namespace