#include "soContainer.h"

extern "C"
{
//char * getFromResultStruct(mdasC_sql_result_struct *result, char *tab_name, char *att_name);
extern char dcs_tname[MAX_DCS_STRUCTS][MAX_TOKEN];
extern char dcs_aname[MAX_DCS_STRUCTS][MAX_TOKEN]; 
}

namespace SRB
{

ContainerNodeImpl::ContainerNodeImpl(INode* parent, const char* container_path)
{
	if(container_path)
		m_container_path = strdup(container_path);
	else
		m_container_path = strdup("");

	m_name = NULL;
	m_path = NULL;
	m_parent = parent;
}

ContainerNodeImpl::~ContainerNodeImpl()
{
	free(m_container_path);
	
	if(m_name)
		free(m_name);

	if(m_path)
		free(m_path);
}

const char* ContainerNodeImpl::GetName()
{
	if(m_name)
		return m_name;

	int len = strlen(m_container_path);

	for(int i = len - 1; i >= 0; i--)
	{
		if('/' == m_container_path[i])
			break;
	}

	char* name = &m_container_path[i+1];

	len = strlen(name);

	m_name = (char*)calloc(len + 1, sizeof(char));
	m_name = strdup(name);

	return m_name;
}

const char* ContainerNodeImpl::GetContainerPath()
{
	return m_container_path;
}

const char* ContainerNodeImpl::GetPath()
{
	int size;
	
	if(NULL == m_path)
	{
		size = strlen(m_parent->GetPath());
		size += strlen(GetName());
		size += 2;	//include slash divider, null characters
		m_path = (char*)calloc(size, sizeof(char));

		//later replace with better implementation
		sprintf(m_path, "%s/%s", m_parent->GetPath(), GetName());
	}

	return m_path;
}

int ContainerNodeImpl::CountHeightFromRoot()
{
	if(NULL == m_parent)
	{
		return 0;
	}

	return m_parent->CountHeightFromRoot() + 1;
}

StatusCode ContainerNodeImpl::GetChild(const char* name, INode** result)
{
	if((NULL == result)||(NULL == name))
		return SRB_ERROR_INVALID_PARAMETER;

	*result = NULL;

	return SRB_ERROR_NOT_FILLED;
}

}//end namespace