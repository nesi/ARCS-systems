#ifndef __SRB_OBJECT_MCAT_OPERATOR_H__
#define __SRB_OBJECT_MCAT_OPERATOR_H__
#include "soGlobals.h"
#include "clConnectExtern.h"

#include "soNode.h"
#include "soMCAT.h"
#include "scommands.h"

namespace SRB
{

class MCATOperatorImpl : public IMCATOperator
{
public:
	StatusCode Bind(INode* node) { return SRB_ERROR_TYPE_NOT_SUPPORTED;};
	int GetType() { return SOB_OP_MCAT; };

	StatusCode GetChildren(MCATNodeImpl* target, unsigned int mask = SOB_ALL);
	MCATOperatorImpl(ISession* session);
	 ~MCATOperatorImpl();

	 StatusCode GetLocalCollections(MCATNodeImpl* target);

StatusCode FindZone4User(const char* domain, const char* user, char* zone_buf);

private:
	MCATOperatorImpl();
	MCATOperatorImpl(const MCATOperatorImpl& source);
	MCATOperatorImpl& operator =(const MCATOperatorImpl& source);

	StatusCode GetZones(MCATNodeImpl* target);

	void ClearMCATScratch();
	mdasC_sql_result_struct m_result;
	char m_qval[MAX_DCS_NUM][MAX_TOKEN];
	int m_selval[MAX_DCS_NUM];
	srbConn* m_conn;
	ISession* m_session;
	IMCATNode* m_MCAT;
};
}//end namespace
#endif __SRB_OBJECT_MCAT_OPERATOR_H__









