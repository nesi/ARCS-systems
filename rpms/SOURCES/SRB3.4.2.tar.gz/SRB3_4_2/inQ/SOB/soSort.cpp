#if ENABLE_SORTING
#include "soSort.h"
#include "soMetadata.h"

extern "C"
{
char * getFromResultStruct(mdasC_sql_result_struct *result, char *tab_name, char *att_name);
extern char dcs_tname[MAX_DCS_STRUCTS][MAX_TOKEN];
extern char dcs_aname[MAX_DCS_STRUCTS][MAX_TOKEN]; 
}

namespace SRB
{
//used to create child nodes
SortNodeImpl::SortNodeImpl(ISortNode* parent, const char* attribute, const char* value)
{
	m_parent = parent;
	m_children = new std::vector<INode*>;
	m_name = NULL;
	m_attribute = strdup(attribute);
	m_value = strdup(value);
}

SortNodeImpl::SortNodeImpl()
{
	m_parent = NULL;
	m_children = new std::vector<INode*>;
	m_name = "";
	m_attribute = "";
	m_value = "";
}

SortNodeImpl::~SortNodeImpl()
{
	delete m_children;
	delete m_name;
}

const char* SortNodeImpl::GetName()
{
	//copy from metadatanodeimpl
}

const char* SortNodeImpl::GetPath()
{
	//copy from metadatanodeimpl
}

//inline
int SortNodeImpl::CountChildren()
{
	if(m_children)
	{
		//does this return int?
		return m_children->size();
	}

	return 0;
}

int SortNodeImpl::CountHeightFromRoot()
{
	if(NULL == m_parent)
	{
		return 0;
	}

	return m_parent->CountHeightFromRoot() + 1;
}

//inline
INode* SortNodeImpl::GetChild(int pos)
{
	if(m_children)
	{
		//does this return NULL for pos outside of bounds?
		return m_children->at(pos);
	};
	
	return NULL;
}


void SortNodeImpl::AddNode(INode* target)
{
	if(NULL == m_children)
	{
		m_children = new std::vector<INode*>;
	}	
	m_children->push_back(target);
}

void SortNodeImpl::AddNodeFront(INode* target)
{
	if(NULL == m_children)
	{
		m_children = new std::vector<INode*>;
	}	
	m_children->insert(m_children->begin(), target);
}

void SortNodeImpl::RemoveNode(INode* target)
{
	if((NULL == m_children)||(NULL == target))
		return;

	std::vector<INode*>::iterator i = m_children->begin();

	for(i; i != m_children->end(); i++)
	{
		if(*i == target)
		{
			m_children->erase(i);
			break;
		}
	}
}

void SortNodeImpl::MoveNode(INode* ThisNodeComes, INode* BeforeThisOne)
{
	if((NULL == m_children)||(NULL == ThisNodeComes)||(NULL == BeforeThisOne))
		return;

	std::vector<INode*>::iterator i = m_children->begin();

	for(i; i != m_children->end(); i++)
	{
		if(*i == ThisNodeComes)
		{
			m_children->erase(i);
			break;
		}
	}

	i = m_children->begin();

	for(i; i != m_children->end(); i++)
	{
		if(*i == BeforeThisOne)
		{
			m_children->insert(i, ThisNodeComes);
			break;
		}
	}
}

INode* SortNodeImpl::GetPrevious(INode* child, bool recursive)
{
	return NULL;
}

INode* SortNodeImpl::GetChild(const char* name)
{
	if((NULL == name)||(NULL == m_children))
		return NULL;

	INode* child;
	char *szname;
	if('/' == name[0])
	{
		szname = strdup(name);

		int len = strlen(name);

		for(int j = 1; j < len; j++)
		{
			if('/' == szname[j])
			{
				szname[j] = 0;
				break;
			}
		}

		child = GetChild(szname);

		if(NULL == child)
		{
			free(szname);
			return NULL;
		}

		if(j < len)
		{
			child = child->GetChild(&szname[j+1]);
		}

		free(szname);

		return child;
	}else
	{
		for(int i = 0; i < m_children->size(); i++)
		{
			child = m_children->at(i);
			if(0 == strcmp(name, child->GetName()))
			{
				return child;
			}
		}
		
		return NULL;
	}

	//should never reach here
	return NULL;
}

INode* SortNodeImpl::GetNext(INode* child, bool recursive)
{
	return NULL;
}

}//end namespace
#endif