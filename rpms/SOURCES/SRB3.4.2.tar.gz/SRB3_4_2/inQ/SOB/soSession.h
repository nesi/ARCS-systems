#ifndef __SRB_OBJECT_SESSION_H__
#define __SRB_OBJECT_SESSION_H__
#include "soGlobals.h"
#include "soNode.h"
#include "clConnectExtern.h"
#include "soCollectionOperator.h"
#include "soDatasetOperator.h"
#include "soResourceOperator.h"
#include "soQueryOperator2.h"
#include "soDomainOperator.h"
#include "soContainerOperator.h"
#include "soZoneOperator.h"

namespace SRB
{
class SessionImpl : public ISession
{
public:
	SessionImpl();
	 ~SessionImpl();

//	StatusCode Root();

	StatusCode Clone(ISession* target);
	StatusCode Init(const char* user, const char* user_home, const char* host, const char* domain, const char* domain_root, const char* auth_scheme, const char* port, const char* password);


	IOperator* GetOperator(int type);	//returns operator associated with node;
										//important for nested queries, etc.
	IStringNode* GetAccessConstraints();
	StatusCode Connect();
	StatusCode Disconnect();
	bool isConnected();
	StatusCode ChangePassword(const char* new_password);
	StatusCode OpenTree(INode* parent, int levels, bool clear, unsigned int mask = SOB_ALL );
	StatusCode CloseTree(INode* parent);


	ISetNode* GetDomain(IZoneNode* zone);
	ISetNode* GetResource(IZoneNode* zone);
	ICollectionNode* GetRoot(IZoneNode* zone);
	ICollectionNode* GetLocalRoot();
	ICollectionNode* GetHome(IZoneNode* zone);

	IZoneNode* GetHomeZone();
	IZoneNode* GetCurrentZone(INode* target);
//	void SetCurrentZone(IZoneNode* zone);
	



	ICollectionNode* GetUserRootCol();
	ICollectionNode* GetUserHomeCol();
	IZoneNode* GetUserZone();

	IMCATNode* GetMCAT();
	const char* GetUserHost()	;
	const char* GetUserAuthScheme() { return m_auth;};
	const char* GetUserPortValue() { return m_port;};
	const char* GetName() { return m_user;};
	void* GetConn() { return m_conn;};
	void* CloneConn();
	

	virtual const char* GetUserDomain();
	virtual ICollectionNode* GetUserHome();



private:
	void Clean();
	SessionImpl(const SessionImpl& source);
	SessionImpl& operator =(const SessionImpl& source);
	srbConn* Clone();
	IZoneNode* m_HomeZone;
	IMCATNode* m_MCAT;

	StatusCode Replicate_Recursive_Impl(ICollectionNode* target);
	char* m_user;
	char* m_host;
	char* m_domain;
	ISetNode* m_domainNode;
	ISetNode* m_ResourceNode;
	char* m_auth;
	char* m_port;
	char* m_password;
	char* m_resource;
	char* m_user_home;

	bool m_bisConnected;
	bool m_bMaster;

	srbConn* m_conn;
	ICollectionNode* m_root;
	ICollectionNode* m_localRoot;
	ICollectionNode* m_home;

	CollectionOperatorImpl* m_CollectionOp;
	DatasetOperatorImpl* m_datasetOp;
	ResourceOperatorImpl* m_ResourceOp;
	QueryOperator2Impl* m_queryOp;
	DomainOperatorImpl* m_domainOp;
	ContainerOperatorImpl* m_containerOp;
	ZoneOperatorImpl* m_ZoneOp;

	//IResourceNode* m_resources;
	std::vector<IOperator*> m_allocations;
	std::vector<INode*> m_allocations2;
	IStringNode* m_constraint_node;
	//IDomainNode* m_domains;
	IZoneNode* m_zones;

	IZoneNode* m_currentZone;


	void ClearMCATScratch();

	mdasC_sql_result_struct m_result;
	char m_qval[MAX_DCS_NUM][MAX_TOKEN];
	int m_selval[MAX_DCS_NUM];
};


}//end namespace
#endif