#include "soCollectionOperator.h"
#include "soCollection.h"
#include "clStubExtern.h"
#include "soDataset.h"
#include "soMetadata.h"
#include "soAccess.h"
#include <dirent.h>
#include "SrbNtUtil.h"

extern "C"
{
extern char ResourceName[MAX_TOKEN];
extern char datatype[MAX_TOKEN];
extern char newpathname[MAX_TOKEN];
extern int bloadMain (srbConn *conn, int catType, int nArgv, srbPathName nameArray[], srbPathName *targName, int flagval);
extern int chmodInColl (srbConn *conn, int catType, char *parColl, int flagval, char *mode, char *userdom);
extern int dataToFileCopy (srbConn *conn, int catType, int flagval, int targType,mdasC_sql_result_struct *dataResult, int srcCopyNum,char *targFile, char *ticketId);
extern long strtoll(const char *nptr, char **endptr, int base);

extern char ContainerName[MAX_TOKEN];
char OrigContainerName[MAX_TOKEN];
extern srb_long_t MaxContSz;	/* max container sz in MB) */ 
extern int optind, opterr, optopt;
extern char srbAuth[];
extern char srbHost[];
extern char mdasCollectionName[];
extern char inCondition[];
extern int iGlbRetriesMax;
extern int RStatus;
extern int bloadMain (srbConn *conn, int catType, int nArgv, srbPathName nameArray[], srbPathName *targName, int flagval);
char defaultReplicaResource[MAX_TOKEN], defaultReplicaPath[MAX_TOKEN];
char datatype[MAX_TOKEN];
extern int unmake_like_str (char *outStr, char *inStr);
extern int parseContainerName (char *inContainerName, char *outContainerName, char *collectionName, char *userName, char *domainName, char *mcatName);
extern char* getmcatNamefromHint (char *mcatNameHint);
}

namespace SRB
{
CollectionOperatorImpl::CollectionOperatorImpl(ISession* session)
{
	m_bytes_received = 0;
	m_bytes_expected = 0;
	m_bIsDownloading = false;

	m_result.result_count = 0;
	m_result.row_count = 0;

	m_conn = (srbConn*)session->GetConn();
	m_session = session;

	INode* m_binding = NULL;
}

//mdownloading is a ptr to a block of memory used by SRB client code
//it is a statically defined block and we don't need to delete it
CollectionOperatorImpl::~CollectionOperatorImpl()
{
}

StatusCode CollectionOperatorImpl::Bind(INode* node) { m_binding = node; return SRB_OK;};

//since we're simulating a resultstruct, we should clear when we're done, not when we start
//delete is differnet, especially since we're simulating a result not actually using one.
//for now we'll create a local struct.
StatusCode CollectionOperatorImpl::Delete(ICollectionNode* target)
{
	if(target == m_session->GetUserHomeCol() || target == m_session->GetUserRootCol())
		return SRB_ERROR;
	
//	static mdasC_sql_result_struct result;

	ClearMCATScratch();

	m_result.result_count = 1;
    m_result.row_count = 1;
	m_result.sqlresult[0].tab_name = dcs_tname[DATA_GRP_NAME];
    m_result.sqlresult[0].att_name = dcs_aname[DATA_GRP_NAME];
	m_result.sqlresult[0].values = (mdasC_handle)target->GetPath();

	StatusCode status = rmColl(m_conn,0,R_FLAG,&m_result,-1, 0);

	m_result.result_count = 0;
	m_result.row_count = 0;

	if(!status.isOk())
		return status;

	CollectionNodeImpl* parent = (CollectionNodeImpl*)target->GetParent();

	if(NULL == parent)
		return SRB_ERROR;

	parent->DeleteChild(target);

	return SRB_OK;
}

//this might not actually work since I do not know the state of renaming collections on the server side
//(the server needs to change the pathnames for all subcollections of the collection)
StatusCode CollectionOperatorImpl::Rename(ICollectionNode* target, const char* name)
{
	if(NULL == target || NULL == name)
		return SRB_ERROR_INVALID_PARAMETER;

	ICollectionNode* parent = (ICollectionNode*)target->GetParent();

	if(NULL == parent)
		return SRB_ERROR_INVALID_PARAMETER;

	const char* szParentPath = parent->GetPath();

	int length = strlen(szParentPath);

	length += strlen(name);

	char* buf = new char[length + 2];	//+1 for / and +1 for NULL

	sprintf(buf, "%s/%s", szParentPath, name);

	StatusCode status = srbModifyCollect(m_conn,0,(char*)target->GetPath(),(char*)buf,"","",D_CHANGE_COLL_NAME);

	delete buf;

	if(status.isOk())
		((CollectionNodeImpl*)target)->SetName(name);

	return status;
}

StatusCode CollectionOperatorImpl::Create(ICollectionNode* target, const char* name, ICollectionNode** result)
{
	if(NULL == target || NULL == name)
		return SRB_ERROR_INVALID_PARAMETER;

	StatusCode status = srbCreateCollect(m_conn, 0, (char*)target->GetPath(), (char*)name);

	ICollectionNode* child;

	if(status.isOk())
	{
		child = new CollectionNodeImpl(target, name);	
		((CollectionNodeImpl*)target)->AddChild(child);
	}

	return status;
}

StatusCode CollectionOperatorImpl::ModifyAccess(IAccessNode* target, const char* permission, bool recursive)
{
	if(NULL == target || NULL == permission)
		return SRB_ERROR_INVALID_PARAMETER;

	IStringNode* constraints = m_session->GetAccessConstraints();

	int count = constraints->CountStrings();

	for(int i = 0; i < count; i++)
	{
		if(0 == strcmp(constraints->GetString(i), permission))
			break;
	}

	if(count == i)
		return SRB_ERROR_INVALID_PARAMETER;

	char* collection = (char*)target->GetParent()->GetPath();
	char* user = (char*)target->GetUser();
	char* domain = (char*)target->GetDomain();
	char* buf;

	StatusCode status;

	int option = 0;

	if(recursive)
		option = R_FLAG;

	int len = 0;

	len += strlen(user);
	len += strlen(domain);
	len += 2;

	buf = (char*)calloc(len, sizeof(char));

	sprintf(buf, "%s@%s", user, domain);
	status = chmodInColl(m_conn, 0, collection, option, (char*)permission, buf);

	free(buf);
	
	if(status.isOk())
	{
		MyMod(permission, target, recursive);
	}

	return status;

}

void CollectionOperatorImpl::MyMod(const char* permission, IAccessNode* target, bool recursive)
{
	INode* parent = target->GetParent();
	if(0 == strcmp("null", permission))
	{
		if(recursive)
		{
			char* szDomain = strdup(target->GetDomain());
			char* szUser = strdup(target->GetUser());
			FooD(parent, szDomain, szUser);
			free(szDomain);
			free(szUser);
		}else
		{
			switch(parent->GetType())
			{
			case SOB_COLLECTION:
				((CollectionNodeImpl*)parent)->DeleteChild(target);
				break;
			case SOB_DATASET:
				((DatasetNodeImpl*)parent)->DeleteChild(target);
				break;
			}
		}
	}else
	{
		if(recursive)
		{
			char* szDomain = strdup(target->GetDomain());
			char* szUser = strdup(target->GetUser());
			FooM(parent, szDomain, szUser, permission);
			free(szDomain);
			free(szUser);
		}else
			((AccessNodeImpl*)target)->SetPermission(permission);
	}
}


void CollectionOperatorImpl::FooD(INode* node, const char* szDomain, const char* szUser)
{
	if(node->isOpen())
	{
		INode* child;
		int i = 0;
		child = node->GetChild(0);
		int type = node->GetType();

		IAccessNode* access;

		do
		{
			if(child->GetType() == SOB_ACCESS)
			{
				access = (IAccessNode*)child;

				if(0 == strcmp(access->GetUser(), szUser))
				{
					if(0 == strcmp(access->GetDomain(), szDomain))
					{
						switch(type)
						{
						case SOB_DATASET:
							((DatasetNodeImpl*)node)->DeleteChild(child);
							break;
						case SOB_COLLECTION:
							((CollectionNodeImpl*)node)->DeleteChild(child);
							break;
						}
						//ith child deleted, do not increment i
					}
				}else
					i++;
			}else
				i++;

			child = node->GetChild(i);
		} while(NULL != child);

		
		//if this is a collection we must examine its children also
		if(type == SOB_COLLECTION)
		{
			int count = node->CountChildren();

			for(int i = 0; i < count; i++)
			{
				INode* child = node->GetChild(i);

				type = child->GetType();

				if(SOB_COLLECTION == type || SOB_DATASET == type)
				{
					FooD(child, szDomain, szUser);
				}
			}
		}
	}
}

void CollectionOperatorImpl::FooM(INode* node, const char* szDomain, const char* szUser, const char* new_permission)
{
	if(node->isOpen())
	{
		int type = node->GetType();
		int count = node->CountChildren();

		INode* child;
		IAccessNode* access;

		for(int i = 0; i < count; i++)
		{
			child = node->GetChild(i);

			if(child->GetType() == SOB_ACCESS)
			{
				access = (IAccessNode*)child;
				if(0 == strcmp(szDomain, access->GetDomain()))
					if(0 == strcmp(szUser, access->GetUser()))
					{
						((AccessNodeImpl*)child)->SetPermission(new_permission);
						break;
					}
			}
		}

		if(i == count)
		{
			//this node did not previously have the permission.
			//however, since a recursive modify will add the permission to the dataset,
			//we must create a new access node for this node
			switch(type)
			{
			case SOB_DATASET:
				((DatasetNodeImpl*)node)->AddChild(new AccessNodeImpl(node, NULL, szDomain, szUser, new_permission));
				break;
			case SOB_COLLECTION:
				((CollectionNodeImpl*)node)->AddChild(new AccessNodeImpl(node, NULL, szDomain, szUser, new_permission));
				break;
			}

		}

		//if this is a collection we must examine its children also
		if(type == SOB_COLLECTION)
		{
			count = node->CountChildren();

			for(int i = 0; i < count; i++)
			{
				child = node->GetChild(i);

				type = child->GetType();

				if(SOB_COLLECTION == type || SOB_DATASET == type)
				{
					FooM(child, szDomain, szUser, new_permission);
				}
			}
		}
	}
}

//we assume that "null" means remove the access
StatusCode CollectionOperatorImpl::SetAccess(ICollectionNode* target, IUserNode* owner, const char* permission, bool recursive)
{
	if(NULL == target || NULL == owner || NULL == permission)
		return SRB_ERROR_INVALID_PARAMETER;

	int option = 0;

	int retraction_type;
	char* sz;

	if(0 == strcmp("null", permission))
	{
		retraction_type = D_DELETE_COLL_ACCS;
		sz = "";
	}
	else
	{
		retraction_type = D_INSERT_COLL_ACCS;
		sz = (char*)permission;
	}

	StatusCode status;

	if(!recursive)
		status = srbModifyCollect(m_conn, 0, (char*)target->GetPath(), (char*)owner->GetName(), (char*)owner->GetParent()->GetName(), (char*)permission, retraction_type);
	else
	{
		status = srbModifyCollect(m_conn, 0, (char*)target->GetPath(), (char*)owner->GetName(), (char*)owner->GetParent()->GetName(), (char*)permission, retraction_type);
		if(status.isOk())
		{
			status = chmodInColl(m_conn, 0, (char*)target->GetPath(), R_FLAG, (char*)permission, (char*)owner->GetPath());
		}

	}

	if(status.isOk())
	{
		SetAccessNodes(target, owner, permission, recursive, retraction_type);
	}

	return status;
}




StatusCode CollectionOperatorImpl::ModifyCollectionRecursively(ICollectionNode* target, IUserNode* owner, const char* permission)
{
	return SRB_OK;
}


void CollectionOperatorImpl::SetAccessNodes(INode* target, IUserNode* owner, const char* permission, bool recursive, int retraction_type)
{
	int count = target->CountChildren();
	INode* child;

	if(target->isOpen())
	{
		//first account for target
		for(int i = 0; i < count; i++)
		{
			child = target->GetChild(i);
			if(SOB_ACCESS == child->GetType())
			{
				if(0 == strcmp(owner->GetName(), ((IAccessNode*)child)->GetUser()))
				{
					((AccessNodeImpl*)child)->SetPermission(permission);
					break;
				}
			}
		}

		if(i == count)
		{
			//a new user was added
			if(target->GetType() == SOB_COLLECTION)
				((CollectionNodeImpl*)target)->AddChild(new AccessNodeImpl(target, NULL, owner->GetParent()->GetName(), owner->GetName(), permission));
			else
				((DatasetNodeImpl*)target)->AddChild(new AccessNodeImpl(target, NULL, owner->GetParent()->GetName(), owner->GetName(), permission));

		}

		//now account for children, if need be
		int type;
		if(recursive)
		{
			for(int j = 0; j < target->CountChildren(); j++)
			{
				child = target->GetChild(j);
				type = child->GetType();
				if(type == SOB_COLLECTION || type == SOB_DATASET)
					SetAccessNodes(child, owner, permission, recursive, retraction_type);
			}
		}
	}
}


StatusCode CollectionOperatorImpl::AddMeta(ICollectionNode* target, const char* attribute, IMetadataNode** result)
{
	StatusCode id = srbModifyCollect(m_conn, 0, (char*)target->GetPath(), "0", (char*)attribute, "", C_INSERT_USER_DEFINED_COLL_STRING_META_DATA);

	if(!id.isOk())
		return id;

	CollectionNodeImpl* collection = (CollectionNodeImpl*)target;

	MetadataNodeImpl* baby = new MetadataNodeImpl(target, attribute, SOB_MD_EQUAL, NULL);
	baby->SetID(id.GetCode());

	collection->AddChild(baby);

	if(NULL != result)
	{
		*result = baby;
	}

	return SRB_OK;
}	

StatusCode CollectionOperatorImpl::ModifyMeta(IMetadataNode* target, const char* value)
{
	ICollectionNode* parent = (ICollectionNode*)target->GetParent();

	static char buf[256];

	sprintf(buf, "1@%d", ((MetadataNodeImpl*)target)->GetID());

	StatusCode status = srbModifyCollect(m_conn, 0, (char*)parent->GetPath(), buf, (char*)value, "", C_CHANGE_USER_DEFINED_COLL_STRING_META_DATA);

	if(status.isOk())
	{
		((MetadataNodeImpl*)target)->SetValue(value);
	}

	return status;
};

StatusCode CollectionOperatorImpl::DeleteMeta(IMetadataNode* target)
{
	static char buf[10];
	sprintf(buf, "%d", ((MetadataNodeImpl*)target)->GetID());

	CollectionNodeImpl* parent = (CollectionNodeImpl*)target->GetParent();
	StatusCode status = srbModifyCollect(m_conn, 0, (char*)parent->GetPath(),buf, "", "", C_DELETE_USER_DEFINED_COLL_STRING_META_DATA);

	if(status.isOk())
	{
		parent->DeleteChild(target);
	}

	return status;
};

StatusCode CollectionOperatorImpl::GetChildren(CollectionNodeImpl* target, unsigned int mask)
{
	if(NULL == target)
		return SRB_ERROR_INVALID_PARAMETER;

	target->Clear();

	StatusCode status;
	
	unsigned int success = SOB_ALL ^ SOB_ACCESS ^ SOB_METADATA ^ SOB_COLLECTION ^ SOB_DATASET;

	if(SOB_ACCESS & mask)
	{
		status = GetAccess(target);
		if(status.isOk())
		{
			success |= SOB_ACCESS;
		}
		else
		{
			target->SetOpen(success);
			return status;
		}
	}
	
	if(SOB_METADATA & mask)
	{
		status = GetMetadata(target);
		if(status.isOk())
		{
			success |= SOB_METADATA;
		}
		else
		{
			target->SetOpen(success);
			return status;
		}
	}

	if(SOB_COLLECTION & mask)
	{
		status = GetChildCollections(target);
		if(status.isOk())
		{
			success |= SOB_COLLECTION;
		}
		else
		{
			target->SetOpen(success);
			return status;
		}
	}

	if(SOB_DATASET & mask)
	{
		status = GetChildDatasets(target);
		if(status.isOk())
		{
			success |= SOB_DATASET;
		}
		else
		{
			target->SetOpen(success);
			return status;
		}
	}

	target->SetOpen(success);
	return status;
}

StatusCode CollectionOperatorImpl::GetAccess(CollectionNodeImpl* target)
{
	ClearMCATScratch();

	sprintf(m_qval[ACCESS_GROUP_NAME], " = '%s'", target->GetPath());

	m_selval[USER_NAME] = 1;
	m_selval[DOMAIN_DESC] = 1;
	m_selval[GROUP_ACCESS_CONSTRAINT] = 1;

	IZoneNode* myzone = m_session->GetCurrentZone(target);

	StatusCode status;

	if(myzone)
	 status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)myzone->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);
	else
	status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
	{
		if(-3005 == status)
		{
			status = SRB_OK;
		}
		return status;
	}

	if(0 == m_result.row_count)
		return SRB_OK;

	filterDeleted(&m_result);

	IAccessNode* access_node;
	

	char *user, *domain, *constraint;
	
	user = getFromResultStruct(&m_result, dcs_tname[USER_NAME], dcs_aname[USER_NAME]);
	domain = getFromResultStruct(&m_result, dcs_tname[DOMAIN_DESC], dcs_aname[DOMAIN_DESC]);
	constraint = getFromResultStruct(&m_result, dcs_tname[GROUP_ACCESS_CONSTRAINT], dcs_aname[GROUP_ACCESS_CONSTRAINT]);
	access_node = new AccessNodeImpl(target, NULL, domain, user, constraint);
	target->AddChild(access_node);

	for(int i = 1; i < m_result.row_count; i++)
	{
		user += MAX_DATA_SIZE;
		domain += MAX_DATA_SIZE;
		constraint += MAX_DATA_SIZE;
		access_node = new AccessNodeImpl(target, NULL, domain, user, constraint);
		target->AddChild(access_node);
	}

	//while(m_result.continuation_index >= 0)
	//{
		//implement later
	//}

	return SRB_OK;
}

void CollectionOperatorImpl::ClearMCATScratch()
{
    clearSqlResult(&m_result);

    for(int i = 0; i < MAX_DCS_NUM; i++)
	{
        sprintf(m_qval[i],"");
        m_selval[i] = 0;
    }
}

StatusCode CollectionOperatorImpl::GetMetadata(CollectionNodeImpl* target)
{
	ClearMCATScratch();

	sprintf(m_qval[DATA_GRP_NAME], " = '%s'", target->GetPath());
	sprintf(m_qval[METADATA_NUM_COLL], " >= 0");

	m_selval[METADATA_NUM_COLL] = 1;
	m_selval[UDSMD_COLL0] = 1;
	m_selval[UDSMD_COLL1] = 1;


	StatusCode status;
	IZoneNode* myzone = m_session->GetCurrentZone(target);
	if(myzone)
		status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)myzone->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);
	else
		status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
	{
		if(-3005 == status)
		{
			status = SRB_OK;
		}
		return status;
	}

	filterDeleted(&m_result);

	IMetadataNode* meta;

	for(int i = 0; i < m_result.row_count; i++)
	{
		meta = new MetadataNodeImpl(target, &m_result, i);
		
		target->AddChild(meta);
	}

	//while(m_result.continuation_index >= 0)
	//{
		//implement later
	//}

	return SRB_OK;
}

StatusCode CollectionOperatorImpl::GetChildCollections(CollectionNodeImpl* target)
{
	ClearMCATScratch();

    m_selval[DATA_GRP_NAME] = 1;
    sprintf(m_qval[PARENT_COLLECTION_NAME]," = '%s'", target->GetPath());

    //StatusCode status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);
	StatusCode status;
	IZoneNode* myzone = m_session->GetCurrentZone(target);
	if(myzone)
		status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)myzone->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);
	else
		status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
		if(-3005 == status)
			return SRB_OK;
		else
			return status;

	filterDeleted(&m_result);

	char *original, *szptr;

	int len;

	while(true)
	{
		original = getFromResultStruct(&m_result,dcs_tname[DATA_GRP_NAME], dcs_aname[DATA_GRP_NAME]);

		for(int i = 0; i < m_result.row_count; i++)
		{
			szptr = original;

			len = strlen(szptr);

			for(int j = len - 1; j >= 0; j--)
				if('/' == szptr[j])
				{
					szptr = &szptr[j+1];
					break;
				}

			target->AddChild(new CollectionNodeImpl(target, szptr));

			original += MAX_DATA_SIZE;
		}

		if(m_result.continuation_index < 0)
			break;

		status = srbGetMoreRows(m_conn, 0, m_result.continuation_index, &m_result, MAX_ROWS);

		if(-3005 == status)
			return SRB_OK;

		if(0 != status)
			return SRB_ERROR;
	}

	return SRB_OK;
}

// by default GetPath returns the path of the node with no trailing slash
// this is because the trailing slash must be omitted for collections and
// present for datasets. 
StatusCode CollectionOperatorImpl::GetChildDatasets(CollectionNodeImpl* target)
{
	ClearMCATScratch();

    m_selval[DATA_NAME] = 1;
    m_selval[DATA_GRP_NAME] = 1;
    m_selval[SIZE] = 1;
    m_selval[DATA_TYP_NAME] = 1;
	m_selval[DATA_OWNER] = 1;
	m_selval[REPL_TIMESTAMP] = 1;
	m_selval[DATA_REPL_ENUM] = 1;
	m_selval[PHY_RSRC_NAME] = 1;
	m_selval[CONTAINER_NAME] = 1;
	m_selval[DATA_COMMENTS] = 1;

    sprintf(m_qval[DATA_GRP_NAME]," = '%s'", target->GetPath());

	StatusCode status;
	IZoneNode* myzone = m_session->GetCurrentZone(target);
	if(myzone)
		status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)myzone->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);
	else
		status = srbGetDataDirInfo(m_conn, 0, m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
		if(-3005 == status)
			return SRB_OK;
		else
			return status;

	filterDeleted(&m_result);

	if(0 == m_result.row_count)
		return SRB_OK;

	while(true)
	{
		char* name = getFromResultStruct(&m_result, dcs_tname[DATA_NAME], dcs_aname[DATA_NAME]);
		char* size = getFromResultStruct(&m_result, dcs_tname[SIZE], dcs_aname[SIZE]);
		char* ownr = getFromResultStruct(&m_result, dcs_tname[DATA_OWNER], dcs_aname[DATA_OWNER]);
		char* time = getFromResultStruct(&m_result, dcs_tname[REPL_TIMESTAMP], dcs_aname[REPL_TIMESTAMP]);
		char* repl = getFromResultStruct(&m_result, dcs_tname[DATA_REPL_ENUM], dcs_aname[DATA_REPL_ENUM]);
		char* resc = getFromResultStruct(&m_result, dcs_tname[PHY_RSRC_NAME], dcs_aname[PHY_RSRC_NAME]);
		char* cont = getFromResultStruct(&m_result, dcs_tname[CONTAINER_NAME], dcs_aname[CONTAINER_NAME]);
		char* type = getFromResultStruct(&m_result, dcs_tname[DATA_TYP_NAME], dcs_aname[DATA_TYP_NAME]);
		char* cmnt = getFromResultStruct(&m_result, dcs_tname[DATA_COMMENTS], dcs_aname[DATA_COMMENTS]);
	
		for(int i = 0; i < m_result.row_count; i++)
		{
			target->AddChild(new DatasetNodeImpl(target, name, size, ownr, time, repl, "", resc, cont, type, cmnt));

			name += MAX_DATA_SIZE;
			size += MAX_DATA_SIZE;
			ownr += MAX_DATA_SIZE;
			time += MAX_DATA_SIZE;
			repl += MAX_DATA_SIZE;
			resc += MAX_DATA_SIZE;
			cont += MAX_DATA_SIZE;
			type += MAX_DATA_SIZE;
			cmnt += MAX_DATA_SIZE;
		}

		if(m_result.continuation_index < 0)
			break;

		status = srbGetMoreRows(m_conn, 0, m_result.continuation_index, &m_result, MAX_ROWS);

		if(-3005 == status)
			return SRB_OK;

		if(0 != status)
			return SRB_ERROR;
	}

	return SRB_OK;
}


extern "C"
{
extern char srbAuth[];
extern char srbHost[];
extern char mdasCollectionName[];
extern char inCondition[];
 
extern int iGlbRetriesMax;
extern int RStatus;

int  nbytes, wbytes, in_fd;
}

StatusCode CollectionOperatorImpl::Download(INode* target, const char* local_path)
{
	if(NULL == local_path)
		return SRB_ERROR_INVALID_PARAMETER;

	if(SOB_COLLECTION != target->GetType())
		return SRB_ERROR_INVALID_PARAMETER;

	if(m_bIsDownloading)
		return SRB_ERROR;

	m_bIsDownloading = true;

	SRB::ICollectionNode* target_collection = (SRB::ICollectionNode*)target;

	int repl = 0;

	if(SOB_DATASET == target->GetType())
		repl = atoi(((IDatasetNode*)target)->GetReplicationIndex());

	srbConn* copyconn = (srbConn*)m_session->CloneConn();


	char sanitized_path[MAX_PATH];

	int len = strlen(local_path);



	if(local_path[len-1] == '\\')
		len--;

	strncpy(sanitized_path, local_path, len);
	sanitized_path[len] = '\0';

	m_bytes_received = 0;
	m_bytes_expected = 0;

    int status = DownloadImpl(copyconn, sanitized_path, (char*)(target->GetPath()), repl, &m_bytes_received, &m_bytes_expected);

	clFinish(copyconn);
	
	m_downloading[0] = '\0';

	m_bIsDownloading = false;

	m_bytes_received = 0;
	m_bytes_expected = 0;

    return status;
}

int CollectionOperatorImpl::GetProgress(char** name)
{
	if(0 == m_bytes_expected)
	{
		if(name)
			*name = NULL;

		return 0;
	}

	if(!m_bIsDownloading)
	{
		if(name)
			*name = NULL;
		return -1;
	}

	//this is intensive, but more accurate - need to make a #define for platform specific long ints
	//this way we can mult an int by 100 and store it in a long int instead of a double (make sure long
	//int or _i64 or whatever is larger than int (32).
	//(int*100)/int is probably fastest way and still accurate (no 106%! =))
	double retval = m_bytes_received;
	retval = (retval / m_bytes_expected) * 100;

	if(NULL != name)
	{
		if(retval)
			*name = m_downloading;
		else
			*name = NULL;
	}

	return retval;	
}


//As with datasetoperator and files, directories are considered as collections without metadata and
//specialaccess right information.
StatusCode CollectionOperatorImpl::Upload(INode* target, const char* local_path, unsigned int overwrite, INode** result)
{
	if(SOB_COLLECTION != target->GetType())
		return SRB_ERROR_INVALID_PARAMETER;

	if(NULL == local_path)
		return SRB_ERROR_INVALID_PARAMETER;

	char* szptr = strdup(local_path);

	for(int i = 0; i < strlen(szptr); i++)
		if('\\' == szptr[i])
			szptr[i] = '/';
#if 0
	//chkFileName already converts an SRB path to an NT path before it checks.
	//hence it's okay to switch to a regular SRB path (replace \ with /) that dirtocolcopyBC needs (even for local files)
    if(-1 == chkFileName (&myPathName))
		return SRB_ERROR_DOES_NOT_EXIST;
#endif
	m_bIsDownloading = true;

	StatusCode status;

	int nFlag = 0;

	if(overwrite)
		nFlag |= F_FLAG;

	srbConn* copyconn = (srbConn*)m_session->CloneConn();

	if(SOB_CONTAINER == m_binding->GetType())
		status = 1;
	else
		status = UploadImpl(copyconn, szptr, (char*)target->GetPath(), (char*)m_binding->GetName(), false);

	clFinish(copyconn);

	m_downloading[0] = '\0';

	m_bIsDownloading = false;

	free(szptr);

	SRB::ICollectionNode* child;

	int len = strlen(local_path);

	const char* name = NULL;

	for(i = len - 1; i != 0; i--)
	{
		if('\\' == local_path[i])
		{
			//found the beginning of our name
			name = &local_path[i+1];
			break;
		}
	}

	if(NULL == name)
	{
		name = local_path;
	}

	if(status.isOk())
	{
		INode* old_child = target->GetChild(name);
		if(NULL != old_child)
			((CollectionNodeImpl*)target)->DeleteChild(old_child);


		child = new CollectionNodeImpl(target, name);
		((CollectionNodeImpl*)target)->AddChild(child);
		if(result)
			*result = child;
	}

	m_bytes_received = 0;
	m_bytes_expected = 0;

    return status;
}


StatusCode CollectionOperatorImpl::Copy(ICollectionNode* target, IDatasetNode* data, IDatasetNode** result)
{
    StatusCode status;

	char *path, *name, *size, *type;

	path = strdup(data->GetParent()->GetPath());
	name = strdup(data->GetName());
	size = strdup(data->GetSize());
	type = strdup(data->GetDataType());

    m_result.result_count = 4;
    m_result.row_count = 1;
    m_result.sqlresult[0].tab_name = dcs_tname[DATA_GRP_NAME];
    m_result.sqlresult[0].att_name = dcs_aname[DATA_GRP_NAME];
    m_result.sqlresult[0].values = (mdasC_handle)path;
    m_result.sqlresult[1].tab_name = dcs_tname[DATA_NAME];
    m_result.sqlresult[1].att_name = dcs_aname[DATA_NAME];
    m_result.sqlresult[1].values = (mdasC_handle)name;
    m_result.sqlresult[2].tab_name = dcs_tname[SIZE];
    m_result.sqlresult[2].att_name = dcs_aname[SIZE];
    m_result.sqlresult[2].values = (mdasC_handle)size;
    m_result.sqlresult[3].tab_name = dcs_tname[DATA_TYP_NAME];
    m_result.sqlresult[3].att_name = dcs_aname[DATA_TYP_NAME];
    m_result.sqlresult[3].values = (mdasC_handle)type;

	if(SOB_CONTAINER == m_binding->GetType())
		status = dataToCollCopy(m_conn, 0, c_FLAG, &m_result, atoi(data->GetReplicationIndex()), (char*)target->GetPath(), "", "", (char*)((IContainerNode*)m_binding)->GetContainerPath());
	else
		//resource
		status = dataToCollCopy (m_conn, 0, 0, &m_result, atoi(data->GetReplicationIndex()), (char*)target->GetPath(), (char*)m_binding->GetName(), "", "");

	m_result.result_count = 0;		//since we're faking it, we don't want any subsequent clean to
    m_result.row_count = 0;			//try and delete the dcs_aname, etc which are on the stack, as well
									//as our GetPath();
	free(path);
	free(name);
	free(size);
	free(type);
	
	IDatasetNode* blah;

	if(status.isOk())
	{
		if(target->isOpen())
			status = FillDataset((CollectionNodeImpl*)target, &blah, data->GetName());
	}

	if(result)
		*result = blah;

    return status;
}



StatusCode CollectionOperatorImpl::Copy(ICollectionNode* target, ICollectionNode* data, ICollectionNode** result)
{
	if(target == data)
		return SRB_ERROR_SOURCE_EQUALS_TARGET;

    StatusCode status;

    m_result.result_count = 1;
    m_result.row_count = 1;
    m_result.sqlresult[0].tab_name = dcs_tname[DATA_GRP_NAME];
    m_result.sqlresult[0].att_name = dcs_aname[DATA_GRP_NAME];
    m_result.sqlresult[0].values = (mdasC_handle)  data->GetPath();

	if(SOB_CONTAINER == m_binding->GetType())
	    status = collToCollCopy(m_conn, 0, F_FLAG | c_FLAG, COLLECTION_T, &m_result, (char*)target->GetPath(), "", (char*)((IContainerNode*)m_binding)->GetContainerPath());
	else
	    status = collToCollCopy(m_conn, 0, F_FLAG, COLLECTION_T, &m_result, (char*)target->GetPath(), (char*)m_binding->GetName(), "");

	m_result.result_count = 0;		//since we're faking it, we don't want any subsequent clean to
    m_result.row_count = 0;			//try and delete the dcs_aname, etc which are on the stack, as well
									//as our GetPath();

	ICollectionNode* blah = NULL;

	if(status.isOk())
	{
		if(target->isOpen())
		{
			blah = new CollectionNodeImpl(target, data->GetName());
			((CollectionNodeImpl*)target)->AddChild(blah);
		}
	}

	if(result)
		*result = blah;


    return status;
}

StatusCode CollectionOperatorImpl::Move(ICollectionNode* target, IDatasetNode* data, IDatasetNode** result)
{
	StatusCode status = srbModifyDataset(m_conn, 0, (char*)data->GetName(), (char*)data->GetParent()->GetPath(), "","", (char*)target->GetPath(), "", D_CHANGE_GROUP);

	IDatasetNode* blah = NULL;

	if(status.isOk())
	{
		if(target->isOpen())
		{
			status = FillDataset((CollectionNodeImpl*)target, &blah, data->GetName());
			((CollectionNodeImpl*)data->GetParent())->DeleteChild(data);
		}

	}

	if(result)
		*result = blah;
	
	
	return status;
}

StatusCode CollectionOperatorImpl::Move(ICollectionNode* target, ICollectionNode* data, ICollectionNode** result)
{
	int len = strlen(target->GetPath()) + strlen(data->GetName()) + 2;
	char* szNewPath = new char[len];

	sprintf(szNewPath, "%s/%s", target->GetPath(), data->GetName());

	StatusCode status = srbModifyCollect(m_conn, 0, (char*)data->GetPath(), szNewPath, "", "", D_CHANGE_COLL_NAME);

	ICollectionNode* child;

	if(status.isOk())
	{
		child = new CollectionNodeImpl(target, data->GetName());
		((CollectionNodeImpl*)target)->AddChild(child);
		((CollectionNodeImpl*)data->GetParent())->DeleteChild(data);
	}

	return status;
}

StatusCode CollectionOperatorImpl::SetComment(ICollectionNode* target, const char* comment)
{
	//COLL_COMMENTS
	return SRB_ERROR_INVALID_PARAMETER;
}

StatusCode CollectionOperatorImpl::Replicate_Recursive_Impl(ICollectionNode* target)
{
	SRB::INode* ptr;
	SRB::StatusCode status;
	SRB::IDatasetOperator* op;

	ptr = (SRB::INode*)target;

	if(!ptr->isOpen())
			m_session->OpenTree(ptr, 1, false);

	unsigned int count = ptr->CountChildren();

	for(int i = 0; i < count; i++)
	{
		ptr = target->GetChild(i);
		if(ptr->GetType() == SOB_COLLECTION)
		{
			if(!ptr->isOpen())
				m_session->OpenTree(ptr, 1, false);

			status = Replicate_Recursive_Impl((SRB::ICollectionNode*)ptr);
		}else
		if(ptr->GetType() == SOB_DATASET)
		{
			op = (SRB::IDatasetOperator*)m_session->GetOperator(SOB_DATASET);
			op->Bind(m_binding);
			op->Replicate((SRB::IDatasetNode*)ptr);
		}

		
	}

	return status;

}

StatusCode CollectionOperatorImpl::Replicate(ICollectionNode* target)
{
	if(NULL == target)
		return SRB_ERROR_INVALID_PARAMETER;

	return Replicate_Recursive_Impl(target);

}


StatusCode CollectionOperatorImpl::FillDataset(CollectionNodeImpl* parent, IDatasetNode** child, const char* name)
{
	if(NULL == parent || NULL == child)
		return SRB_ERROR_INVALID_PARAMETER;

	*child = NULL;
	
	ClearMCATScratch();

    m_selval[DATA_NAME] = 1;
    m_selval[DATA_GRP_NAME] = 1;
    m_selval[SIZE] = 1;
    m_selval[DATA_TYP_NAME] = 1;
	m_selval[DATA_OWNER] = 1;
	m_selval[REPL_TIMESTAMP] = 1;
	m_selval[DATA_REPL_ENUM] = 1;
	m_selval[PHY_RSRC_NAME] = 1;
	//m_selval[RSRC_NAME] = 1;
	m_selval[CONTAINER_NAME] = 1;
	m_selval[DATA_COMMENTS] = 1;

    sprintf(m_qval[DATA_GRP_NAME]," = '%s'", parent->GetPath());
    sprintf(m_qval[DATA_NAME]," = '%s'", name);

	StatusCode status = srbGetDataDirInfoWithZone(m_conn, 0, (char*)m_session->GetCurrentZone(parent)->GetName(), m_qval, m_selval, &m_result, MAX_ROWS);

	if(!status.isOk())
	{
		if(-3005 == status)
			return SRB_OK;
		return status;
	}

	filterDeleted(&m_result);

	if(m_result.row_count != 1)
		return SRB_ERROR;

	DatasetNodeImpl* baby;

	baby = new DatasetNodeImpl(parent, &m_result, 0);

	parent->AddChild(baby);

	*child = baby;

	return SRB_OK;
}


int CollectionOperatorImpl::UploadImpl(srbConn* bloadconn, char* local, char* collection, char* resource, bool isContainer)
{
    int c, ii;
    srbPathName nameArray[MAX_TOKEN], targNameArray[MAX_TOKEN];
    char contName[MAX_TOKEN], contCollection[MAX_TOKEN], inpCont[MAX_TOKEN];
  
    srbConn *conn;
    int status;
    int flagval = 0;
    char *userName, *domainName;
    char containerName[MAX_TOKEN];
    char *mcatName = NULL;
    char myMcatName[MAX_TOKEN];
    int copyNum = -1;

    strcpy(inCondition , "");

	if(isContainer)
	{
		strcpy (inpCont, resource);
		strcpy (ResourceName, "");
	}else
	{

		strcpy (ResourceName, resource);
	}

	targNameArray[0].inpArgv = collection;
	strcpy (datatype, "");
	strcpy (newpathname, "");

    nameArray[0].inpArgv = strdup(local);
    SrbNtPathForwardSlash(nameArray[0].inpArgv);

    /* Convert the target name to SQL like */
    if (convNameArrayToSQL (targNameArray, 1) < 0)
      {clFinish(conn); exit(4);}

    if (isContainer)
	{         /* user container */
    	if (conn->clientUser == NULL) {
            userName = conn->proxyUser->userName;
            domainName = conn->proxyUser->domainName;
    	} else {
            userName = conn->clientUser->userName;
            domainName = conn->clientUser->domainName;
    	}


   
                char *thisMcat = NULL;

                thisMcat = getmcatNamefromHint (targNameArray[0].outArgv);
                if (thisMcat == NULL) {
                    status =srbGetMcatZone (conn, userName, domainName,
                     myMcatName);
                    if (status >= 0)
                        mcatName = myMcatName;
                    else
                        mcatName = NULL;
                } else if (strcmp (thisMcat, "home") == 0 ||
                 strcmp (thisMcat, "container") == 0) {
                    mcatName = NULL;
                } else {
                    mcatName = thisMcat;
                }
           


        parseContainerName (inpCont, contName, contCollection, userName, domainName, mcatName);
        sprintf (containerName, "%s/%s", contCollection, contName);
		strcpy (ContainerName, containerName); /*XXXX used in bload.take out */ 
    }else
	{
		containerName[0] = '\0';
    }

    /* set the target resource */

    if (strlen(ResourceName) == 0) {
        get_user_preference(ResourceName, "DRSRC");
    }


	char *myHost;
	srbConn *myConn;

        myHost = getHostByResource (bloadconn, ResourceName, mcatName);
        if (myHost != NULL)
		{
            if (strncmp (srbHost, myHost, strlen (srbHost)) != 0)
			{
                /* different host */
                myConn = srbConnect (myHost, NULL, srbAuth,NULL, NULL, NULL, NULL);
                if (clStatus(myConn) == CLI_CONNECTION_OK)
				{
                    clFinish (conn);
                    conn = myConn;
                    strcpy (srbHost, myHost);
                }
            }
        }
 
		m_bytes_received = 0;
		m_bytes_expected = 0;

      ii = bloadMainBC (bloadconn, MDAS_CATALOG, 1, nameArray, targNameArray,
       flagval, &m_bytes_received, &m_bytes_expected);


 
    if (ii >= 0 && RStatus >= 0)
      return 0;
   
	return 1;
}



#if 1

extern char srbAuth[];
extern char srbHost[];
extern char mdasCollectionName[];
extern char inCondition[];
 
extern int iGlbRetriesMax;
extern int RStatus;
extern NumThreads;


int i;
int lcval;



























int CollectionOperatorImpl::DownloadImpl(srbConn* bdown_conn, const char* local, const char* source, int copyNum, srb_long_t* bytes_received, srb_long_t* bytes_expected)
{
    int  newargc;
   
    int c;
    int flagval = 0;
    srbPathName targNameArray[MAX_TOKEN], srcNameArray[MAX_TOKEN];
    int nArgv;

	nArgv = 1;
  
    FILE *fd;
    int status;
    char ticketId[MDAS_TICKET_SIZE+10];
   
    int i, ii;
   
    int option_index = 0;

    iGlbRetriesMax=(-1);
    strcpy(ticketId , "");
    strcpy(inCondition , "");
    lcval = 0;

    flagval |= b_FLAG;
    
	targNameArray[0].inpArgv = (char*)local;
  
    srcNameArray[0].inpArgv = (char*)source;
	srcNameArray[0].type = COLLECTION_T;
	srcNameArray[0].outArgv = (char*)source;

    if (convNameArrayToSQL (srcNameArray, 0) < 0)
		return -1;

    ii= getMainBC (bdown_conn, 0, nArgv, srcNameArray, targNameArray, flagval, copyNum, ticketId, bytes_received, bytes_expected);
 
	if(ii >= 0 && RStatus >= 0)
		return 0;
	else
		return -1;
}

#if 0
int
CollectionOperatorImpl::getMain (srbConn *conn, int catType, int nArgv, srbPathName nameArray[],
srbPathName targNameArray[], int flagval, int copyNum, char *ticketId, srb_long_t* bytes_received)
{
    int i, j;
    int status=(-1), status1=0;
    mdasC_sql_result_struct *dataResult, *collResult;
    int targType;
    int dataCnt = 0;
    int collCnt = 0;
    char temp[MAX_TOKEN], temp1[MAX_TOKEN];
    char *tmpStr;

    status = chkFileName (&targNameArray[0]);

    targType = targNameArray[0].type;
    dataResult = (mdasC_sql_result_struct *)
      malloc (sizeof (mdasC_sql_result_struct) * nArgv);
    collResult = (mdasC_sql_result_struct *)
      malloc (sizeof (mdasC_sql_result_struct) * nArgv);

    memset (dataResult, 0, sizeof (mdasC_sql_result_struct) * nArgv);
    memset (collResult, 0, sizeof (mdasC_sql_result_struct) * nArgv);

    for (i = 0; i < nArgv; i++) {
        /* set flagval to 0 first for non-recursive check */
        status = expandAndChkName (conn, MDAS_CATALOG, &nameArray[i], 0,
          &dataResult[i], &collResult[i]);
        if (status < 0) {
            fprintf (stderr, "Source %s not found\n", nameArray[i].inpArgv);
            return (CLI_ERR_COLLNAME);
        }
        dataCnt += dataResult[i].row_count;
        collCnt += collResult[i].row_count;
    }

    /* Do some sanity checks */

    if (dataCnt + collCnt == 0) {
        fprintf (stderr, "Source %s not found\n",
          targNameArray[0].inpArgv);
        return (CLI_ERR_COLLNAME);
    }

    if ((dataCnt + collCnt > 1 || collCnt > 0) && targType >= DATANAME_T) {
        fprintf (stderr, "Target %s must be a directory\n",
          targNameArray[0].inpArgv);
        return (CLI_ERR_COLLNAME);
    }

    if (collCnt > 0 && (flagval & R_FLAG) == 0 && (flagval & b_FLAG) == 0) {
        fprintf (stderr, "Must use the -r flag to copy a collection\n");
        return (CLI_ERR_COLLNAME);
    }

    if (targType == -1) {       /* Target does not exist */
        if (dataCnt + collCnt > 1) {
            fprintf (stderr, "Target directory %s not found\n",
              targNameArray[0].inpArgv);
            return (CLI_ERR_COLLNAME);
        }
    }

    status = 0;
    for (i = 0; i < nArgv; i++) {
      do {
        if (dataResult[i].row_count > 0) {      /* source is data */
            if (targType == -1 || targType >= DATANAME_T) {       
		/* A normal data-file copy */
                status = dataToFileCopy (conn, catType, flagval, targType,
                  &dataResult[i], copyNum, targNameArray[0].outArgv, 
                   ticketId);
            } else if (targType == COLLECTION_T || targType == SPEC_COLL_T) {
                status = dataToDirCopyBC(conn, catType, flagval,
                 &dataResult[i], copyNum, targNameArray[0].outArgv,
                   ticketId, bytes_received);
            }
        }

        if (collResult[i].row_count > 0) {      /* source is coll */
            if (!(flagval & b_FLAG) && collCnt == 1 && targType == -1) {
            /* if (collCnt == 1 && targType == -1) { */
                /* the source is a single coll */
                clSplitbychar (targNameArray[0].outArgv, temp, temp1, '/');
                status = mkdir (targNameArray[0].outArgv);
                if (status < 0) {
                    fprintf(stderr,
                     "Unable to mkdir %s, status = %d\n",
                      targNameArray[0].inpArgv, status);
                    return (CLI_ERR_COLLNAME);
                }
                /* mark it as COLLECTION_T */
                targNameArray[0].type = COLLECTION_T;
                targType = COLLECTION_T;
                tmpStr = (char *) getFromResultStruct (&collResult[i],
                  dcs_tname[DATA_GRP_NAME], dcs_aname[DATA_GRP_NAME]);
                status = collToDirCopyCont (conn, catType, flagval, tmpStr,
                 targNameArray[0].outArgv, ticketId);
            } else {
		if (flagval & b_FLAG) {
		    char *myColl;
		    srbPathName collNameArray, *contnameArray;
		    int nVal;

    		    myColl = (char *) getFromResultStruct(&collResult[i],
      		    dcs_tname[DATA_GRP_NAME], dcs_aname[DATA_GRP_NAME]);

		    collNameArray.inpArgv = strdup (myColl);
		    collNameArray.outArgv = strdup (myColl);

		    nVal = getContainerByColl (conn, &collNameArray, 
                     &contnameArray);
		    if (nVal <= 0) {
			status = nVal;
		    } else {
			status = unloadContMain (conn, catType, nVal, 
			 contnameArray, flagval, targNameArray[0].outArgv, 
			 &collNameArray);
		    }
    		    for (j = 0; j < nVal; j++) {
        		free (contnameArray[j].outArgv);
    		    }
    		    free (contnameArray);

		} else {
                    status = collToDirCopy (conn, catType, flagval,
                     nameArray[i].type, &collResult[i], 
		     targNameArray[0].outArgv, ticketId);
		}
            }
        }
        if (status == MCAT_INQUIRE_ERROR)
            status = 0;          
        else if (status < 0)
            break;
        if (dataResult[i].continuation_index >= 0 &&
          dataResult[i].row_count > 0) {
            clearSqlResult (&dataResult[i]);
            status = srbGetMoreRows(conn, catType,
             dataResult[i].continuation_index, &dataResult[i], MAX_GET_RESULTS);
            if (status == 0)
                filterDeleted (&dataResult[i]);
        } else
            clearSqlResult (&dataResult[i]);

        if (collResult[i].continuation_index >= 0 &&
          collResult[i].result_count > 0) {
            clearSqlResult (&collResult[i]);
            status1 = srbGetMoreRows(conn, catType,
             collResult[i].continuation_index, &collResult[i], MAX_GET_RESULTS);
            if (status1 == 0)
                filterDeleted (&collResult[i]);
        } else
            clearSqlResult (&collResult[i]);

      } while ((dataResult[i].result_count > 0 && status == 0) ||
      (collResult[i].result_count > 0 && status1 == 0));
      if (status == MCAT_INQUIRE_ERROR)
        status = 0;
      else if (status < 0)
	break;
    }

    return (status);
}

#endif


#endif


}//end namespace

