#ifndef __SRB_OBJECT_ZONE_OPERATOR_H__
#define __SRB_OBJECT_ZONE_OPERATOR_H__
#include "soGlobals.h"
#include "clConnectExtern.h"

#include "soNode.h"
#include "soZone.h"
#include "scommands.h"

namespace SRB
{

class ZoneOperatorImpl : public IZoneOperator
{
public:
	StatusCode Download(INode* target, const char* local_path) { return -1;};
	StatusCode Upload(INode* target, const char* local_path, unsigned int overwrite, INode** result) { return -1;};
	int GetProgress(char** name) { return -1;};
	StatusCode Bind(INode* node) { return SRB_ERROR_TYPE_NOT_SUPPORTED;};
	int GetType() { return SOB_OP_ZONE; };

	StatusCode GetChildren(ZoneNodeImpl* target, int clean, unsigned int mask = SOB_ALL);
	ZoneOperatorImpl(ISession* session);
	 ~ZoneOperatorImpl();


private:
	ZoneOperatorImpl();
	ZoneOperatorImpl(const ZoneOperatorImpl& source);
	ZoneOperatorImpl& operator =(const ZoneOperatorImpl& source);

	StatusCode GetResources(ZoneNodeImpl* target);
	StatusCode GetDomains(ZoneNodeImpl* target);
	StatusCode GetZoneCollections(ZoneNodeImpl* target);
	StatusCode GetLocalCollection(ZoneNodeImpl* target);
	StatusCode GetAllContainers(IZoneNode* target);


	void ClearMCATScratch();
	mdasC_sql_result_struct m_result;
	char m_qval[MAX_DCS_NUM][MAX_TOKEN];
	int m_selval[MAX_DCS_NUM];
	ISession* m_session;
	IZoneNode* m_zone;
};
}//end namespace
#endif __SRB_OBJECT_ZONE_OPERATOR_H__

