#ifndef __SRB_OBJECT_RESOURCE_OPERATOR_H__
#define __SRB_OBJECT_RESOURCE_OPERATOR_H__

#include "soGlobals.h"
#include "soNode.h"
#include "clConnectExtern.h"
#include "scommands.h"
#include "soResource.h"

namespace SRB
{

class ResourceOperatorImpl : public IResourceOperator
{
public:

	StatusCode Download(INode* target, const char* local_path) { return -1;};
	StatusCode Upload(INode* target, const char* local_path, unsigned int overwrite, INode** result) { return -1;};


	int GetProgress(char** name) { return -1;};
	ResourceOperatorImpl(ISession* session);
	 ~ResourceOperatorImpl();
	INode* GetBinding() { return NULL;};
	StatusCode Bind(INode* node) { return SRB_ERROR_TYPE_NOT_SUPPORTED;};
	int GetType() { return SOB_OP_RESOURCE; };


	//interface
	virtual StatusCode Create(IResourceNode* target, const char* name, IContainerNode** result = 0);

	//impl
	StatusCode GetChildren(ResourceNodeImpl* target, unsigned int mask = SOB_ALL);
	StatusCode GetContainer(ResourceNodeImpl* target);
	StatusCode GetAllContainers();

private:
	ResourceOperatorImpl();
	ResourceOperatorImpl(const ResourceOperatorImpl& source);
	ResourceOperatorImpl& operator =(const ResourceOperatorImpl& source);

	void ClearMCATScratch();
	mdasC_sql_result_struct m_result;
	char m_qval[MAX_DCS_NUM][MAX_TOKEN];
	int m_selval[MAX_DCS_NUM];
	ISession* m_session;
	srbConn* m_conn;

	IResourceNode* m_resources;
};
}//end namespace
#endif

