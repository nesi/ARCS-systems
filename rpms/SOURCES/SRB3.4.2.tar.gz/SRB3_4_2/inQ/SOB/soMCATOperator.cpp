#include "soMCATOperator.h"
#include "soMCAT.h"
#include "soUser.h"
#include "soZone.h"
#include "clStubExtern.h"
#include "scommands.h"

#include "soSession.h"


namespace SRB
{

StatusCode MCATOperatorImpl::FindZone4User(const char* domain, const char* user, char* zone_buf)
{
	StatusCode status = srbGetMcatZone((srbConn*)m_session->GetConn(), (char*)user, (char*)domain, zone_buf);
		
	if(!status.isOk())
		return status;

	return SRB_OK;
}

MCATOperatorImpl::MCATOperatorImpl(ISession* session)
{
	m_session = session;
	m_result.result_count = 0;
	m_result.row_count = 0;
}

MCATOperatorImpl::~MCATOperatorImpl()
{
}

void MCATOperatorImpl::ClearMCATScratch()
{
    clearSqlResult (&m_result);

    for(int i = 0; i < MAX_DCS_NUM; i++)
	{
        sprintf(m_qval[i],"");
        m_selval[i] = 0;
    }
}

StatusCode MCATOperatorImpl::GetChildren(MCATNodeImpl* target, unsigned int mask)
{
	if(NULL == target)
		return SRB_ERROR_INVALID_PARAMETER;

	target->Clear();

	StatusCode status;
	
	unsigned int success = SOB_ALL ^ SOB_ZONE;

	if(SOB_ZONE & mask)
	{
		status = GetZones(target);
		if(status.isOk())
		{
			success |= SOB_ZONE;
		}
		else
		{
			target->SetOpen(success);
			return status;
		}
	}

	if(SOB_COLLECTION & mask)
	{
		status = GetLocalCollections(target);
		if(status.isOk())
		{
			success |= SOB_COLLECTION;
		}
		else
		{
			target->SetOpen(success);
			return status;
		}
	}

	target->SetOpen(success);
	return status;
}

StatusCode MCATOperatorImpl::GetZones(MCATNodeImpl* target)
{
	ClearMCATScratch();

	//_selval[DOMAIN_DESC] = 1;
	m_selval[ZONE_NAME] = 1;

	char buf[1024];
	StatusCode status = srbGetDataDirInfoWithZone((srbConn*)m_session->GetConn(),
		0, buf, m_qval, m_selval, &m_result, 200);

	filterDeleted(&m_result);

	char* zone = getFromResultStruct(&m_result,dcs_tname[ZONE_NAME], dcs_aname[ZONE_NAME]);

	ZoneNodeImpl* child = new ZoneNodeImpl(target, zone);

	target->AddChild(child);

	for(int i = 1; i < m_result.row_count; i++)
	{
		zone += MAX_DATA_SIZE;
		child = new ZoneNodeImpl(target, zone);
		target->AddChild(child);
	}

	return SRB_OK;
}



StatusCode MCATOperatorImpl::GetLocalCollections(MCATNodeImpl* target)
{
	ClearMCATScratch();

	CollectionNodeImpl* root = new CollectionNodeImpl("home");
	target->AddChild(root);	


    m_selval[DATA_GRP_NAME] = 1;
    sprintf(m_qval[PARENT_COLLECTION_NAME]," = '%s'", root->GetPath());


    StatusCode status = srbGetDataDirInfo((srbConn*)m_session->GetConn(), 0, m_qval, m_selval, &m_result, MAX_ROWS);


	if(!status.isOk() || -3005 == status)
	{
		//even though root collection could have user permissions, datasets, etc.
		//we set the root to all because usually they aren't things we want to see.
		//root->SetOpen(SOB_ALL);
		target->DeleteChild(root);
		return SRB_OK;
	}



	filterDeleted(&m_result);

	char *original, *szptr;

	int len;

	while(true)
	{
		original = getFromResultStruct(&m_result,dcs_tname[DATA_GRP_NAME], dcs_aname[DATA_GRP_NAME]);

		for(int i = 0; i < m_result.row_count; i++)
		{
			szptr = original;

			len = strlen(szptr);

			for(int j = len - 1; j >= 0; j--)
				if('/' == szptr[j])
				{
					szptr = &szptr[j+1];
					break;
				}

			root->AddChild(new CollectionNodeImpl(root, szptr));

			original += MAX_DATA_SIZE;
		}

		if(m_result.continuation_index < 0)
		{
			//setting root to all keeps us from looking for its access permissions, etc.
			//note this used to take a long time, at least, and was ultimately not what
			//we wanted to show, hence the hack.
			root->SetOpen(SOB_ALL);
			break;
		}

		status = srbGetMoreRows((srbConn*)m_session->GetConn(), 0, m_result.continuation_index, &m_result, MAX_ROWS);

		if(-3005 == status)	
			return SRB_OK;

		if(0 != status)
			return SRB_ERROR;
	}

	return SRB_OK;
}
}
