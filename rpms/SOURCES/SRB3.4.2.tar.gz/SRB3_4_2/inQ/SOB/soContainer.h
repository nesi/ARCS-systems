#ifndef __SRB_OBJECT_CONTAINER_NODE_H__
#define __SRB_OBJECT_CONTAINER_NODE_H__
#include "soGlobals.h"
#include "soNode.h"
#include "mdasC_db2_externs.h"
#include <vector>

namespace SRB
{
class ContainerNodeImpl : public IContainerNode
{
public:
	ContainerNodeImpl(INode* parent, const char* container_path);
	 ~ContainerNodeImpl();

	const char* GetName();
	const char* GetPath();
	const char* GetContainerPath();
	INode* GetParent() {return m_parent;};
	INode* GetChild(int pos) { return NULL;};
	StatusCode GetChild(const char* name, INode** result);
	unsigned int GetType() { return SOB_CONTAINER;};

	int CountChildren() { return 0;};
	int CountHeightFromRoot();

	INode* GetChild(const char* name) { return NULL;};

	bool isOpen(unsigned int mask = SOB_ALL) { return true; };
	unsigned int GetOpen() { return SOB_ALL;};

	INode* GetUncle(int pos) { return NULL;};
	int CountUncles() { return 0;};


private:
	char* m_name;
	char* m_path;
	char* m_container_path;
	INode* m_parent;
};


}//end namespace
#endif