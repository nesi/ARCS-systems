/**************************************************************************
Copyright Notice
All Rights Reserved
Please refer to files in COPYRIGHT directory under the SRB software directory
for copyright, usage, liability and license information.
Please read these files before using,modifying or distributing SRB software.
**************************************************************************/



/*****************************************************************************/
/*                                                                           */
/*  WHAT:   mcatSmodR.java                                                   */
/*                                                                           */
/*  WHY:    xxx                                                              */
/*                                                                           */
/*  WHERE:  San Diego Supercomputer Center (SDSC)                            */
/*                                                                           */
/*  WHEN:   2/5/99                                                           */
/*                                                                           */
/*  HOW:    JAVA                                                             */
/*                                                                           */
/*****************************************************************************/

package edu.sdsc.SrbAdmin;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.border.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
import java.sql.Time;

import edu.sdsc.SrbBrowser.SrbElement;
import edu.sdsc.SrbBrowser.SrbCellRenderer;


import edu.sdsc.grid.io.srb.*;
import edu.sdsc.grid.io.*;
import edu.sdsc.grid.io.local.*;
import java.io.IOException;

/**
 * mcatSmodR
 *
 */
public class mcatMiscResc extends JFrame 
{
    // Insets
    public final static Insets insets5
		= new Insets( 5, 5, 5, 5 );

    //Labels to identify the text fields

//	public Time test;

	private JLabel oprMsgLabel;
    private JLabel arg1Label;
	private JLabel arg2Label;
	private JLabel rescNameLabel;
	private JLabel statusLabel;
	private JLabel space1Label;
	private JLabel space2Label;

	//Option Buttons for various SmodR -flag commands.
	private JRadioButton iButton;
	private JRadioButton dButton;
	private JRadioButton oButton;
	private JRadioButton xButton;
	private JRadioButton nButton;
	private JRadioButton bButton;
	private JRadioButton cButton;
	private JRadioButton sButton;
	private JRadioButton hButton;
	private JRadioButton gButton;
	private JRadioButton rButton;
	private JRadioButton zButton;
	private JRadioButton DButton;
	private JRadioButton EButton;
	private JRadioButton LButton;

    //Strings for the labels
	private static String oprMsgStr = 
		"Select  a  Modify  Resource  Operation: ";
	private static String argStr = "N/A: ";
    private static String rescNameStr = "Resource Name: ";
    private static String statusStr = "Status: ";
	private static String iStr = "Insert/Modify Access";
	private static String dStr = "Delete Access";
	private static String oStr = "Change Ownership";
	private static String xStr = "Maximum Latency";
	private static String nStr = "Minimum Latency";
	private static String bStr = "Modify Bandwidth";
	private static String cStr = "Maximum concurrency";
	private static String sStr = "Modify Striping";
	private static String hStr = "Number of Hierarchies";
	private static String gStr = "Maximum Capacity";
	private static String rStr = "Rename";
	private static String zStr = "Modify Description";
	private static String DStr = "Disable Write Access";
	private static String EStr = "Enable Write Access";
	private static String LStr = "Modify Location";

    //Text fields for data entry
	private JTextField arg1Field;
	private JTextField arg2Field;

    // rescName list box
    DefaultListModel rescNameModel;
    private JList rescNameList;
    JScrollPane  rescNamePane;
    public String selrescName = null;

    private SRBFileSystem fileSystem;
	private static int catalogType = 0;

	ButtonGroup myRGroup;
    RadioListener myListener;
    String myCommand = null;

    private JTextArea msgText;

    // Fonts
    public Font msgFont
        = new Font("TimeRoman", Font.BOLD, 16);


    public mcatMiscResc(SRBFileSystem srbFileSystem)
    {
		this.fileSystem = srbFileSystem;

		setTitle (new String ("Modify Resource"));

		// Init the layout
		GridBagLayout layout = new GridBagLayout();
		getContentPane().setLayout( layout );
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.fill = GridBagConstraints.BOTH;

		//Create the labels
		oprMsgLabel = new JLabel(oprMsgStr);
		buildConstraints (constraints, 0, 1, 1, 1, 100, 100);
		layout.setConstraints( oprMsgLabel, constraints );
		getContentPane().add( oprMsgLabel );

		arg1Label = new JLabel(argStr);
		buildConstraints (constraints, 0, 6, 1, 1, 100, 100);
		layout.setConstraints( arg1Label, constraints );
		getContentPane().add( arg1Label );
		arg1Label.setLabelFor(arg1Field);
		//arg1Label.setVisible(false);
		//arg1Label.setEnabled(false);
	
		arg2Label = new JLabel(argStr);
		buildConstraints (constraints, 0, 7, 1, 1, 100, 100);
		layout.setConstraints( arg2Label, constraints );
		getContentPane().add( arg2Label );
		arg2Label.setLabelFor(arg2Field);
		//arg2Label.setVisible(false);
		//arg2Label.setEnabled(false);

		rescNameLabel = new JLabel(rescNameStr);
		buildConstraints (constraints, 0, 0, 1, 1, 100, 100);
		layout.setConstraints( rescNameLabel, constraints );
		getContentPane().add( rescNameLabel );

		statusLabel = new JLabel(statusStr);
		buildConstraints (constraints, 0, 9, 1, 1, 100, 100);
		layout.setConstraints( statusLabel, constraints );
		getContentPane().add( statusLabel );

		space1Label = new JLabel("\n");
		space1Label.setFont (msgFont);
		buildConstraints (constraints, 0, 6, 3, 1, 100, 100);
		layout.setConstraints( space1Label, constraints );
		getContentPane().add( space1Label );

		space2Label = new JLabel("\n");
		space2Label.setFont (msgFont);
		buildConstraints (constraints, 0, 7, 3, 1, 100, 100);
		layout.setConstraints( space2Label, constraints );
		getContentPane().add( space2Label );

		//Create the text fields
		arg1Field = new JTextField(16);
		buildConstraints (constraints, 1, 6, 2, 1, 100, 100);
		layout.setConstraints( arg1Field, constraints );
		getContentPane().add( arg1Field );
		//arg1Field.setVisible(false);
		//arg1Field.setEnabled(false);

		arg2Field = new JTextField(16);
		buildConstraints (constraints, 1, 7, 2, 1, 100, 100);
		layout.setConstraints( arg2Field, constraints );
		getContentPane().add( arg2Field );
		//arg2Field.setVisible(false);
		//arg2Field.setEnabled(false);

		// rescName List
		rescNameModel = new DefaultListModel();
		rescNameList = new JList( rescNameModel );
		rescNameList.setCellRenderer( new SrbCellRenderer() );
		// The scrolling pane containing the list
		rescNamePane = new JScrollPane();
		rescNamePane.getViewport().setView( rescNameList );
		buildConstraints (constraints, 1, 0, 2, 1, 100, 200);
		layout.setConstraints( rescNamePane, constraints );
		getContentPane().add( rescNamePane );
		rescNamePane.setPreferredSize (new Dimension(200, 70));

		MouseListener rescNameListener = new MouseAdapter()
		{
			public void mouseClicked( MouseEvent e ) 
			{
				SrbElement elem = (SrbElement)
					rescNameList.getSelectedValue();
				if ( elem != null ) 
				{
					selrescName = elem.getName();
				} 
				else 
				{
					selrescName = null;
				}
			}
		};
		rescNameList.addMouseListener( rescNameListener );

		//Create the radio buttons
		iButton = new JRadioButton (iStr);
		buildConstraints (constraints, 0, 2, 1, 1, 100, 100);
		layout.setConstraints( iButton, constraints );
		getContentPane().add( iButton );
		iButton.setSelected(false);
		iButton.setActionCommand(iStr);

/*		MouseListener iListener = new MouseAdapter()
		{
			public void mouseClicked( MouseEvent e ) 
			{
				arg1Label.setText("user@domain");
				arg2Label.setText("accs");
//				arg1Field.setVisible(true);
//				arg2Field.setVisible(true);
			}
		};
		iButton.addMouseListener( iListener );
*/
		dButton = new JRadioButton (dStr);
		buildConstraints (constraints, 1, 2, 1, 1, 100, 100);
		layout.setConstraints( dButton, constraints );
		getContentPane().add( dButton );
		dButton.setSelected(false);
		dButton.setActionCommand(dStr);

		oButton = new JRadioButton (oStr);
		buildConstraints (constraints, 2, 2, 1, 1, 100, 100);
		layout.setConstraints( oButton, constraints );
		getContentPane().add( oButton );
		oButton.setSelected(false);
		oButton.setActionCommand(oStr);

		xButton = new JRadioButton (xStr);
		buildConstraints (constraints, 3, 2, 1, 1, 100, 100);
		layout.setConstraints( xButton, constraints );
		getContentPane().add( xButton );
		xButton.setSelected(false);
		xButton.setActionCommand(xStr);

		nButton = new JRadioButton (nStr);
		buildConstraints (constraints, 0, 3, 1, 1, 100, 100);
		layout.setConstraints( nButton, constraints );
		getContentPane().add( nButton );
		nButton.setSelected(false);
		nButton.setActionCommand(nStr);
	
		bButton = new JRadioButton (bStr);
		buildConstraints (constraints, 1, 3, 1, 1, 100, 100);
		layout.setConstraints( bButton, constraints );
		getContentPane().add( bButton );
		bButton.setSelected(false);
		bButton.setActionCommand(bStr);

		cButton = new JRadioButton (cStr);
		buildConstraints (constraints, 2, 3, 1, 1, 100, 100);
		layout.setConstraints( cButton, constraints );
		getContentPane().add( cButton );
		cButton.setSelected(false);
		cButton.setActionCommand(cStr);

		sButton = new JRadioButton (sStr);
		buildConstraints (constraints, 3, 3, 1, 1, 100, 100);
		layout.setConstraints( sButton, constraints );
		getContentPane().add( sButton );
		sButton.setSelected(false);
		sButton.setActionCommand(sStr);

		hButton = new JRadioButton (hStr);
		buildConstraints (constraints, 0, 4, 1, 1, 100, 100);
		layout.setConstraints( hButton, constraints );
		getContentPane().add( hButton );
		hButton.setSelected(false);
		hButton.setActionCommand(hStr);

		gButton = new JRadioButton (gStr);
		buildConstraints (constraints, 1, 4, 1, 1, 100, 100);
		layout.setConstraints( gButton, constraints );
		getContentPane().add( gButton );
		gButton.setSelected(false);
		gButton.setActionCommand(gStr);

		rButton = new JRadioButton (rStr);
		buildConstraints (constraints, 2, 4, 1, 1, 100, 100);
		layout.setConstraints( rButton, constraints );
		getContentPane().add( rButton );
		rButton.setSelected(false);
		rButton.setActionCommand(rStr);

		zButton = new JRadioButton (zStr);
		buildConstraints (constraints, 3, 4, 1, 1, 100, 100);
		layout.setConstraints( zButton, constraints );
		getContentPane().add( zButton );
		zButton.setSelected(false);
		zButton.setActionCommand(zStr);

		DButton = new JRadioButton (DStr);
		buildConstraints (constraints, 0, 5, 1, 1, 100, 100);
		layout.setConstraints( DButton, constraints );
		getContentPane().add( DButton );
		DButton.setSelected(false);
		DButton.setActionCommand(DStr);

		EButton = new JRadioButton (EStr);
		buildConstraints (constraints, 1, 5, 1, 1, 100, 100);
		layout.setConstraints( EButton, constraints );
		getContentPane().add( EButton );
		EButton.setSelected(false);
		EButton.setActionCommand(EStr);

		LButton = new JRadioButton (LStr);
		buildConstraints (constraints, 2, 5, 1, 1, 100, 100);
		layout.setConstraints( LButton, constraints );
		getContentPane().add( LButton );
		LButton.setSelected(false);
		LButton.setActionCommand(LStr);

		myRGroup = new ButtonGroup();
		myRGroup.add(iButton);
		myRGroup.add(dButton);
		myRGroup.add(oButton);
		myRGroup.add(xButton);
		myRGroup.add(nButton);
		myRGroup.add(bButton);
		myRGroup.add(cButton);
		myRGroup.add(sButton);
		myRGroup.add(hButton);
		myRGroup.add(gButton);
		myRGroup.add(rButton);
		myRGroup.add(zButton);
		myRGroup.add(DButton);
		myRGroup.add(EButton);
		myRGroup.add(LButton);

		// Register a listener for the radio buttons.
        myListener = new RadioListener();
        iButton.addActionListener(myListener);
		dButton.addActionListener(myListener);
		oButton.addActionListener(myListener);
		xButton.addActionListener(myListener);
		nButton.addActionListener(myListener);
		bButton.addActionListener(myListener);
		cButton.addActionListener(myListener);
		sButton.addActionListener(myListener);
		hButton.addActionListener(myListener);
		gButton.addActionListener(myListener);
		rButton.addActionListener(myListener);
		zButton.addActionListener(myListener);
		DButton.addActionListener(myListener);
		EButton.addActionListener(myListener);
		LButton.addActionListener(myListener);

		// "Execute" Button

		JButton executeButton = new JButton( "Execute" );
		buildConstraints (constraints, 1, 8, 1, 1, 50, 100);
		layout.setConstraints( executeButton, constraints );
		getContentPane().add( executeButton );

		ActionListener executeListener = new ActionListener() 
		{
			public void actionPerformed( ActionEvent e )
			{
			  try
			  {
				msgText.append(DateFormat.getTimeInstance().format(
					new Date()) + ": ");

				if (selrescName == null) 
				{
					msgText.append (new String (
						"Error: Missing User Domain. " +
						"Execution failed.\n"));
					return;
				}

				if (myCommand == null) 
				{
					msgText.append (new String ("Error: No Operation "
						+ "has been chosen. Execution failed.\n"));
					return;
				} 
				else if (myCommand == iStr)	// Modify Access
				{
					boolean didUpdate=false;

					String inputUserDomain = new String (arg1Field.getText());
					String inputAccess = new String (arg2Field.getText());
					if (inputUserDomain.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing user@domain input. " +
							"Execution failed.\n"));
						return;
					}
					if (inputAccess.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing accs input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						     selrescName, 
						     SRBMetaDataSet.R_INSERT_ACCS,
						     inputUserDomain, inputAccess,
						     "", "");
				}
				else if (myCommand == dStr)	// Delete Access
				{
					boolean didUpdate=false;

					String inputUserDomain = new String (arg1Field.getText());
					if (inputUserDomain.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing user@domain input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						selrescName, 
						SRBMetaDataSet.R_DELETE_ACCS,
                                                inputUserDomain, "", "", "");
				}
				else if (myCommand == oStr)	// Change Ownership
				{
					boolean didUpdate=false;

					String inputUserDomain = new String (arg1Field.getText());
					if (inputUserDomain.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing user@domain input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						selrescName, 
	 				        SRBMetaDataSet.R_CHANGE_OWNER,
						inputUserDomain, "",
						"", "");
				}
				else if (myCommand == xStr)	// Modify Max Latency
				{
					boolean didUpdate=false;

					String inputMaxLatency = new String (arg1Field.getText());
					if (inputMaxLatency.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing Maximum Latency input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						selrescName, 
                                                SRBMetaDataSet.R_ADJUST_LATENCY_MAX_IN_MILLISEC,
                                                inputMaxLatency, "", "", "");
						
				}
				else if (myCommand == nStr)	// Modify Min Latency
				{
					boolean didUpdate=false;

					String inputMinLatency = new String (arg1Field.getText());
					if (inputMinLatency.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing Maximum Latency input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
	 				       selrescName,
					       SRBMetaDataSet.R_ADJUST_LATENCY_MIN_IN_MILLISEC,
					       inputMinLatency, "","", "" );
						
				}
				else if (myCommand == bStr)	// Modify Bandwidth
				{
					boolean didUpdate=false;

					String inputBandwidth = new String (arg1Field.getText());
					if (inputBandwidth.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing Bandwidth input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						selrescName, 
						SRBMetaDataSet.R_ADJUST_BANDWIDTH_IN_MBITSPS,
                                                inputBandwidth, "", "", "");
				}
				else if (myCommand == cStr)	// Modify Max Concurrency
				{
					boolean didUpdate=false;

					String inputMaxConcurrency = 
						new String (arg1Field.getText());
					if (inputMaxConcurrency.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing Maximum Concurrency input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						selrescName, 
						SRBMetaDataSet.R_ADJUST_MAXIMUM_CONCURRENCY,
                                                inputMaxConcurrency, "", "", "");
				}
				else if (myCommand == sStr)	// Modify Striping
				{
					boolean didUpdate=false;

					String inputNumStripes = new String (arg1Field.getText());
					if (inputNumStripes.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing Number of Stripes input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						selrescName, 
                                                SRBMetaDataSet.R_ADJUST_NUM_OF_STRIPES,
                                                inputNumStripes, "",
						"", "");
				}
				else if (myCommand == hStr)	// Modify # of hierarchies
				{
					boolean didUpdate=false;

					String inputNumHierarchies = 
						new String (arg1Field.getText());
					if (inputNumHierarchies.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing Number of Hierarchies input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						selrescName, 
						SRBMetaDataSet.R_ADJUST_NUM_OF_HIERARCHIES,
						inputNumHierarchies, "", "", "");
				}
				else if (myCommand == gStr)	// Modify Max Capacity
				{
					boolean didUpdate=false;

					String inputMaxCapacity = new String (arg1Field.getText());
					if (inputMaxCapacity.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing Maxiumum Capacity input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						selrescName, 
						SRBMetaDataSet.R_ADJUST_CAPACITY_IN_GIGABYTES, 
						inputMaxCapacity, "","","");
						
				}
				else if (myCommand == rStr)	// Rename
				{
					boolean didUpdate=false;

					String inputNewName = new String (arg1Field.getText());
					if (inputNewName.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing New Resource Name input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						selrescName, 
						SRBMetaDataSet.R_RENAME, 
						inputNewName, "", "", "");
				}
				else if (myCommand == zStr)	// Modify Description
				{
					boolean didUpdate=false;

					String inputNewDesc = new String (arg1Field.getText());
					if (inputNewDesc.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing New Description input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						selrescName, 
						SRBMetaDataSet.R_ADJUST_DESCRIPTION, 
						inputNewDesc, "", "", "");
				}
				else if (myCommand == EStr)	// Set to down state
				{
					boolean didUpdate=false;

					Date test = new Date();
					String tmpStr = (test.getTime() / 1000) + "\n";
					String RES_RESOURCE_RESTART = "-1";
					fileSystem.srbModifyRescInfo (catalogType, selrescName, 
						SRBMetaDataSet.R_INSERT_FREE_SPACE, 
						RES_RESOURCE_RESTART, tmpStr, "", "");
				}
				else if (myCommand == DStr)	// Set to up state
				{
					boolean didUpdate=false;

					Date test = new Date();
					String tmpStr = (test.getTime() / 1000) + "\n";
					String RES_RESOURCE_DELETED = "-4";
					fileSystem.srbModifyRescInfo (catalogType, selrescName, 
						SRBMetaDataSet.R_INSERT_FREE_SPACE, 
						RES_RESOURCE_DELETED, tmpStr, "", "");
				}
				else if (myCommand == LStr)	// Modify Access
				{
					boolean didUpdate=false;

					String inputNewLoc = new String (arg1Field.getText());
					if (inputNewLoc.length() == 0) 
					{
						msgText.append (new String (
							"Error: Missing New Resource Location input. " +
							"Execution failed.\n"));
						return;
					}
					fileSystem.srbModifyRescInfo(catalogType, 
						selrescName, 
						SRBMetaDataSet.R_CHANGE_LOCATION,
						inputNewLoc, "", "", "");
						
				}
				msgText.append (new String (
					"Notice: Complete modifying resource " + 
					selrescName + "\n"));
			  }
			  
			  catch (IOException ioe) 
			  {
				String statString="";
				if (ioe instanceof SRBException) 
				{
					statString = ((SRBException) ioe).getStandardMessage();
				}
				msgText.append (new String (
				"Error: Error modifying resource. Status = " +
					statString + ioe.getMessage()+ "\n"));
			  }
			}
		};
		executeButton.addActionListener( executeListener );


        // "Clear" Button
        JButton clearButton = new JButton( "Clear / Refresh" );
        buildConstraints (constraints, 2, 8, 1, 1, 50, 100);
        layout.setConstraints( clearButton, constraints );
        getContentPane().add( clearButton );

        ActionListener clearListener = new ActionListener() 
		{
            public void actionPerformed( ActionEvent e ) 
			{
				fillRescName ();
				selrescName = null;
				clearInput ();
            }
        };
        clearButton.addActionListener( clearListener );


		// "Close" Button
        JButton exitButton = new JButton( "Close" );
		buildConstraints (constraints, 3, 8, 1, 1, 50, 100);
        layout.setConstraints( exitButton, constraints );
        getContentPane().add( exitButton );

        ActionListener exitListener = new ActionListener() 
		{
            public void actionPerformed( ActionEvent e ) 
			{
				setVisible (false);
            }
        };
        exitButton.addActionListener( exitListener );

		// Status Box
		msgText = new JTextArea (3, 60);
		msgText.setLineWrap(true);
        msgText.setWrapStyleWord(true);
        JScrollPane areaScrollPane = new JScrollPane(msgText);
        areaScrollPane.setVerticalScrollBarPolicy(
			JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        buildConstraints (constraints, 1, 9, 3, 2, 100, 100);
        layout.setConstraints( areaScrollPane, constraints );
        getContentPane().add( areaScrollPane );

		
		fillRescName ();

		pack();
		show();
		arg1Label.setVisible(false);
		arg2Label.setVisible(false);
		arg1Field.setVisible(false);
		arg2Field.setVisible(false);
	}

	class RadioListener implements ActionListener 
	{
        public void actionPerformed(ActionEvent e) 
		{
			/*
            if (selDomain == null) {
                msgText.append (new String (
                 "Error: Missing User Domain. Operation failed.\n"));
                return;
            }

            if (selUserName == null) {
                msgText.append (new String (
                 "Error: Missing User Name. Operation failed.\n"));
                return;
            }
			*/

			myCommand = e.getActionCommand();
			clearInput ();

			if (myCommand == iStr) // Modify Access
			{
				arg1Label.setText("user@domain: ");
				arg2Label.setText("accs: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(true);
				arg1Field.setVisible(true);
				arg2Field.setVisible(true);
			}
			else if (myCommand == dStr) // Delete Access
			{
				arg1Label.setText("user@domain: ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
			else if (myCommand == oStr) // Change Ownership
			{
				arg1Label.setText("user@domain: ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
			else if (myCommand == xStr) // Modify Max Latency
			{
				arg1Label.setText("Maximum Latency (milliseconds): ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
			else if (myCommand == nStr) // Modify Min Latency
			{
				arg1Label.setText("Minimum Latency (milliseconds): ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
			else if (myCommand == bStr) // Modify Bandwidth
			{
				arg1Label.setText("Bandwidth (MegaBits per sec): ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
			else if (myCommand == cStr) // Modify Max Concurrency
			{
				arg1Label.setText("Maximum Concurrency: ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
			else if (myCommand == sStr) // Modify # of Stripes
			{
				arg1Label.setText("Number of Stripes: ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
			else if (myCommand == hStr) // Modify # of Hierarchies
			{
				arg1Label.setText("Number of Hierarchies: ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
			else if (myCommand == gStr) // Modify Max Capacity
			{
				arg1Label.setText("Maximum Capacity (GigaBytes): ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
			else if (myCommand == rStr) // Rename
			{
				arg1Label.setText("New Resource Name: ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
			else if (myCommand == zStr) // Modify Description
			{
				arg1Label.setText("New Resource Description: ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
			else if (myCommand == DStr) // Disable Write Access
			{
				arg1Label.setText("N/A: ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(false);
				arg2Label.setVisible(false);
				arg1Field.setVisible(false);
				arg2Field.setVisible(false);
			}
			else if (myCommand == EStr) // Enable Write Access
			{
				arg1Label.setText("N/A: ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(false);
				arg2Label.setVisible(false);
				arg1Field.setVisible(false);
				arg2Field.setVisible(false);
			}
			else if (myCommand == LStr) // Modify Location
			{
				arg1Label.setText("New Resource Location: ");
				arg2Label.setText("N/A: ");
				arg1Label.setVisible(true);
				arg2Label.setVisible(false);
				arg1Field.setVisible(true);
				arg2Field.setVisible(false);
			}
		}
	}

	public void clearInput() 
	{
        arg1Field.setText (null);
		arg2Field.setText (null);
    }

    public void fillRescName()
	{
		MetaDataCondition[] conditions = { MetaDataSet.newCondition(
			SRBMetaDataSet.RESOURCE_TYPE_NAME, MetaDataCondition.NOT_EQUAL,
			"compound" ) };

		MetaDataSelect[] selects = {
		  MetaDataSet.newSelection( SRBMetaDataSet.PHYSICAL_RESOURCE_NAME )};

		MetaDataRecordList[] rl = null;

		rescNameModel.removeAllElements();

		try 
		{
			rl = fileSystem.query( conditions, selects );
		} 
		catch (IOException ioe) 
		{
			String statString="";
			if (ioe instanceof SRBException) 
			{
				statString = ((SRBException) ioe).getStandardMessage();
			}
			msgText.append (new String (
				"Error: Error modifying resource. Status = " +
				statString + ioe.getMessage()+ "\n"));
		}

		if (rl != null) 
		{
			for (int i=0; i<rl.length; i++) 
			{
				rescNameModel.addElement( new SrbElement( 
					rl[i].getStringValue(0), null ) );
			}
		}
    }

    void buildConstraints (GridBagConstraints gbc, int gx, int gy, int gw,
     int gh, int wx, int wy) {
	gbc.gridx = gx;
	gbc.gridy = gy;
	gbc.gridwidth = gw;
	gbc.gridheight = gh;
	gbc.weightx = wx;
	gbc.weighty = wy;
    }

    public static void main(String[] args) {

        try {
            mcatNewLogResc  myMcatNewLogResc = new mcatNewLogResc(
		new SRBFileSystem());
        } catch (Exception e) {
            System.exit(0);
        }
    }
}
