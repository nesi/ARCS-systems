#
#	Copyright Saul Youssef, June 2003
#
from Base        import *
from StringAttr  import *

class DownloadSource(StringAttr):
	type   = 'download source'
	action = 'set download source'
	title  = 'Download Sources'
	
