#
#	Copyright, August 2003, Saul Youssef
#
from RPM import *

class RPMinstalled(RPM):
	type   = 'check if rpm installed'
	title  = 'RPMs installed'
	action = 'check if rpm installed'
	
	def __init__(self,rpmfile): self.rpmfile = rpmfile

#-- Satisfiable
	def satisfiable(self): return self.satisfied()
