#
#	Copyright, Saul Youssef, August 2003
#
from IntAttr import *

class UsePackageRoot(IntAttr):
	type = 'use package root'
	title = 'Uses Package Root'
	action = 'use package root'
