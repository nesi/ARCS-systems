#
#	Copyright Saul Youssef, June 2003
#
#from Directory import *
#
#class PersistentDirectory(Directory):
#	type = 'mkdirPersistent'
#	title = 'Persistent Directories'
#
#-- Action
#	def retract(self): return Reason()
	




		
