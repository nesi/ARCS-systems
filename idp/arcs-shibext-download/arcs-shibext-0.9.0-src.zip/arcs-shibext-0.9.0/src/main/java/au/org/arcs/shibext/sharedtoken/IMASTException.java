/**
 * 
 */
package au.org.arcs.shibext.sharedtoken;

/**
 * @author Damien Chen
 *
 */
public class IMASTException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -942576894643250557L;

	/**
	 * 
	 */
	public IMASTException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public IMASTException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public IMASTException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public IMASTException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
