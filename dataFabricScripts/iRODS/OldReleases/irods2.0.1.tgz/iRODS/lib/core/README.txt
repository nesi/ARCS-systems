DIRECTORY
	iRODS/lib/core	- core functions for clients and servers

DESCRIPTION
	This directory contains core functions used by both clients
	and servers.
