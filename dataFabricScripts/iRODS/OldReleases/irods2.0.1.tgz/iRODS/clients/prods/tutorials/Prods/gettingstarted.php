<?php 
  require_once("/Path/to/Prods/src/Prods.inc.php");
  ... rest of your code ...
?>