<?php  
  
  // following is general defines. Do not motify unless you know what you
  // are doing!
  define ("ORDER_BY",      0x400);
  define ("ORDER_BY_DESC", 0x800);
  
?>  