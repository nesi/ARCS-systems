<?php
define ("DONE_OPR", 9999);
define ("PUT_OPR", 1);
define ("GET_OPR", 2);
define ("SAME_HOST_COPY_OPR",3);
define ("COPY_TO_LOCAL_OPR",4);
define ("COPY_TO_REM_OPR",5);
define ("REPLICATE_OPR",6);
define ("REPLICATE_DEST",7);
define ("REPLICATE_SRC",8);
define ("COPY_DEST",9);
define ("COPY_SRC",10);
define ("RENAME_DATA_OBJ",11);
define ("RENAME_COLL",12);
define ("MOVE_OPR",13);
define ("RSYNC_OPR",14);
define ("PHYMV_OPR",15);
define ("PHYMV_SRC",16);
define ("PHYMV_DEST",17);
?>