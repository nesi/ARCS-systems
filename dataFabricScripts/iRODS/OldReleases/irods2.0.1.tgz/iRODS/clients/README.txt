DIRECTORY
	iRODS/clients	- iRODS client programs

DESCRIPTION
	This directory, and its subdirectories, contains client
	programms for accessing remote iRODS servers.  These programs
	include the 'icommands' for command-line access, as well
	as sample web access tools.
