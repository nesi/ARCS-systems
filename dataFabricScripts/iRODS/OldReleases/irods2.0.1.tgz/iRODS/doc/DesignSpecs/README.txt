The documents in this directory were used for internal planning and
decision making and may no longer be completely accurate as we do not
normally keep them up to date.  See the irods wiki for current
information: http://www.irods.org .
