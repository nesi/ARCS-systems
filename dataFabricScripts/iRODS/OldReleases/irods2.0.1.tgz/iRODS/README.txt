This is iRODS, the integrated Rule-based Data System, a distributed
data-management system for creating data grids, digital libraries,
persistent archives, and real-time data systems.  

For information on how to build see:
INSTALL.txt and/or https://www.irods.org/index.php/installation

Web site:
For additional information, please see https://www.irods.org

Release notes:
https://www.irods.org/index.php/Release_Notes

iRODS builds on the previous versions of iRODS and upon our years of
experience developing SRB.

See the above URLs for additional information.  https://www.irods.org
is a Wiki system and includes documentation, descriptions,
publications, presentations, and other information.
