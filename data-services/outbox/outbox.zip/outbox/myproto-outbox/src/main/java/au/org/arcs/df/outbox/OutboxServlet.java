package au.org.arcs.df.outbox;

import edu.sdsc.grid.io.MetaDataCondition;
import edu.sdsc.grid.io.MetaDataRecordList;
import edu.sdsc.grid.io.MetaDataSelect;
import edu.sdsc.grid.io.MetaDataSet;
import edu.sdsc.grid.io.irods.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: pmak
 * Date: Jun 24, 2010
 * Time: 8:22:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class OutboxServlet extends HttpServlet {
    private IRODSAccount acc = null;
    private ServletConfig config = null;


    public void init(ServletConfig _config) throws ServletException
    {
        config = _config;
        Properties props = new Properties();
        try
        {
            System.out.println("config path: " + config.getServletContext().getRealPath("/WEB-INF/classes/outbox.properties"));
            props.load(new FileInputStream(config.getServletContext().getRealPath("/WEB-INF/classes/outbox.properties")));
            String username =props.getProperty("outbox-username", "OUTBOX_READER");
            String pass = props.getProperty("outbox-password");
            String host = props.getProperty("irods-host");
            int port = Integer.valueOf(props.getProperty("irods-port"));
            String zone = props.getProperty("irods-zone");
            acc = new IRODSAccount(host, port, username, pass,  "/" + zone + "/home", zone, "");
        }
        catch(IOException ioe)
        {
            System.err.println("Cannot open outbox.properies.  Please make sure it's in your classpath!");
            throw new ServletException("FATAL: Cannot start servlet");
        }
    }

    public IRODSFileSystem getFilesystem() throws IOException
    {
        IRODSFileSystem sys = new IRODSFileSystem(acc);
        return sys;
    }


    protected void sendFile(IRODSFile file, HttpServletResponse response) throws IOException
    {
        String contentType = config.getServletContext().getMimeType(file.getName());
        response.setHeader("Content-Length", String.valueOf(file.length()));
        response.setContentType((contentType != null) ? contentType : "application/octet-stream");
        response.setContentLength((int) file.length());

        int bufferSize = (int) (file.length() / 100);
        // minimum buf size of 50KiloBytes
        if (bufferSize < 51200)
            bufferSize = 51200;
        // maximum buf size of 5MegaByte
        else if (bufferSize > 5242880)
            bufferSize = 5242880;
        byte[] buf = new byte[bufferSize];
        int count = 0;
        ServletOutputStream output = response.getOutputStream();
        IRODSRandomAccessFile input = new IRODSRandomAccessFile((IRODSFile) file, "r");

        while ((count = input.read(buf)) > 0) {
            output.write(buf, 0, count);
        }
        output.flush();
        output.close();
    }

    protected IRODSFile findFile(IRODSFileSystem sys, String path) throws IOException
    {
        System.out.println("find file");
        MetaDataSelect selectFile[] = MetaDataSet.newSelection(new String[] {
            IRODSMetaDataSet.FILE_NAME,
            IRODSMetaDataSet.DIRECTORY_NAME,
            IRODSMetaDataSet.PATH_NAME,
            IRODSMetaDataSet.PARENT_DIRECTORY_NAME   
        });

        MetaDataCondition[] condList = new MetaDataCondition[1];

        //Watch out for path - need to parse it properly... for security reasons...
        condList[0] = MetaDataSet.newCondition("OUTBOX_URL",
                                    MetaDataCondition.EQUAL, path);

        MetaDataRecordList[] recordList = sys.query(condList, selectFile);

        if((recordList != null) && (recordList.length == 1))
        {
            MetaDataRecordList record = recordList[0];
            String parent = (String)(record.getValue(record.getFieldIndex(IRODSMetaDataSet.PARENT_DIRECTORY_NAME)));
            String filename = (String)(record.getValue(record.getFieldIndex(IRODSMetaDataSet.FILE_NAME)));
            String dirname = (String)(record.getValue(record.getFieldIndex(IRODSMetaDataSet.DIRECTORY_NAME)));

            System.out.println("parent: " + parent);
            System.out.println("filename: " + filename);
            System.out.println("dirname: " + dirname);

            IRODSFile file = new IRODSFile(sys, dirname + "/" + filename);
            return file;
        }
        else
        {
            System.out.println("Cannot find file");
        }

        //File doesn't exist!  Can't find anything that matches the request path
        //i.e. no match for OUTBOX_URL:
        return null;

    }

    protected void doGet(HttpServletRequest req,
                         HttpServletResponse response) throws ServletException, IOException
    {
        IRODSFileSystem sys = null;
        try
        {
            sys = getFilesystem();

            String uri = req.getRequestURI();
            String context = req.getContextPath() + "/";
            System.out.println("path! " + uri);

            String cut = req.getRequestURI().substring(context.length());
            System.out.println("cut: " + cut);

            //findPath
            IRODSFile file = findFile(sys, cut);
            if(file != null)
            {
                //write to outputStream
                sendFile(file, response);
            }
            else
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
        catch(IOException ioe)
        {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
        finally
        {
            if(sys != null)
                sys.close();
        }
    }

}
